﻿using System;

namespace KMN.Gateway
{
    public class Class1
    {
    }
}
