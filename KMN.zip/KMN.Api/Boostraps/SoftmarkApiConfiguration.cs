﻿using Softmark.Api;
using System;
using System.Net.Http.Formatting;
using System.Web.Http;
using System.Web.Http.Dependencies;
using System.Web.Http.Routing;
using Swashbuckle.Application;

namespace Softmark.Api
{
    public sealed  class SoftmarkApiConfiguration
    {
		private readonly Lazy<HttpConfiguration> _config = new Lazy<HttpConfiguration>(Register, true);
	    private SoftmarkApiConfiguration()
	    {
	    }

		public static SoftmarkApiConfiguration Instance => InternalSoftmarkApiConfiguration.Instance;

	    private class InternalSoftmarkApiConfiguration
        {
			static InternalSoftmarkApiConfiguration() { }
			internal static  readonly SoftmarkApiConfiguration Instance = new SoftmarkApiConfiguration();
		}


	    public HttpConfiguration Configuration => _config.Value;

		public bool EnableLog { get; private set; }

        private static HttpConfiguration Register()
        {
			var config = new HttpConfiguration();

            config.MapHttpAttributeRoutes(new DefaultInlineConstraintResolver()
            {
            });

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            config
             .EnableSwagger(c => c.SingleApiVersion("v1", "KMN"))
             .EnableSwaggerUi();

            config.Formatters.Clear();
            config.Formatters.Add(new JsonMediaTypeFormatter());

            WebApiConfig.Register(config);

            return config;
        }

        public SoftmarkApiConfiguration UseDependencyResolver(IDependencyResolver resolver)
        {
            Configuration.DependencyResolver=resolver;
            return this;
        }
    }
}