﻿using System.Collections.Generic;
using System.Reflection;
using System.Web.Http.Dependencies;
using Autofac;
using Autofac.Integration.WebApi;
using Module = Autofac.Module;

namespace Softmark.IoC
{
    /// <summary>
    /// Implement your Dependency Resolver with any IoC framework
    /// </summary>
    public class AutoFacIoCBuilder
    {
        public IDependencyResolver BuildContainer(IEnumerable<Module> modules)
        {
            var containerBuilder = new ContainerBuilder();
            containerBuilder.RegisterApiControllers(Assembly.GetExecutingAssembly()).InstancePerRequest();

            if (modules != null)
            {
                foreach (var module in modules)
                {
                    containerBuilder.RegisterModule(module);
                }
            }
            var container = containerBuilder.Build();
            return new AutofacWebApiDependencyResolver(container);
        }
    }
}