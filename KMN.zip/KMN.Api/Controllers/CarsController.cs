﻿using KMN.Api.Models;
using KMN.Domain.Result;
using KMN.Service.Contract;
using Softmark.Shared.Api;
using Softmark.Shared.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;

namespace KMN.Api.Controllers
{
    [RoutePrefix("api/cars")]
    public class CarsController : ApiController
    {
        private readonly ISystemEntitiesService _service;
        public CarsController(ISystemEntitiesService service)
        {
            _service = service;
        }

        public static readonly Func<IEnumerable<GetCarDataInfoResult>, Models.CarResultModel[]> _carResultList = (serv) =>
        {
            var contacts = new List<CarResultModel>();

            if (serv == null) return null;

            foreach (var c in serv)
            {
                contacts.Add(_carResult(c));
            }

            return contacts.ToArray();
        };


        public static readonly Func<GetCarDataInfoResult, CarResultModel> _carResult = (serv) =>
        {
            if (serv == null) return null;
            return new CarResultModel()
            {
                CarDataId =  serv.CarDataId,
                CarCode =  serv.CarCode,
                Make = serv.Make,
                Year = serv.Year,
                ModelYear =  serv.ModelYear
            };
        };


        [HttpGet]
        [Route]
        public async Task<ApiResultModel<CarResultModel[]>> GetAllCars()
        {
            var result = await _service.GetAllCars().ConfigureAwait(false);

            return result.Map(_carResultList);
        }

        [HttpGet]
        [Route("{carId:guid}")]
        public async Task<ApiResultModel<CarResultModel>> GetCarById(Guid carId)
        {
            var response = new ServiceResult<CarResultModel>();
            if (carId == null )
            {
                response.AddError("Bad request, invalid request parameters (carId)",
                    "Bad request, invalid request parameters (carId)");

                return response.Map();
            }

            var result = await _service.GetCarsById (carId).ConfigureAwait(false);

            return result.Map(_carResult);
        }

        [HttpGet]
        [Route("byCode/{carCode}")]
        public async Task<ApiResultModel<CarResultModel>> GetCarsByCarCode(string carCode)
        {
            var response = new ServiceResult<CarResultModel>();
            if (carCode == null || string.IsNullOrWhiteSpace(carCode))
            {
                response.AddError("Bad request, invalid request parameters (carCode)",
                    "Bad request, invalid request parameters (carCode)");

                return response.Map();
            }

            var result = await _service.GetCarsByCarCode(carCode).ConfigureAwait(false);

            return result.Map(_carResult);
        }

        [HttpGet]
        [Route("Group")]
        public async Task<ApiResultModel<CarResultModel[]>> GetCarsByGroup()
        {
            var response = new ServiceResult<CarResultModel[]>();

            var result = await _service.GetCarsByGroup().ConfigureAwait(false);

            return result.Map(_carResultList);
        }


        [HttpGet]
        [Route("byMake/{make}")]
        public async Task<ApiResultModel<CarResultModel[]>> GetCarsByMake(string make)
        {
            var response = new ServiceResult<CarResultModel[]>();
            if (make == null || string.IsNullOrWhiteSpace(make))
            {
                response.AddError("Bad request, invalid request parameters (make)",
                    "Bad request, invalid request parameters (make)");

                return response.Map();
            }

            var result = await _service.GetCarsByMake(make).ConfigureAwait(false);

            return result.Map(_carResultList);
        }

        [HttpGet]
        [Route("{make}/{year:int}")]
        public async Task<ApiResultModel<CarResultModel[]>> GetCarsByMakeYear(string make, string year)
        {
            var response = new ServiceResult<CarResultModel[]>();
            if (make == null || string.IsNullOrWhiteSpace(make))
            {
                response.AddError("Bad request, invalid request parameters (make, year)",
                    "Bad request, invalid request parameters (make, year)");

                return response.Map();
            }

            if (year == null || string.IsNullOrWhiteSpace(year))
            {
                response.AddError("Bad request, invalid request parameters (make, year)",
                    "Bad request, invalid request parameters (make, year)");

                return response.Map();
            }

            var result = await _service.GetCarsByMakeYear(make,year).ConfigureAwait(false);

            return result.Map(_carResultList);
        }

        [HttpGet]
        [Route("byModelYear/{modelYear}")]
        public async Task<ApiResultModel<CarResultModel[]>> GetCarsByModelYear(string modelYear)
        {
            var response = new ServiceResult<CarResultModel[]>();
            if (modelYear == null || string.IsNullOrWhiteSpace(modelYear))
            {
                response.AddError("Bad request, invalid request parameters (modelYear)",
                    "Bad request, invalid request parameters (make)");

                return response.Map();
            }

            var result = await _service.GetCarsByMake(modelYear).ConfigureAwait(false);

            return result.Map(_carResultList);
        }

        private ServiceResult<TResult> ValidateSendTokenRequest<TResult>(NotificationRequestModel request)
        {
            var response = new ServiceResult<TResult>();
            if (request == null || string.IsNullOrWhiteSpace(request.RecipientId) ||
                 request.NotificationType == NotificationType.None )
            {
                response.AddError("Bad request, invalid request parameters (RecipientId, NotificationType)",
                    "Bad request, invalid request parameters (RecipientId, NotificationType)");

                return response;
            }

            return response;
        }
    }
}
