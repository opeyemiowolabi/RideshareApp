﻿using KMN.Api.Models;
using KMN.Domain.Entities;
using KMN.Domain.Result;
using KMN.Service.Contract;
using Softmark.Shared.Api;
using Softmark.Shared.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using Softmark.Shared.Domain.Utilities;
using System;
using System.Collections.Generic;
using System.Data.Entity.Spatial;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace KMN.Api.Controllers
{
    [RoutePrefix("api/subscription")]
    public class SubscriptionController : ApiController
    {
        private readonly ISubscriptionService _service;
        private readonly IGeoHelper _geolocation;
        public SubscriptionController(ISubscriptionService service, IGeoHelper geolocation)
        {
            _service = service;
            _geolocation = geolocation;
        }

        public static readonly Func<AddSubscriptionInfoResult, SubscrptionResponseModel> _addRiderMapper = (serv) =>
        {
            if (serv == null) return null;
            return new SubscrptionResponseModel()
            {
                SubscriptionId = serv.SubscriptionId,
            };
        };

        public static readonly Func<IEnumerable<SubscriberInforesult>, SubscriberResultModel[]> _getSubscribersMapper = (serv) =>
        {
            var subscribers = new List<SubscriberResultModel>();

            if (serv == null) return null;

            foreach (var sub in serv)
            {
                subscribers.Add(
                     new SubscriberResultModel
                     {
                         SubscriberId = sub.SubscriberId,
                         SubscriptionId = sub.SubscriptionId,
                         PassengerNames = sub.PassengerNames ,
                         PassengerEmail = sub.PassengerEmail ,
                         PassengerPhone = sub.PassengerPhone ,
                         PassengerRouteId = sub.PassengerRouteId,
                         AgreedFare = sub.AgreedFare,
                         DriverApproval = sub.DriverApproval,
                         PassengerApproval = sub.PassengerApproval,
                         Notes = sub.Notes
                     }
                   );
            }

            return subscribers.ToArray();
        };

        public static readonly Func<IEnumerable<DriverSubscriptionInfoResult>, GetDriverSubscriptionResultModel[]> _getDriverSubscriptionMapper = (serv) =>
        {
            var subscriptionList = new List<GetDriverSubscriptionResultModel>();

            if (serv == null) return null;

            foreach (var subscript in serv)
            {
                subscriptionList.Add(
                     new GetDriverSubscriptionResultModel
                     {
                         SubscriptionId = subscript.SubscriptionId,
                         RiderId = subscript.RiderId,
                         DriverNames = subscript.DriverNames,
                         DriverEmail = subscript.DriverEmail,
                         DriverPhone = subscript.DriverPhone,
                         VehicleId = subscript.VehicleId,
                         PickupLocation = GeoLocation.Get(subscript.PickupLocation),
                         DropOffLocation = GeoLocation.Get(subscript.DropOffLocation),
                         EstimatedPickupDateTime = subscript.EstimatedPickupDateTime,
                         EstimatedDroppOffDateTime = subscript.EstimatedDroppOffDateTime,
                         MaxPassengerAllowed = subscript.MaxPassengerAllowed,
                         BaseFare = subscript.BaseFare,
                         RequestStatus = subscript.RequestStatus,
                         Notes = subscript.Notes,
                         Subscribers = _getSubscribersMapper(subscript.Subscribers)
                     }
                   );
            }

            return subscriptionList.ToArray();
        };

        public static readonly Func<IEnumerable<PassengerRouteInforesult>, GetPassengerRouteResultModel[]> _getPassengersMapper = (serv) =>
        {
            var passengers = new List<GetPassengerRouteResultModel>();

            if (serv == null) return null;

            foreach (var db in serv)
            {
                passengers.Add(
                     new GetPassengerRouteResultModel
                     {
                         PassengerRouteId = db.PassengerRouteId
                        ,RiderId = db.RiderId
                        , PassengerNames = db.PassengerNames
                        , PassengerEmail = db.PassengerEmail
                        , PassengerPhone = db.PassengerPhone
                        , PickupLocation = GeoLocation.Get(db.PickupLocation)
                        , DropOffLocation = GeoLocation.Get(db.DropOffLocation)
                        , EstimatedPickupDateTime = db.EstimatedPickupDateTime
                        ,RequestStatus = db.DriverApproval
                       // ,RiderType = db.RiderType
                        , BaseFare = db.BaseFare
                        , Notes = db.Notes
                     }
                   );
            }

            return passengers.ToArray();
        };

        public static readonly Func<DriverJoinRequestInforesult, DriverJoinRequestResultModel> _driverJoinMapper = (serv) =>
        {
            if (serv == null) return null;
            return new DriverJoinRequestResultModel()
            {
                SubscriptionId = serv.SubscriptionId,
                SubscriberId = serv.SubscriberId,
                PassengerRouteId =  serv.PassengerRouteId 
            };
        };

        [HttpPost]
        [Route("register")]
        public async Task<ApiResultModel<SubscrptionResponseModel>> CreateSubscription(SubscriptionRequestModel request)
        {
            var validationResult = ValidateSubscriptionRequest<SubscrptionResponseModel>(request);
            if (validationResult.HasErrors) return validationResult.Map();

            if (request.RiderType == EntityRiderType.Driver) // Driver
            {
               var sub = Subscription.CreateNew(
               request.RiderId,
               request.VehicleId,
               _geolocation.Location(request.PickupLocation),
               _geolocation.Location(request.DropOffLocation),
               request.EstimatedPickupDateTime,
               request.EstimatedDroppOffDateTime,
               request.MaxPassengerAllowed,
               request.RiderType,
               request.BaseFare,
               EntityRequestStatus.Pending,
               request.Notes,
               null
               );

                var response = await _service.AddSubscriptionAsync(sub).ConfigureAwait(false);
                return response.Map(_addRiderMapper);
            }
            else // Passenger
            {
                var sub = PassengerRoute.CreateNew(
               request.RiderId,
               _geolocation.Location(request.PickupLocation),
               _geolocation.Location(request.PickupLocation),
               request.EstimatedPickupDateTime,
               request.RiderType,
               request.BaseFare,
               EntityRequestStatus.Pending,
               request.Notes
               );

               var response = await _service.AddSubscriptionAsync(sub).ConfigureAwait(false);
                return response.Map(_addRiderMapper);
            }
        }

        [HttpPost]
        [Route("getDriverSubscriptions")]
        public async Task<ApiResultModel<GetDriverSubscriptionResultModel[]>> GetDriverSubscription(GetSubscriptionRequestModel request)
        {
            var pickup = _geolocation.Location(request.PickupLocation);
            var dropOff = _geolocation.Location(request.DropOffLocation);

            var response = await _service.GetDriverSubscriptionListAsync(pickup, dropOff, request.Kilometers, request.SubscriptionStatus).ConfigureAwait(false);
            return response.Map(_getDriverSubscriptionMapper);
        }

        [HttpPost]
        [Route("getPassengerSubscriptions")]
        public async Task<ApiResultModel<GetPassengerRouteResultModel[]>> GetPassengerSubscription(GetSubscriptionRequestModel request)
        {
            var pickup = _geolocation.Location(request.PickupLocation);
            var dropOff = _geolocation.Location(request.DropOffLocation);

            var response = await _service.GetPassengerSubscriptionListAsync(pickup, dropOff, request.Kilometers, request.SubscriptionStatus).ConfigureAwait(false);
            return response.Map(_getPassengersMapper);
        }

        [HttpPost]
        [Route("driverJoinRequest")]
        public async Task<ApiResultModel<DriverJoinRequestResultModel>> DriverJoinRequest(DriverJoinRequestRequestModel request)
        {
            //rename to JoinRequest ..add extra parameter to specify passenger or driver

            //or leave as is so we can automatically create 

            var response = await _service.DriverJoinRequestAsync(request.SubscriptionId , request.PassengerRouteId).ConfigureAwait(false);
            return response.Map(_driverJoinMapper);
        }

        private ServiceResult<TResult> ValidateSubscriptionRequest<TResult>(SubscriptionRequestModel request)
        {
            var response = new ServiceResult<TResult>();
            //if (request == null || string.IsNullOrWhiteSpace(request.RecipientId) ||
            //     request.RiderType == EntityRequestStatus.Canclled)
            //{
            //    response.AddError("Bad request, invalid request parameters (RecipientId, NotificationType)",
            //        "Bad request, invalid request parameters (RecipientId, NotificationType)");
            //    return response;
            //}

            return response;
        }

    }
}
