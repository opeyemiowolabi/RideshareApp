﻿using KMN.Api.Models;
using KMN.Service.Outbound.Notification;
using Softmark.Shared.Api;
using Softmark.Shared.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using System;
using System.Threading.Tasks;
using System.Web.Http;

namespace KMN.Api.Controllers
{
    [RoutePrefix("api/notification")]
    public class NotificationController : ApiController
    {
        private readonly INotification _service;
        public NotificationController(INotification service)
        {
            _service = service;
        }

        public static readonly Func<NotificationResponse, NotificationResponseModel> _addMapper = (serv) =>
        {
            if (serv == null) return null;
            return new NotificationResponseModel()
            {
                MessageId = serv.MessageId,
            };
        };

        [HttpPost]
        [Route("sendToken")]
        public async Task<ApiResultModel<NotificationResponseModel>> SendToken(NotificationRequestModel request)
        {
            var validationResult = ValidateSendTokenRequest<NotificationResponseModel>(request);
            if (validationResult.HasErrors) return validationResult.Map();

            var notify = new NotificationRequest()
            {
                MessageBody =  request.MessageBody,
                MessageTitle =  request.MessageTitle,
                NotificationType =  request.NotificationType,
                RecipientId =  request.RecipientId
            };

            var response = await _service.SendToken(notify).ConfigureAwait(false);
            return response.Map(_addMapper);
        }

        [HttpPost]
        [Route("validateToken")]
        public async Task<ApiResultModel<bool>> ValidateToken(NotificationRequestModel request)
        {
            var validationResult = ValidateTokenValidateRequest<bool>(request);
              if (validationResult.HasErrors) return validationResult.Map();

            var notify = new NotificationRequest()
            {
                MessageBody = request.MessageBody,
                RecipientId = request.RecipientId
            };

            var response = await _service.ValidateToken(notify).ConfigureAwait(false);
            return response.Map();
        }

        [HttpPost]
        [Route("sendNotification")]
        public async Task<ApiResultModel<NotificationResponseModel>> SendNotification(NotificationRequestModel request)
        {
            var validationResult = ValidateSendNotificationRequest<NotificationResponseModel>(request);
              if (validationResult.HasErrors) return validationResult.Map();

            var notify = new NotificationRequest()
            {
                NotificationType = request.NotificationType,
                RecipientId = request.RecipientId,
                MessageBody =  request.MessageBody,
                MessageTitle =  request.MessageTitle 
            };

            var response = await _service.SendNotification(notify).ConfigureAwait(false);
            return response.Map(_addMapper);
        }

        //[HttpGet]
        //[Route("getToken")]
        //public async Task<ApiResultModel<NotificationResponseModel>> GetToken()
        //{
        //    NotificationRequestModel request = new NotificationRequestModel()
        //    {

        //    };

        //    var validationResult = ValidateSendTokenRequest<NotificationResponseModel>(request);

        //    validationResult.ErrorMessages.Add(new ValidationMessage("Bad request, invalid request parameters (RecipientId, NotificationType)"
        //         , "Bad request, invalid request parameters (RecipientId, NotificationType)", ValidationMessageType.Error));

        //    if (validationResult.HasErrors) return validationResult.Map();
        //    var notify = new NotificationRequest()
        //    {
        //        //MessageBody = request.MessageBody,
        //        MessageTitle = "KMN (OTP)",
        //        NotificationType = NotificationType.Email,
        //        RecipientId = "owolabi.j.opeyemi@gmail.com"//"owolabi.j.opeyemi@gmail.com"  2347036605597
        //    };

        //    var response = await _service.SendToken(notify).ConfigureAwait(false);
        //    return response.Map(_addMapper);
        //}

        private ServiceResult<TResult> ValidateSendTokenRequest<TResult>(NotificationRequestModel request)
        {
            var response = new ServiceResult<TResult>();
            if (request == null || string.IsNullOrWhiteSpace(request.RecipientId) ||
                 request.NotificationType == NotificationType.None )
            {
                response.AddError("Bad request, invalid request parameters (RecipientId, NotificationType)",
                    "Bad request, invalid request parameters (RecipientId, NotificationType)");

                return response;
            }

            return response;
        }

        private ServiceResult<TResult> ValidateTokenValidateRequest<TResult>(NotificationRequestModel request)
        {
            var response = new ServiceResult<TResult>();
            if (request == null || string.IsNullOrWhiteSpace(request.RecipientId) ||
                 string.IsNullOrWhiteSpace(request.MessageBody))
            {
                response.AddError("Bad request, invalid request parameters (RecipientId, MessageBody)",
                    "Bad request, invalid request parameters (RecipientId, MessageBody)");
                return response;
            }

            return response;
        }

        private ServiceResult<TResult> ValidateSendNotificationRequest<TResult>(NotificationRequestModel request)
        {
            var response = new ServiceResult<TResult>();
            if (request == null || string.IsNullOrWhiteSpace(request.RecipientId) ||
                 request.NotificationType == NotificationType.None)
            {
                response.AddError("Bad request, invalid request parameters (RecipientId, NotificationType)",
                    "Bad request, invalid request parameters (RecipientId, NotificationType)");
                return response;
            }

            return response;
        }

    }
}
