﻿using KMN.Api.Models;
using KMN.Domain.Entities;
using KMN.Domain.Result;
using KMN.Service.Contract;
using Softmark.Shared.Api;
using Softmark.Shared.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using Softmark.Shared.Domain.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace KMN.Api.Controllers
{
    [RoutePrefix("api/rider")]
    public class RiderController : ApiController
    {
        private readonly IRiderService _service;
        private readonly ISubscriptionService _subservice;
        private readonly IGeoHelper _geolocation;
        public RiderController(IRiderService service, ISubscriptionService subservice, IGeoHelper geolocation)
        {
            _service = service;
            _subservice = subservice;
            _geolocation = geolocation;
        }

        public static readonly Func<AddRiderInfoResult, RiderResponseModel> _addRiderMapper = (serv) =>
        {
            if (serv == null) return null;
            return new RiderResponseModel()
            {
                TransactionId = serv.TransactionId ,
                RiderId = serv.RiderId ,
                RiderNumber = serv.RiderNumber,
                Contacts = serv.Contacts,
                VehicleInfoIds = serv.VehicleInfoIds 
            };
        };

        public static readonly Func<Models.RiderContactRequestModel[] , IEnumerable<Domain.Entities.RiderContact>> _riderContactsRequest = (serv) =>
       {
          var contacts = new List<Domain.Entities.RiderContact>();

           if (serv == null) return null;
           
           foreach (var c in serv)
           {
               contacts.Add(
                    new Domain.Entities.RiderContact
                    {
                        ContactId  = c.ContactId,
                        RiderId  =  c.RiderId,
                        Address  = c.Address,
                        CityOrLGA =  c.CityOrLGA,
                        State =  c.State,
                        PrimaryPhoneNo =  c.PrimaryPhoneNo,
                        SecondaryPhoneNo =  c.SecondaryPhoneNo,
                        Email =  c.Email,
                        EmergencyContactName =  c.EmergencyContactName,
                        EmergencyPhoneNumber =  c.EmergencyPhoneNumber 
                    }
                  );
           }

           return contacts;
       };

        public static readonly Func<Models.RiderContactCreateRequestModel[], IEnumerable<Domain.Entities.RiderContact>> _riderContactsCreateRequest = (serv) =>
        {
            var contacts = new List<Domain.Entities.RiderContact>();

            if (serv == null) return null;

            foreach (var c in serv)
            {
                contacts.Add(
                     new Domain.Entities.RiderContact
                     {
                         Address = c.Address,
                         CityOrLGA = c.CityOrLGA,
                         State = c.State,
                         PrimaryPhoneNo = c.PrimaryPhoneNo,
                         SecondaryPhoneNo = c.SecondaryPhoneNo,
                         Email = c.Email,
                         EmergencyContactName = c.EmergencyContactName,
                         EmergencyPhoneNumber = c.EmergencyPhoneNumber
                     }
                   );
            }

            return contacts;
        };

        public static readonly Func<IEnumerable<UpdateRiderContactInfoResult>, Models.RiderContactResponseModel[]> _riderContactsResponse = (serv) =>
        {
            var contacts = new List<RiderContactResponseModel>();

            if (serv == null) return null;

            foreach (var c in serv)
            {
                contacts.Add(
                     new RiderContactResponseModel
                     {
                         ContactId = c.ContactId,
                         RiderId = c.RiderId,
                         IsUpdated = c.IsUpdated,
                         TransactionId = c.TransactionId
                     }
                   );
            }

            return contacts.ToArray();
        };

        public static readonly Func<IEnumerable<RiderContactInfoResult>, Models.RiderContactRequestModel[]> _riderContactsResult = (serv) =>
        {
            var contacts = new List<RiderContactRequestModel>();

            if (serv == null) return null;

            foreach (var c in serv)
            {
                contacts.Add(
                     new RiderContactRequestModel
                     {
                         ContactId = c.ContactId,
                         RiderId = c.RiderId,
                         Address = c.Address,
                         CityOrLGA = c.CityOrLGA,
                         State = c.State,
                         PrimaryPhoneNo = c.PrimaryPhoneNo,
                         SecondaryPhoneNo = c.SecondaryPhoneNo,
                         Email = c.Email,
                         EmergencyContactName = c.EmergencyContactName,
                         EmergencyPhoneNumber = c.EmergencyPhoneNumber
                     }
                   );
            }

            return contacts.ToArray();
        };

        public static readonly Func<Models.VehicleInformationRequestModel[], IEnumerable<Domain.Entities.VehicleInformation>> _riderVehicleInfoRequest = (serv) =>
        {
            var vehicleInfo = new List<Domain.Entities.VehicleInformation> ();

            if (serv == null) return null;

            foreach (var c in serv)
            {
                vehicleInfo.Add(
                     new Domain.Entities.VehicleInformation 
                     {
                         VehicleInformationId = c.VehicleInformationId,
                         RiderId = c.RiderId,
                         NumberOfPassenger = c.NumberOfPassenger,
                         PlateNumber = c.PlateNumber,
                         ChasisNumber =  c.ChasisNumber 
                     }
                    );
            }

            return vehicleInfo;
        };

        public static readonly Func<Models.VehicleInformationCreateRequestModel[], IEnumerable<Domain.Entities.VehicleInformation>> _riderVehicleInfoCreateRequest = (serv) =>
        {
            var vehicleInfo = new List<Domain.Entities.VehicleInformation>();

            if (serv == null) return null;

            foreach (var c in serv)
            {
                vehicleInfo.Add(
                     new Domain.Entities.VehicleInformation
                     {
                         NumberOfPassenger = c.NumberOfPassenger,
                         PlateNumber = c.PlateNumber,
                         ChasisNumber = c.ChasisNumber
                     }
                    );
            }

            return vehicleInfo;
        };

        public static readonly Func<IEnumerable<RiderVehicleInfoResult>, Models.VehicleInformationRequestModel[]> _riderVehiclesResult = (serv) =>
        {
            var vehicles = new List<VehicleInformationRequestModel>();

            if (serv == null) return null;

            foreach (var c in serv)
            {
                vehicles.Add(
                     new VehicleInformationRequestModel
                     {
                         VehicleInformationId = c.VehicleInformationId ,
                         RiderId = c.RiderId,
                         CarDataId =  c.CarDataId,
                         CarCode = c.CarCode,
                         NumberOfPassenger = c.NumberOfPassenger,
                         PlateNumber = c.PlateNumber,
                         ChasisNumber = c.ChasisNumber,
                         Make =  c.Make,
                         Year =  c.Year,
                         ModelYear = c.ModelYear,
                     }
                   );
            }

            return vehicles.ToArray();
        };

        public static readonly Func<GetRiderInfoResult, RiderResultModel> _riderResult = (serv) =>
        {
            if (serv == null) return null;

            return new RiderResultModel
            {
                UserName = serv.UserName,
                RiderNumber = serv.RiderNumber,
                FirstName = serv.FirstName,
                MiddleName = serv.MiddleName,
                LastName = serv.LastName,
                Email = serv.Email,
                PrimaryPhoneNumber = serv.PrimaryPhoneNumber,
                SecondaryPhoneNumber = serv.SecondaryPhoneNumber,
                Occupation = serv.Occupation,
                Notes = serv.Notes,
                Contacts = _riderContactsResult(serv.Contacts),
                Vehicles = _riderVehiclesResult (serv.Vehicles)
            };
           
        };

        public static readonly Func<IEnumerable<GetRiderInfoResult>, RiderResultModel[]> _riderResultList = (serv) =>
        {
            var riderList = new List<RiderResultModel>();

            if (serv == null) return null;

            foreach (var c in serv)
            {
                riderList.Add(
                     new RiderResultModel
                     {
                         UserName = c.UserName,
                         RiderNumber = c.RiderNumber,
                         FirstName = c.FirstName,
                         MiddleName = c.MiddleName,
                         LastName = c.LastName,
                         Email = c.Email,
                         PrimaryPhoneNumber = c.PrimaryPhoneNumber,
                         SecondaryPhoneNumber = c.SecondaryPhoneNumber,
                         Occupation = c.Occupation,
                         Notes = c.Notes,
                         Contacts = _riderContactsResult(c.Contacts),
                         Vehicles = _riderVehiclesResult(c.Vehicles)
                     }
                   );
            }

            return riderList.ToArray();
        };

        [HttpPost]
        [AllowAnonymous]
        [Route("register")]
        public async Task<ApiResultModel<RiderResponseModel>> CreateRider(RiderRequestModel request)
        {
            var validationResult = ValidateCreateRider<RiderResponseModel>(request);
             if (validationResult.HasErrors) return validationResult.Map();

            var newRider = Rider.CreateNew(
                  request.RiderNumber  
                , request.UserName 
                , request.Password 
                , request.ConfirmPassword 
                , request.FirstName
                , request.MiddleName
                , request.LastName
                , request.DateOfBirth
                , request.Gender
                ,request.Email 
                , request.PrimaryPhoneNumber
                , request.SecondaryPhoneNumber 
                , SoftUtil.GetGuid()
                , SoftUtil.GetGuid()
                , request.Occupation
                , request.Notes
                , DateTime.Now
                , DateTime.Now
                , _riderContactsCreateRequest(request.Contacts)
                , _riderVehicleInfoCreateRequest(request.VehicleInfo )
                );

            var result = await _service.AddRiderAsync(newRider).ConfigureAwait(false);
            var subRequest = new SubscriptionRequestModel();
            if (result.Result != null)
            {
                subRequest.BaseFare = request.SubscriptionInfo.BaseFare;
                subRequest.PickupLocation = request.SubscriptionInfo.PickupLocation;
                subRequest.DropOffLocation = request.SubscriptionInfo.DropOffLocation;
                subRequest.RiderType = request.SubscriptionInfo.RiderType;
                subRequest.VehicleId = result.Result.VehicleInfoIds.FirstOrDefault();
                subRequest.RiderId = newRider.RiderId;
                subRequest.EstimatedPickupDateTime = request.SubscriptionInfo.EstimatedPickupDateTime;
                subRequest.EstimatedDroppOffDateTime = request.SubscriptionInfo.EstimatedDroppOffDateTime;
                subRequest.MaxPassengerAllowed = request.SubscriptionInfo.MaxPassengerAllowed;
                subRequest.Notes = request.SubscriptionInfo.Notes;
            }
                
            var sub = await ProcessSubscription(subRequest).ConfigureAwait(false);

            var response = result.Map(_addRiderMapper);

            if (sub.Result != null)
                response.Result.SubscriptionId = sub.Result.SubscriptionId;

            return response;
        }

        [HttpPut]
        [Route("updateContact")]
        public async Task<ApiResultModel<RiderContactResponseModel[]>> UpdateRiderContact(RiderContactRequestModel[] requests)
        {
            var result = await _service.UpdateRiderContactAsync(_riderContactsRequest(requests)).ConfigureAwait(false);
            return result.Map(_riderContactsResponse);
        }

        [HttpPost]
        [Route("addContact")]
        public async Task<ApiResultModel<RiderContactResponseModel[]>> AddRiderContact(RiderContactRequestModel[] requests)
        {
            var result = await _service.AddRiderContactAsync(_riderContactsRequest(requests)).ConfigureAwait(false);
            return result.Map(_riderContactsResponse);
        }

        [HttpGet]
        [Route("riderByStatus/{status}")]
        public async Task<ApiResultModel<RiderResultModel[]>> GetRiderByStatus(EntityStatus? status)
        {
            if (status == null )
            {
                status = EntityStatus.Active;
            }

           var result = await _service.GetAllRidersAsync(status).ConfigureAwait(false);

           return  result.Map(_riderResultList);
        }

        [HttpGet]
        [Route("riderById/{riderId:guid}")]
        public async Task<ApiResultModel<RiderResultModel>> GetRiderById(Guid riderId)
        {
            var response = new ServiceResult<RiderResultModel>();
            if (riderId == null )
            {
                response.AddError("Bad request, invalid request parameters (riderId)",
                    "Bad request, invalid request parameters (riderId)");

                return response.Map();
            }

            var result = await _service.GetRiderByIdAsync(riderId).ConfigureAwait(false);

            return result.Map(_riderResult);
        }

        [HttpGet]
        [Route("riderByEmail/{email:length(3,40)}")]
        public async Task<ApiResultModel<RiderResultModel>> GetRiderByEmail(string email)
        {
            var response = new ServiceResult<RiderResultModel>();
            if (email == null || string.IsNullOrWhiteSpace(email))
            {
                response.AddError("Bad request, invalid request parameters (Email)",
                    "Bad request, invalid request parameters (Email)");

                return response.Map();
            }

            var result = await _service.GetRiderByEmailAsync(email).ConfigureAwait(false);

            return result.Map(_riderResult);
        }

        private ServiceResult<TResult> ValidateCreateRiderRequest<TResult>(RiderRequestModel request)
        {
            var response = new ServiceResult<TResult>();
            if (request == null || string.IsNullOrWhiteSpace(request.Email ) ||
                string.IsNullOrWhiteSpace(request.RiderNumber))
            {
                response.AddError("Bad request, invalid request parameters (Email, RiderNumber)",
                    "Bad request, invalid request parameters (Email, RiderNumber)");
                return response;
            }

            return response;
        }

        private ServiceResult<TResult> ValidateCreateRider<TResult>(RiderRequestModel request)
        {
            var response = new ServiceResult<TResult>();
            if (request == null || string.IsNullOrWhiteSpace(request.Email ) ||
                 string.IsNullOrWhiteSpace(request.UserName))
            {
                response.AddError("Bad request, invalid request parameters (Username, Password, ConfirmPassword, Email)",
                    "Bad request, invalid request parameters (Username, Password, ConfirmPassword, Email)");

                return response;
            }

            if (request == null || string.IsNullOrWhiteSpace(request.Password ) ||
                 string.IsNullOrWhiteSpace(request.ConfirmPassword))
            {
                response.AddError("Bad request, invalid request parameters (Password is required)",
                    "Bad request, invalid request parameters (RecipientId, NotificationType)");

                return response;
            }

            if (request == null || request.Password != request.ConfirmPassword)
            {
                response.AddError("Bad request, invalid request parameters (Password and ConfirmPassword must be same"," invalid request parameters (RecipientId, NotificationType)");

                return response;
            }

            return response;
        }

        private async Task<ServiceResult<AddSubscriptionInfoResult>> ProcessSubscription(SubscriptionRequestModel request)
        {
            var validationResult = ValidateSubscriptionRequest<AddSubscriptionInfoResult>(request);
            if (validationResult.HasErrors) return validationResult;

            if (request.RiderType == EntityRiderType.Driver) // Driver
            {
                var sub = Subscription.CreateNew(
                request.RiderId,
                request.VehicleId,
                _geolocation.Location(request.PickupLocation),
                _geolocation.Location(request.PickupLocation),
                request.EstimatedPickupDateTime,
                request.EstimatedDroppOffDateTime,
                request.MaxPassengerAllowed,
                request.RiderType,
                request.BaseFare,
                EntityRequestStatus.Pending,
                request.Notes,
                null
                );

                var response = await _subservice.AddSubscriptionAsync(sub).ConfigureAwait(false);
                return response;//.Map(_addMapper);
            }
            else // Passenger
            {
                var sub = PassengerRoute.CreateNew(
               request.RiderId,
               _geolocation.Location(request.PickupLocation),
               _geolocation.Location(request.PickupLocation),
               request.EstimatedPickupDateTime,
               request.RiderType,
               request.BaseFare,
               EntityRequestStatus.Pending,
               request.Notes
               );

                var response = await _subservice.AddSubscriptionAsync(sub).ConfigureAwait(false);
                return response;//.Map(_addMapper);
            }
        }

        private ServiceResult<TResult> ValidateSubscriptionRequest<TResult>(SubscriptionRequestModel request)
        {
            var response = new ServiceResult<TResult>();
            //if (request == null || string.IsNullOrWhiteSpace(request.RecipientId) ||
            //     request.RiderType == EntityRequestStatus.Canclled)
            //{
            //    response.AddError("Bad request, invalid request parameters (RecipientId, NotificationType)",
            //        "Bad request, invalid request parameters (RecipientId, NotificationType)");
            //    return response;
            //}

            return response;
        }
    }
}
