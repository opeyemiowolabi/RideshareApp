﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KMN.Api.Models
{
    public class CarRequestModel
    {
      
    }

    public class CarResultModel
    {
        [JsonProperty("carDataId")]
        public Guid CarDataId { get; set; }

        [JsonProperty("carCode")]
        public string CarCode { get; set; }

        [JsonProperty("make")]
        public string Make { get; set; }

        [JsonProperty("year")]
        public string Year { get; set; }

        [JsonProperty("modelYear")]
        public string ModelYear { get; set; }

    }
}