﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Softmark.Shared.Domain.Enum;
using Softmark.Shared.Domain.Utilities;
using System;
using System.Collections.Generic;
using System.Data.Entity.Spatial;

namespace KMN.Api.Models
{
    public class SubscriptionRequestModel : SubscriptionRequestModelBase
    {
        [JsonProperty("pickupLocation")]
        public GeoLocation PickupLocation { get; set; }

        [JsonProperty("dropOffLocation")]
        public GeoLocation DropOffLocation { get; set; }

        [JsonProperty("estimatedPickupDateTime")]
        public DateTime EstimatedPickupDateTime { get; set; }

        [JsonProperty("estimatedDroppOffDateTime")]
        public DateTime EstimatedDroppOffDateTime { get; set; }

        [JsonProperty("maxPassengerAllowed")]
        public int MaxPassengerAllowed { get; set; }

        [JsonProperty("riderType")]
        [JsonConverter(typeof(StringEnumConverter))]
        public EntityRiderType RiderType { get; set; }

        [JsonProperty("baseFare")]
        public decimal BaseFare { get; set; }

        [JsonProperty("notes")]
        public string Notes { get; set; }
    }

    public class RiderSubscriptionRequestModel 
    {
        [JsonProperty("pickupLocation")]
        public GeoLocation PickupLocation { get; set; }

        [JsonProperty("dropOffLocation")]
        public GeoLocation DropOffLocation { get; set; }

        [JsonProperty("estimatedPickupDateTime")]
        public DateTime EstimatedPickupDateTime { get; set; }

        [JsonProperty("estimatedDroppOffDateTime")]
        public DateTime EstimatedDroppOffDateTime { get; set; }

        [JsonProperty("maxPassengerAllowed")]
        public int MaxPassengerAllowed { get; set; }

        [JsonProperty("riderType")]
        [JsonConverter(typeof(StringEnumConverter))]
        public EntityRiderType RiderType { get; set; }

        [JsonProperty("baseFare")]
        public decimal BaseFare { get; set; }

        [JsonProperty("notes")]
        public string Notes { get; set; }
    }

    public abstract class SubscriptionRequestModelBase
    {
        [JsonProperty("subscriptionId")]
        public Guid SubscriptionId { get; set; }

        [JsonProperty("riderId")]
        public Guid RiderId { get; set; }

        [JsonProperty("vehicleId")]
        public Guid VehicleId { get; set; }
    }

        public class SubscrptionResponseModel
    {
        [JsonProperty("subscriptionId")]
        public Guid SubscriptionId { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }
    }

    public class GetSubscriptionRequestModel
    {
        [JsonProperty("pickupLocation")]
        public GeoLocation PickupLocation { get; set; }

        [JsonProperty("dropOffLocation")]
        public GeoLocation DropOffLocation { get; set; }

        [JsonProperty("kilometers")]
        public double Kilometers { get; set; }

        [JsonProperty("subscriptionStatus")]
        [JsonConverter(typeof(StringEnumConverter))]
        public EntityRequestStatus SubscriptionStatus { get; set; }
    }

    public class GetDriverSubscriptionResultModel
    {
        [JsonProperty("subscriptionId")]
        public Guid SubscriptionId { get; set; }

        [JsonProperty("riderId")]
        public Guid RiderId { get; set; }

        [JsonProperty("vehicleId")]
        public Guid VehicleId { get; set; }

        [JsonProperty("driverNames")]
        public string DriverNames { get; set; }

        [JsonProperty("driverEmail")]
        public string DriverEmail { get; set; }

        [JsonProperty("driverPhone")]
        public string DriverPhone { get; set; }

        [JsonProperty("pickupLocation")]
        public GeoLocation PickupLocation { get; set; }

        [JsonProperty("dropOffLocation")]
        public GeoLocation DropOffLocation { get; set; }

        [JsonProperty("estimatedPickupDateTime")]
        public DateTime? EstimatedPickupDateTime { get; set; }

        [JsonProperty("estimatedDroppOffDateTime")]
        public DateTime? EstimatedDroppOffDateTime { get; set; }

        [JsonProperty("maxPassengerAllowed")]
        public int MaxPassengerAllowed { get; set; } = 1;

        [JsonProperty("riderType")]
        [JsonConverter(typeof(StringEnumConverter))]
        public EntityRiderType RiderType { get; set; }  // (Not needed now)

        [JsonProperty("baseFare")]
        public decimal BaseFare { get; set; } = 0.00M;

        [JsonProperty("requestStatus")]
        [JsonConverter(typeof(StringEnumConverter))]
        public EntityRequestStatus RequestStatus { get; set; }

        [JsonProperty("notes")]
        public string Notes { get; set; }

        [JsonProperty("subscribers")]
        public SubscriberResultModel[] Subscribers { get; set; }
    }

    public class SubscriberResultModel
    {
        [JsonProperty("subscriberId")]
        public Guid SubscriberId { get; set; }

        [JsonProperty("subscriptionId")]
        public Guid SubscriptionId { get; set; }

        [JsonProperty("passengerNames")]
        public string PassengerNames { get; set; }

        [JsonProperty("passengerEmail")]
        public string PassengerEmail { get; set; }

        [JsonProperty("passengerPhone")]
        public string PassengerPhone { get; set; }

        [JsonProperty("passengerRouteId")]
        public Guid PassengerRouteId { get; set; }

        [JsonProperty("agreedFare")]
        public decimal AgreedFare { get; set; } = 0.00M;

        [JsonProperty("driverApproval")]
        [JsonConverter(typeof(StringEnumConverter))]
        public EntityRequestStatus DriverApproval { get; set; }

        [JsonProperty("passengerApproval")]
        [JsonConverter(typeof(StringEnumConverter))]
        public EntityRequestStatus PassengerApproval { get; set; }

        [JsonProperty("notes")]
        public string Notes { get; set; }
    }

    public class GetPassengerRouteResultModel
    {
        [JsonProperty("passengerRouteId")]
        public Guid PassengerRouteId { get; set; }

        [JsonProperty("riderId")]
        public Guid RiderId { get; set; }

        [JsonProperty("passengerNames")]
        public string PassengerNames { get; set; }

        [JsonProperty("passengerEmail")]
        public string PassengerEmail { get; set; }

        [JsonProperty("passengerPhone")]
        public string PassengerPhone { get; set; }

        [JsonProperty("pickupLocation")]
        public GeoLocation PickupLocation { get; set; }

        [JsonProperty("dropOffLocation")]
        public GeoLocation  DropOffLocation { get; set; }

        [JsonProperty("estimatedPickupDateTime")]
        public DateTime? EstimatedPickupDateTime { get; set; }

        [JsonProperty("baseFare")]
        public decimal BaseFare { get; set; } = 0.00M;

        [JsonProperty("requestStatus")]
        [JsonConverter(typeof(StringEnumConverter))]
        public EntityRequestStatus RequestStatus { get; set; }

        [JsonProperty("notes")]
        public string Notes { get; set; }
    }

    public class DriverJoinRequestRequestModel
    {
        [JsonProperty("passengerRouteId")]
        public Guid PassengerRouteId { get; set; }

        [JsonProperty("subscriptionId")]
        public Guid SubscriptionId { get; set; }

    }
    public class DriverJoinRequestResultModel
    {
        [JsonProperty("subscriberId")]
        public Guid SubscriberId { get; set; }

        [JsonProperty("passengerRouteId")]
        public Guid PassengerRouteId { get; set; }

        [JsonProperty("subscriptionId")]
        public Guid SubscriptionId { get; set; }

    }
}