﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KMN.Api.Models
{
    public class NotificationRequestModel
    {
        [JsonProperty("recipientId")]
        public string RecipientId { get; set; }

        [JsonProperty("messageTitle")]
        public string MessageTitle { get; set; }

        [JsonProperty("messageBody")]
        public string MessageBody { get; set; }

        [JsonProperty("expirationTime")]
        public DateTime? ExpirationTime { get; set; }

        [JsonProperty("notificationType")]
        [JsonConverter(typeof(StringEnumConverter))]
        public NotificationType NotificationType { get; set; }
    }

    public class NotificationResponseModel
    {
        [JsonProperty("messageId")]
        public Guid MessageId { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

    }
}