﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KMN.Api.Models
{
    public class RiderRequestModel
    {
        [JsonProperty("riderNumber")]
        public string RiderNumber { get; set; }

        [JsonProperty("userName")]
        public string UserName { get; set; }

        [JsonProperty("password")]
        public string Password { get; set; }

        [JsonProperty("confirmPassword")]
        public string ConfirmPassword { get; set; }

        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        [JsonProperty("middleName")]
        public string MiddleName { get; set; }

        [JsonProperty("lastName")]
        public string LastName { get; set; }

        [JsonProperty("dateOfBirth")]
        public DateTime?  DateOfBirth { get; set; }

        [JsonProperty("gender")]
        [JsonConverter(typeof(StringEnumConverter))]
        public EntityGender  Gender { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("primaryPhoneNumber")]
        public string PrimaryPhoneNumber { get; set; }

        [JsonProperty("secondaryPhoneNumber")]
        public string SecondaryPhoneNumber { get; set; }

        [JsonProperty("occupation")]
        public string Occupation { get; set; }

        [JsonProperty("notes")]
        public string Notes { get; set; }

        [JsonProperty("contacts")]
        public RiderContactCreateRequestModel[] Contacts { get; set; }

        [JsonProperty("vehicleInfo")]
        public VehicleInformationCreateRequestModel[] VehicleInfo { get; set; }

        [JsonProperty("subscriptionInfo")]
        public RiderSubscriptionRequestModel SubscriptionInfo { get; set; }
    }

    public class RiderResponseModel : ControllerBase
    {
        [JsonProperty("riderId")]
        public Guid RiderId { get; set; }

        [JsonProperty("riderNumber")]
        public string RiderNumber { get; set; }

        [JsonProperty("subscriptionId")]
        public Guid SubscriptionId { get; set; }

        [JsonProperty("contactIds")]
        public Guid[] Contacts { get; set; }

        [JsonProperty("VehicleInfoIds")]
        public Guid[] VehicleInfoIds { get; set; }
    }

    public class RiderContactRequestModelBase
    {
        [JsonProperty("contactId")]
        public Guid ContactId { get; set; }

        [JsonProperty("riderId")]
        public Guid RiderId { get; set; }
    }

    public class RiderContactRequestModel : RiderContactRequestModelBase
    {
        [JsonProperty("address")]
        public string Address { get; set; }

        [JsonProperty("cityOrLGA")]
        public Guid CityOrLGA { get; set; }

        [JsonProperty("state")]
        public Guid State { get; set; }

        [JsonProperty("primaryPhoneNo")]
        public string PrimaryPhoneNo { get; set; }

        [JsonProperty("secondaryPhoneNo")]
        public string SecondaryPhoneNo { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("emergencyContactName")]
        public string EmergencyContactName { get; set; }

        [JsonProperty("emergencyPhoneNumber")]
        public string EmergencyPhoneNumber { get; set; }

    }

    public class RiderContactCreateRequestModel
    {
        [JsonProperty("address")]
        public string Address { get; set; }

        [JsonProperty("cityOrLGA")]
        public Guid CityOrLGA { get; set; }

        [JsonProperty("state")]
        public Guid State { get; set; }

        [JsonProperty("primaryPhoneNo")]
        public string PrimaryPhoneNo { get; set; }

        [JsonProperty("secondaryPhoneNo")]
        public string SecondaryPhoneNo { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("emergencyContactName")]
        public string EmergencyContactName { get; set; }

        [JsonProperty("emergencyPhoneNumber")]
        public string EmergencyPhoneNumber { get; set; }

    }

    public class RiderContactResponseModel : ControllerBase
    {
        [JsonProperty("riderId")]
        public Guid RiderId { get; set; }

        [JsonProperty("contactId")]
        public Guid ContactId { get; set; }

        [JsonProperty("isUpdated")]
        public bool IsUpdated { get; set; }
    }

    public class VehicleInformationRequestModelBase
    {
        [JsonProperty("riderId")]
        public Guid RiderId { get; set; }

        [JsonProperty("vehicleInformationId")]
        public Guid VehicleInformationId { get; set; }
    }
    public class VehicleInformationRequestModel : VehicleInformationRequestModelBase
    {
        [JsonProperty("carDataId")]
        public Guid CarDataId { get; set; }

        //[JsonProperty("vehicleType")]
        //public Guid VehicleType { get; set; }

        [JsonProperty("code")]
        public string CarCode { get; set; }

        [JsonProperty("maker")]
        public string Make { get; set; }

        [JsonProperty("year")]
        public string Year { get; set; }

        [JsonProperty("modelYear")]
        public string ModelYear { get; set; }

        [JsonProperty("numberOfPassenger")]
        public int NumberOfPassenger { get; set; }

        [JsonProperty("plateNumber")]
        public string PlateNumber { get; set; }

        [JsonProperty("chasisNumber")]
        public string ChasisNumber { get; set; }
    }

    public class VehicleInformationCreateRequestModel
    {
        [JsonProperty("carDataId")]
        public Guid CarDataId { get; set; }

        [JsonProperty("code")]
        public string CarCode { get; set; }

        [JsonProperty("maker")]
        public string Make { get; set; }

        [JsonProperty("year")]
        public string Year { get; set; }

        [JsonProperty("modelYear")]
        public string ModelYear { get; set; }

        [JsonProperty("numberOfPassenger")]
        public int NumberOfPassenger { get; set; }

        [JsonProperty("plateNumber")]
        public string PlateNumber { get; set; }

        [JsonProperty("chasisNumber")]
        public string ChasisNumber { get; set; }
    }

    public class RiderResultModel
    {
        [JsonProperty("riderNumber")]
        public string RiderNumber { get; set; }

        [JsonProperty("userName")]
        public string UserName { get; set; }

        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        [JsonProperty("middleName")]
        public string MiddleName { get; set; }

        [JsonProperty("lastName")]
        public string LastName { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("primaryPhoneNumber")]
        public string PrimaryPhoneNumber { get; set; }

        [JsonProperty("secondaryPhoneNumber")]
        public string SecondaryPhoneNumber { get; set; }

        [JsonProperty("occupation")]
        public string Occupation { get; set; }

        [JsonProperty("notes")]
        public string Notes { get; set; }

        [JsonProperty("contacts")]
        public RiderContactRequestModel[] Contacts { get; set; }

        [JsonProperty("vehicles")]
        public VehicleInformationRequestModel[] Vehicles { get; set; }

    }

}