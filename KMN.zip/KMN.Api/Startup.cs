﻿using Autofac;
using Autofac.Integration.WebApi;
using Owin;
using Softmark.Api;
using System.Net.Http.Formatting;
using System.Web.Http;
using System.Web.Http.Routing;

namespace Softmark.Api
{
    public class Startup
    {
        public void Configuration(IAppBuilder appBuilder)
        {
            appBuilder.UseWebApi(SoftmarkApiConfiguration.Instance.Configuration);
        }
    }
}