﻿using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace Softmark.Shared.Api
{
    [DataContract]
    public class ApiResultModel
    {
        [JsonProperty("hasErrors")]
        [DataMember(Name = "hasErrors")]
        public bool HasErrors { get; set; }

        [JsonProperty("isSuccessful")]
        [DataMember(Name = "isSuccessful")]
        public bool IsSuccessful { get; set; }

        [JsonProperty("serverProcessingTime")]
        [DataMember(Name = "serverProcessingTime")]
        public string ServerResponseTime { get; set; }

        [JsonProperty("errorMessages")]
        [DataMember(Name = "errorMessages")]
        public List<string> ErrorMessages { get; set; }

        [JsonProperty("warningMessages")]
        [DataMember(Name = "warningMessages")]
        public List<string> WarningMessages { get; set; }

        [JsonProperty("informationMessages")]
        [DataMember(Name = "informationMessages")]
        public List<string> InformationMessages { get; set; }

        [JsonProperty("logId")]
        [DataMember(Name = "logId")]
        public int? LogId { get; set; }

        [JsonProperty("successMessage")]
        [DataMember(Name = "successMessage")]
        public string SuccessMessage { get; set; }

        [JsonProperty("errorMessage")]
        [DataMember(Name = "errorMessage")]
        public string ErrorMessage { get; set; }
    }


    [DataContract]
    public class ApiResultModel<T> : ApiResultModel
    {
        [JsonProperty("result")]
        [DataMember(Name = "result")]
        public T Result { get; set; }

        public ApiResultModel<T> SetResult(T result)
        {
            Result = result;
            return this;
        }
    }
}
