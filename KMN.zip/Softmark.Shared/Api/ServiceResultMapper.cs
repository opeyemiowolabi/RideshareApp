﻿using Softmark.Shared.Domain.Entities;
using System;
using System.Linq;

namespace Softmark.Shared.Api
{
    public static class ServiceResultMapper
    {
        /// <summary>
        /// Mpa Service Result to Service Result View Model
        /// </summary>
        /// <typeparam name="TDomain">a domain object</typeparam>
        /// <typeparam name="TView">a view entity</typeparam>
        /// <param name="src">the service result</param>
        /// <param name="mapToView">map the view to domain</param>
        /// <returns></returns>
        public static ApiResultModel<TView> Map<TDomain, TView>(this ServiceResult<TDomain> src, Func<TDomain, TView> mapToView)
        {
            return new ApiResultModel<TView>
            {
                ErrorMessage = src.ErrorMessages?.FirstOrDefault()?.Message,
                HasErrors = src.HasErrors,
                IsSuccessful = !src.HasErrors,
                LogId = 0,
                Result = mapToView(src.Result)
            };
        }


        /// <summary>
        /// Map service result with value type result to service result view model
        /// </summary>
        /// <typeparam name="T">the value type</typeparam>
        /// <param name="src">the service result</param>
        /// <returns></returns>
        public static ApiResultModel<T> Map<T>(this ServiceResult<T> src)
        {
            return new ApiResultModel<T>
            {
                ErrorMessage = src.ErrorMessages?.FirstOrDefault()?.Message,
                HasErrors = src.HasErrors,
                IsSuccessful = !src.HasErrors,
                LogId = 0,
                Result = src.Result
            };
        }
    }

}
