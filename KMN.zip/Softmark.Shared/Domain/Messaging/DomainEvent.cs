﻿using System;

namespace Softmark.Shared.Domain.Messaging
{
	public class DomainEvent<TSource> : IEvent
	{
		public DomainEvent(Guid id,TSource sourceId)
		{
			Id = id;
			SourceId = sourceId;
			CreationDate = DateTime.UtcNow;
		}

		public DomainEvent(Guid id,DateTime creationDate, TSource sourceId)
		{
			Id = id;
			SourceId = sourceId;
			CreationDate = creationDate;
		}

		public Guid Id { get; }
		public TSource SourceId { get; }
		public DateTime CreationDate { get; }

	}
}
