﻿namespace Softmark.Shared.Domain.Messaging.Handling
{
	public interface IIntegrationHandler { }

	public interface IIntegrationHandler<in T> : IIntegrationHandler
		where T : IntegrationEvent
	{
		void Handle(T @event);
	}
}
