﻿using Softmark.Shared.Domain.Messaging;


namespace Softmark.Shared.Domain.Contracts
{
    public interface IMediator
    {
        void Raise<T>(T @event) where T : IEvent;
    }
}