﻿namespace Softmark.Shared.Domain.Messaging.Handling
{
    public interface IEventHandler
    {
    }

    public interface IEventHandler<in TEvent> : IEventHandler where TEvent : IEvent
    {
        void Handle(TEvent @event);
    }

    public interface IEventHandler<in T, TSource> : IEventHandler<T>
        where T : DomainEvent<TSource>
        where TSource : struct
    {
    }
}