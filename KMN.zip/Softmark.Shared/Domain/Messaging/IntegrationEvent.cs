﻿using System;

namespace Softmark.Shared.Domain.Messaging
{
	public class IntegrationEvent : IEvent
	{
		public IntegrationEvent(Guid id)
		{
			Id = id;
			CreationDate = DateTime.UtcNow;
		}
		public IntegrationEvent(DateTime creationDate, Guid id)
		{
			Id = id;
			CreationDate = creationDate;
		}

		public Guid Id { get; }
		public DateTime CreationDate { get; }
	}
}
