﻿using System;
using System.Collections.Generic;
using System.Linq;
using Softmark.Shared.Domain.Contracts;
using Softmark.Shared.Domain.Messaging.Handling;
using Softmark.Shared.Domain.Messaging;


namespace Softmark.Shared.Domain.Messaging
{
    public class Mediator : IMediator
    {
        private readonly List<IEventHandler> _eventHandlers;

        public Mediator(IEnumerable<IEventHandler> handlers)
        {
            _eventHandlers = new List<IEventHandler>(handlers);
        }

        public void Raise<T>(T @event) where T : IEvent
        {
            if (@event == null) return;
            var eventType = @event.GetType();

            foreach (var eventHandler in _eventHandlers)
            {
                bool invoked = false;
                if (eventHandler == null) continue;
                var handlerInterfaces = eventHandler.GetType().GetInterfaces();
                foreach (var i in handlerInterfaces)
                {
                    if (i.IsGenericType && typeof(IEventHandler).IsAssignableFrom(i))
                    {
                        foreach (var ga in i.GenericTypeArguments)
                        {
                            if (ga == eventType)
                            {
                                var method = typeof(IEventHandler<>).MakeGenericType(eventType).GetMethod("Handle");
                                if (method == null) continue;
                                method.Invoke(eventHandler, new object[] {@event});
                                invoked = true;
                            }
                        }
                    }

                    if (invoked) break;
                }
            }
        }
    }
}