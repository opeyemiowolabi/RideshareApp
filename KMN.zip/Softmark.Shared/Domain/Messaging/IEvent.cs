﻿using System;

namespace Softmark.Shared.Domain.Messaging
{
	public interface IEvent
	{
		Guid Id { get; }
		DateTime CreationDate { get; }
	}
}
