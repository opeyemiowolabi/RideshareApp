﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Spatial;
using System.Text;

namespace Softmark.Shared.Domain.Utilities
{
    public interface IGeoHelper
    {
        DbGeography Location(double lat, double lon);
        DbGeography Location(GeoLocation geo);
        double? Distance(DbGeography start, DbGeography dest);
    }
    public class GeoHelper : IGeoHelper
    {
        public DbGeography Location(double lat, double lon) => DbGeography.FromText($"POINT({lat} {lon})");
        public DbGeography Location(GeoLocation geo) =>  DbGeography.FromText($"POINT({geo.Latitude} {geo.Longitude})");
        public GeoLocation Location(DbGeography geo) => GeoLocation.Get(geo);
        public double? Distance(DbGeography start, DbGeography dest) => dest.Distance(start); 
    }

    public class GeoLocation
    {
        
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }


        public static GeoLocation Get(double? latitude, double? longitude)
        {
            return new GeoLocation { Latitude = latitude, Longitude = longitude };
        }

        public static GeoLocation Get(DbGeography geo)
        {
            return new GeoLocation { Latitude = geo.Latitude, Longitude = geo.Longitude };
        }
    }
}
