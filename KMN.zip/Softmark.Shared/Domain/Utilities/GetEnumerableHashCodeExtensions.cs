﻿using System.Collections.Generic;

namespace Softmark.Shared.Domain.Utilities
{
    public static class GetEnumerableHashCodeExtensions
    {
        private const int HashPrime = 533000387;
        private const int LargePrime = 179426549;
        public static int GetEnumerableHashCode<T>(this IEnumerable<T> list) where T : class
        {

            unchecked
            {

                var hashCode = HashPrime;
                foreach (var item in list)
                {
                    hashCode = (hashCode * LargePrime) ^ item.GetHashCode();
                }

                return hashCode == HashPrime ? 0 : hashCode;
            }
        }

        public static int GetEnumerableStructHashCode<T>(this IEnumerable<T> list) where T : struct
        {
            unchecked
            {

                var hashCode = HashPrime;
                foreach (var item in list)
                {
                    hashCode = (hashCode * LargePrime) ^ item.GetHashCode();
                }

                return hashCode == HashPrime ? 0 : hashCode;
            }
        }
    }
}
