﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace Softmark.Shared.Domain.Utilities
{
  public  class SoftUtil
    {
        public static Guid GetGuid()
        {
            return  Guid.NewGuid();
        }

        public static string GeneratePatientNumber()
        {
            return "0101010";
        }

        public static string GetTokenKey(int size)
        {
            string caps = "1234567890";
            char[] chars = caps.ToCharArray();
            byte[] data = new byte[1];
            RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider();
            crypto.GetNonZeroBytes(data);
            data = new byte[size];
            crypto.GetNonZeroBytes(data);
            StringBuilder result = new StringBuilder(size);
            foreach (byte b in data) { result.Append(chars[b % (chars.Length)]); }
            return result.ToString();
        }

    }
}
