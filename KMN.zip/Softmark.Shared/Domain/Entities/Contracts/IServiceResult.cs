﻿namespace Softmark.Shared.Domain.Entities.Contracts
{
    public interface IServiceResult
    {
        bool HasErrors { get; }
        ValidationMessageCollection ValidationMessages { get; }
    }
}
