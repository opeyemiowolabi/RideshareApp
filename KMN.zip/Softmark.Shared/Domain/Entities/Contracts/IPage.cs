﻿namespace Softmark.Shared.Domain.Entities.Contracts
{
    public interface IPage
    {
        int PageNumber { get; }
        int PageSize { get; }
        int TotalRecords { get; }

        int TotalPages { get; }
    }
}
