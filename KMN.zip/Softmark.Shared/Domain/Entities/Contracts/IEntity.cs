﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Softmark.Shared.Domain.Entities.Contracts
{
    public interface IEntity<T>
    {
        T Id { get; }
    }
}
