﻿using Softmark.Shared.Domain.Enum;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Softmark.Shared.Domain.Entities
{
    public class ValidationMessageCollection : IEnumerable<ValidationMessage>, IList<ValidationMessage>
    {
        private readonly List<ValidationMessage> _messages;

        public ValidationMessageCollection()
        {
            _messages = new List<ValidationMessage>();
        }

        public IEnumerator<ValidationMessage> GetEnumerator()
        {
            return _messages.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return _messages.GetEnumerator();
        }

        public void Add(ValidationMessage message)
        {
            if (message == null) return;
            _messages.Add(message);
        }

        public void AddRange(IEnumerable<ValidationMessage> items)
        {
            _messages.AddRange(items);
        }
        public void Clear()
        {
            _messages.Clear();
        }

        public bool Contains(ValidationMessage item)
        {
            return _messages.Contains(item);
        }

        public void CopyTo(ValidationMessage[] array, int arrayIndex)
        {
            if (_messages == null || !_messages.Any()) return;
            foreach (var message in _messages) array.SetValue(message, arrayIndex++);
        }

        public bool Remove(ValidationMessage item)
        {
            if (_messages == null || !_messages.Any()) return false;
            return _messages.Remove(item);
        }

        public int Count => _messages.Count;
        public bool IsReadOnly => true;

        public int IndexOf(ValidationMessage item)
        {
            return _messages.IndexOf(item);
        }

        public void Insert(int index, ValidationMessage item)
        {
            _messages.Insert(index, item);
        }

        public void RemoveAt(int index)
        {
            _messages.RemoveAt(index);
        }

        public ValidationMessage this[int index]
        {
            get
            {
                return _messages[index];
            }
            set { _messages[index] = value; }
        }

        public bool HasErrors =>
            _messages != null && _messages.Any(i => i.ValidationMessageType == ValidationMessageType.Error);
    }
}
