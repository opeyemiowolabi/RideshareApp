﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Softmark.Shared.Domain.Entities
{
    public abstract class ViewEntity : BaseViewEntity
    {
        public int Id { get; set; }
    }
}
