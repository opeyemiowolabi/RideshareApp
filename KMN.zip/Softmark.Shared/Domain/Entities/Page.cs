﻿using System;
using System.Collections.Generic;
using Softmark.Shared.Domain.Entities.Contracts;

namespace Softmark.Shared.Domain.Entities
{
    public class Page<T> : IPage
    {
        private readonly List<T> _items;

        public Page() : this(new List<T>(), 0, 0, 0)
        {
        }

        public Page<T> CopyWithoutItemsFrom(IPage page)
        {
            if (page == null) return this;
            PageNumber = page.PageNumber;
            PageSize = page.PageSize;
            TotalRecords = page.TotalRecords;
            return this;
        }
        public Page(List<T> items, int pageNumber, int pageSize, int total)
        {
            _items = new List<T>();
            if (items == null) return;
            _items.AddRange(items);
            PageNumber = pageNumber;
            PageSize = pageSize;
            TotalRecords = total;
        }

        public IReadOnlyCollection<T> Items => _items;
        public int PageNumber { get; private set; }
        public int PageSize { get; private set; }
        public int TotalRecords { get; private set; }
        public int TotalPages => PageSize == 0 ? 0 : (int)Math.Ceiling((double)TotalRecords / (double)PageSize);


        public Page<T> AddItems(params T[] items)
        {
            _items.AddRange(items);
            return this;
        }
    }
}
