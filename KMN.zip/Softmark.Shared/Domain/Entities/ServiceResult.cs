﻿using Softmark.Shared.Domain.Entities.Contracts;
using Softmark.Shared.Domain.Enum;
using System.Collections.Generic;
using System.Linq;

namespace Softmark.Shared.Domain.Entities
{
    public class ServiceResult<T> : IServiceResult
    {
        public ServiceResult() : this(default(T), new ValidationMessageCollection())
        {
        }

        public ServiceResult(T result, ValidationMessageCollection validaionMessages)
        {
            ValidationMessages = validaionMessages ?? new ValidationMessageCollection();
            Result = result;
        }

        public T Result { get; private set; }
        public bool HasWarnings => WarningMessages != null && WarningMessages.Any();

        public List<ValidationMessage> InformationMessages => ValidationMessages
            .Where(m => m.ValidationMessageType == ValidationMessageType.Information).ToList();

        public List<ValidationMessage> WarningMessages => ValidationMessages
            .Where(m => m.ValidationMessageType == ValidationMessageType.Warning).ToList();

        public List<ValidationMessage> ErrorMessages => ValidationMessages
            .Where(m => m.ValidationMessageType == ValidationMessageType.Error).ToList();

        public ValidationMessageCollection ValidationMessages { get; }

        public bool HasErrors => ErrorMessages != null && ErrorMessages.Any();

        public ServiceResult<T> AddWarning(string message, string internalMessage)
        {
            ValidationMessages.Add(new ValidationMessage(message, internalMessage, ValidationMessageType.Warning));
            return this;
        }

        public ServiceResult<T> AddError(string message, string internalMessage)
        {
            ValidationMessages.Add(new ValidationMessage(message, internalMessage, ValidationMessageType.Error));
            return this;
        }

        public ServiceResult<T> SetResult(T result)
        {
            Result = result;
            return this;
        }

        public void MergeValidationWith(IServiceResult other)
        {
            if (other == null) return;
            ValidationMessages.AddRange(other.ValidationMessages);
        }
    }
}
