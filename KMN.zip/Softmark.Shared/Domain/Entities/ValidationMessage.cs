﻿using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Text;

namespace Softmark.Shared.Domain.Entities
{
    public class ValidationMessage : IEquatable<ValidationMessage>
    {
        public string Message { get; }
        public string InternalMessage { get; }
        public ValidationMessageType ValidationMessageType { get; }

        public ValidationMessage(string message, string internalMessage, ValidationMessageType validationMessageType)
        {
            Message = message;
            InternalMessage = internalMessage;
            ValidationMessageType = validationMessageType;
        }

        public bool Equals(ValidationMessage other)
        {
            if (ReferenceEquals(null, other)) return false;
            if (ReferenceEquals(this, other)) return true;
            return string.Equals(Message, other.Message) && string.Equals(InternalMessage, other.InternalMessage) && ValidationMessageType == other.ValidationMessageType;
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((ValidationMessage)obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                var hashCode = (Message != null ? Message.GetHashCode() : 0);
                hashCode = (hashCode * 397) ^ (InternalMessage != null ? InternalMessage.GetHashCode() : 0);
                hashCode = (hashCode * 397) ^ (int)ValidationMessageType;
                return hashCode;
            }
        }
    }
}
