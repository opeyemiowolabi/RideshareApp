﻿namespace Softmark.Shared.Domain.Entities
{
    public abstract class PersistenceEntity : PersistenceEntityWithoutKey
    {
        public int Id { get; set; }
    }
}
