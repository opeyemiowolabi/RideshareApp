﻿using Softmark.Shared.Domain.Messaging;
using System;
using System.Collections.Generic;
using System.Text;

namespace Softmark.Shared.Domain.Entities
{
    [Serializable]
    public abstract class AggregateRoot : AggregateRoot<int>
    {
        private AggregateRoot() : base(0)
        {
        }

        protected AggregateRoot(int id) : base(id)
        {
        }
    }

    public abstract class AggregateRoot<T> : DomainEntity<T>
    {
        private readonly List<DomainEvent<T>> _domainEvents = new List<DomainEvent<T>>();

        private AggregateRoot() : base(default(T))
        {
        }

        protected AggregateRoot(T id) : base(id)
        {
        }

        public IReadOnlyCollection<DomainEvent<T>> DomainEvents => _domainEvents;

        public void AddDomainEvent(DomainEvent<T> eventItem)
        {
            _domainEvents.Add(eventItem);
        }

        public void RemoveDomainEvent(DomainEvent<T> eventItem)
        {
            _domainEvents?.Remove(eventItem);
        }

        public void ClearDomainEvents()
        {
            _domainEvents?.Clear();
        }
    }
}
