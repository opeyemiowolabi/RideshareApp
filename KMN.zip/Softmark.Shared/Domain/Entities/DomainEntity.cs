﻿using Softmark.Shared.Domain.Entities.Contracts;
using System;

namespace Softmark.Shared.Domain.Entities
{

    public abstract class DomainEntity : DomainEntity<int>
        {

            protected DomainEntity(int id) : base(id)
            {
            }
        }


        public abstract class DomainEntity<T> : DomainObject, IEntity<T>
        {
            public T Id { get; private set; }

            public DomainEntity(T id)
            {
                Id = id;
            }

            protected void ChangeId(T id)
            {
                Id = id;
            }
        }

        public abstract class DomainObject
        {
           public Guid TransactionId { get; set; } // Unique transaction Id
        }

    
}
