﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Softmark.Shared.Domain.Entities
{
    public abstract class PersistenceEntityWithoutKey
    {
        public DateTimeOffset CreatedTimestamp { get; set; }
        public int CreatedBy { get; set; }
        public DateTimeOffset? ModifiedTimestamp { get; set; }
        public int? ModifiedBy { get; set; }
        public string CreatedByName { get; set; }
        public string ModifiedByName { get; set; }

        public void IsCreatedBy(int id, string name)
        {
            CreatedBy = id;
            CreatedByName = name;
            CreatedTimestamp = DateTimeOffset.Now;
        }

        public void IsModifiedBy(int id, string name)
        {
            ModifiedBy = id;
            ModifiedByName = name;
            ModifiedTimestamp = DateTimeOffset.Now;
        }
    }
}
