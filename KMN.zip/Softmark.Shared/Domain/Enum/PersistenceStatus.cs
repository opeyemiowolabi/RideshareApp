﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Softmark.Shared.Domain.Enum
{
    public enum PersistenceStatus
    {
        Added = 1,
        Deleted = 2,
        Updated = 3,
        NoChange = 4,
        NotFound = 5,
        ConcurrencyException = 6
    }
}
