﻿namespace Softmark.Shared.Domain.Enum
{
    public enum BizPartnerType
    {
        Other = 0,
        Supplier = 1,
        Vendor = 2,
        Reserve1 = 3,
        Reserve2 = 4,
        Reserve3 = 5,
        Reserve4 = 6
    }

    public enum StoreItemType
    {
        Other = 0,
        NonEdibleDry = 1,
        NonEdibleWet = 2,
        EdibleDry = 3,
        EdibleWet = 4,
        Reserve3 = 5,
        Reserve4 = 6
    }


    public enum NotificationType
    {
        None = 0,
        Email = 1,
        SMS = 2,
        Log = 3,
        Other = 4
    }

    public enum DeliveryStatus
    {
        Pending = 0,
        Delivered = 1,
        Failed = 2,
        Unknown = 3
    }
}
