﻿namespace Softmark.Shared.Domain.Enum
{
    public enum EntityStatus
    {
        InActive = 0,
        Active = 1,
        Deleted = 2,
        Reserve1 = 3,
        Reserve2 = 4,
        Reserve3 = 5,
        Reserve4 = 6
    }

    public enum EntityGender
    {
        Undefine = 0,
        Male = 1,
        Female = 2
    }

    public enum EntityContactType
    {
        Undefine = 0,
        Residential = 1,
        Mailing = 2
    }

    public enum EntityPriority
    {
        Undefine = 0,
        Primary = 1,
        Secondary = 2
    }

    public enum EntityMaritalStatus
    {
        Undefine = 0,
        Single = 1,
        Married = 2,
        Divorced = 3,
        Widow = 4
    }

    public enum EntityRelationship
    {
        Undefine = 0,
        Spouse = 1,
        Daughter = 2,
        Son = 3,
        Father = 4,
        Mother = 5,
        Uncle = 6,
        Sister = 7,
        Brother = 8
    }

    public enum EntityAppointmentType
    {
        Undefine = 0,
        InPatient = 1,
        OutPatient = 2,
        InPatientEmergency = 3,
        OutPatientEmergency = 4
    }

    public enum EntityRiderType
    {
        Driver = 1,
        Passenger = 2,
        Undefine = 0,
    }

    public enum EntityRequestStatus
    {
        Pending = 0,
        AwaitingApproval = 1,
        Approved= 2,
        Declined = 3,
        Canclled = 4
    }

    public enum EntityTripStatus
    {
        Pending = 0,
        Completed = 1,
        Ongoing = 2,
        Canclled = 3
    }
}
