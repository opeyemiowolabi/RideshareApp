﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Softmark.Shared.Domain.Enum
{
    public enum ValidationMessageType
    {
        Information = 0,
        Warning = 1,
        Error = 2
    }
}
