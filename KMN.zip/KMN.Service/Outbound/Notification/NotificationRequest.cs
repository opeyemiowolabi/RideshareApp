﻿using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Text;

namespace KMN.Service.Outbound.Notification
{
   public class NotificationRequest
    {
        public Guid MessageId { get; set; }
        public string SenderId { get; set; }
        public string RecipientId { get; set; }
        public string MessageTitle { get; set; }
        public string MessageBody { get; set; }
        public DateTime? Timestamp { get; set; }
        public NotificationType NotificationType { get; set; }
    }
}
