﻿using System;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Threading;
using System.ComponentModel;
using System.Threading.Tasks;
using System.Collections;

namespace KMN.Service.Outbound.Notification
{
    public class EmailSender 
    {
        private readonly NotificationRequest _request;
        private readonly SmtpClient _client;
        private readonly string _host = "smtp.ionos.com";
        private readonly string _username = "DoNotReply@softmark.ca";
        private readonly string _password = "Torriq02";
        private readonly int _port = 587;
        private readonly string _displayname = "KMN";

        static bool mailSent = false;
        static string desc = "";
        private  void SendCompletedCallback(object sender, AsyncCompletedEventArgs e)
        {
            Guid token = (Guid)e.UserState;

            if (e.Cancelled)
            {
                desc = string.Format("[{0}] Send canceled.", token);
            }
            if (e.Error != null)
            {
                desc = string.Format("[{0}] {1}", token, e.Error.ToString());
            }
            else
            {
                desc = string.Format("Message sent.");
            }
            mailSent = true;
        }
        public EmailSender(NotificationRequest request )
        {
            _request = request;
        }

        public void SendMailWithAttachement()
        {
            string server = "";
            // Specify the file to be attached and sent.
            // This example assumes that a file named Data.xls exists in the
            // current working directory.
            string file = "data.xls";
            // Create a message and set up the recipients.
            MailMessage message = new MailMessage("jane@contoso.com","ben@contoso.com","Quarterly data report.", "See the attached spreadsheet.");

            // Create  the file attachment for this email message.
            Attachment data = new Attachment(file, MediaTypeNames.Application.Octet);
            // Add time stamp information for the file.
            ContentDisposition disposition = data.ContentDisposition;
            disposition.CreationDate = System.IO.File.GetCreationTime(file);
            disposition.ModificationDate = System.IO.File.GetLastWriteTime(file);
            disposition.ReadDate = System.IO.File.GetLastAccessTime(file);
            // Add the file attachment to this email message.
            message.Attachments.Add(data);

            //Send the message.
            SmtpClient client = new SmtpClient(server);
            // Add credentials if the SMTP server requires them.
            client.Credentials = CredentialCache.DefaultNetworkCredentials;

            try
            {
                client.Send(message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught in CreateMessageWithAttachment(): {0}",
                            ex.ToString());
            }

            // Display the values in the ContentDisposition for the attachment.
            ContentDisposition cd = data.ContentDisposition;
            Console.WriteLine("Content disposition");
            Console.WriteLine(cd.ToString());
            Console.WriteLine("File {0}", cd.FileName);
            Console.WriteLine("Size {0}", cd.Size);
            Console.WriteLine("Creation {0}", cd.CreationDate);
            Console.WriteLine("Modification {0}", cd.ModificationDate);
            Console.WriteLine("Read {0}", cd.ReadDate);
            Console.WriteLine("Inline {0}", cd.Inline);
            Console.WriteLine("Parameters: {0}", cd.Parameters.Count);
            foreach (DictionaryEntry d in cd.Parameters)
            {
                Console.WriteLine("{0} = {1}", d.Key, d.Value);
            }
            data.Dispose();
        }
       
        public async Task<bool> SendMailAsync()
        {
            // Command-line argument must be the SMTP host.
            using (SmtpClient client = new SmtpClient(_host, _port)) 
            {
                client.Credentials = new NetworkCredential(_username, _password);
                client.EnableSsl = true;

                // Specify the email sender.
                // Create a mailing address that includes a UTF8 character in the display name.
                MailAddress from = new MailAddress(_username, _displayname, System.Text.Encoding.UTF8);
                 
                // Set destinations for the email message.
                MailAddress to = new MailAddress(_request.RecipientId);

                // Specify the message content.
                MailMessage message = new MailMessage(from, to);
                message.Body = _request.MessageBody;
                message.IsBodyHtml = true;

                // Include some non-ASCII characters in body and subject.
                // string someArrows = new string(new char[] { '\u2190', '\u2191', '\u2192', '\u2193' });
                // message.Body += Environment.NewLine + someArrows;
                message.BodyEncoding = System.Text.Encoding.UTF8;
                message.Subject = _request.MessageTitle;
                message.SubjectEncoding = System.Text.Encoding.UTF8;

                // Set the method that is called back when the send operation ends.
                client.SendCompleted += new SendCompletedEventHandler(SendCompletedCallback);

                // The userState can be any object that allows your callback
                // method to identify this send operation.
                // For this example, the userToken is a string constant.
                Guid userState = Guid.NewGuid();
                client.SendAsync(message, userState);

                await Task.Delay(5000);

                // If the user canceled the send, and mail hasn't been sent yet,
                // then cancel the pending operation.
                if (mailSent == false)
                {
                    client.SendAsyncCancel();
                }

                return mailSent;
            }
        }
    }
}
