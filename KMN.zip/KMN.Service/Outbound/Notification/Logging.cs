﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Softmark.Shared.Domain.Entities;
using Softmark.Shared.Domain.Enum;

namespace KMN.Service.Outbound.Notification
{
    public class Logging 
    {
       
    }
}
