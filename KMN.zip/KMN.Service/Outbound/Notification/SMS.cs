﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Softmark.Shared.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace KMN.Service.Outbound.Notification
{
    public class SMSSender
    {
        // twilio password Torriq02Paparazzi1987
        private readonly NotificationRequest _request;
        // LIVE
        const string accountSid = "ACafbf01b82665ef23237e6cac45db639e";
        const string authToken = "1e86061883f0e75ef158d0c31f92a0b1";
        private readonly string from = "+16476940351";

        // TEST
        const string accountSid_test = "ACfebd8175b024ea697f589d141cb92670";
        const string authToken_test  = "cfdf26cc0b0c2bfe640a74ee96cfad5a";
        private readonly string from_test = "+15005550006";

        private readonly string _displayname = "KMN";

        static bool smsSent = false;
        static string desc = "";
     
        public SMSSender(NotificationRequest request)
        {
            _request = request;
        }

        public async Task<bool> SendSMSAsync()
        {
            TwilioClient.Init(accountSid_test, authToken_test);

            var message = MessageResource.Create(
               body: _request.MessageBody,
               from: new Twilio.Types.PhoneNumber(from_test),
               to: new Twilio.Types.PhoneNumber(_request.RecipientId)
           );

            await Task.Delay(100);
            smsSent = true;
            return smsSent;
        }

    }
}
