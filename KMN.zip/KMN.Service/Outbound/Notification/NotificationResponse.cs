﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KMN.Service.Outbound.Notification
{
    public class NotificationResponse
    {
        public Guid  MessageId { get; set; }
    }
}
