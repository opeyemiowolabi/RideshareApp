﻿using Softmark.Shared.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace KMN.Service.Outbound.Notification
{
    public interface INotification
    {
        Task<ServiceResult<NotificationResponse>> SendNotification(NotificationRequest notification);
        Task<ServiceResult<NotificationResponse>> SendToken(NotificationRequest notification);

        Task<ServiceResult<bool>> ValidateToken(NotificationRequest notification);
    }
}
