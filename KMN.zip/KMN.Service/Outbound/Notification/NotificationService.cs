﻿using KMN.Domain.Entities;
using KMN.Domain.Result;
using KMN.Persistence.Repositories;
using KMN.Persistence.Repositories.Contract;
using KMN.Service.Contract;
using KMN.Service.Outbound.Notification;
using Softmark.Shared.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using Softmark.Shared.Domain.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KMN.Service.Outbound.Notification
{
    public class NotificationService : INotification
    {
        private readonly INotificationRepository _repository;
        private const int expirationHour = 4;
        public NotificationService(INotificationRepository repository)
        {
            _repository = repository;
        }

        public async Task<ServiceResult<NotificationResponse>> SendNotification(NotificationRequest notification)
        {
            var dTime = DateTime.Now;
            var result = new ServiceResult<NotificationResponse>();
            try
            {
                // Construct token implementation and pass it as parameter in the NotificationRequest
              
                var resp = false;

                // save token in database. if successful send it out to recipient
                var dbNotification = new Domain.Entities.Notification
                {
                    NotificationId = SoftUtil.GetGuid(),
                    MessageId = SoftUtil.GetGuid(),
                    SenderId = "",
                    RecipientId = notification.RecipientId,
                    MessageBody = notification.MessageBody,
                    MessageTitle = notification.MessageTitle,
                    NotificationType = notification.NotificationType,
                    DeliveryStatus = DeliveryStatus.Pending,
                    Timestamp = dTime,
                    ExpirationTime = dTime,
                    CreatedBy = SoftUtil.GetGuid(),
                    LastUpdatedBy = SoftUtil.GetGuid(),
                    DateCreated = dTime,
                    LastUpdatedDate = dTime
                };

                result.SetResult(new NotificationResponse
                {
                    MessageId = dbNotification.MessageId
                });

                var dbresp = await _repository.CreateNotificationAsync(dbNotification).ConfigureAwait(false);
                if (dbresp)
                {
                    switch (notification.NotificationType)
                    {
                        case NotificationType.Email:
                            notification.MessageBody = $"<html><body>{notification.MessageBody}<br/><br/>Regards,</body></html>";
                            resp = await (new EmailSender(notification).SendMailAsync().ConfigureAwait(false));
                            break;

                        case NotificationType.SMS:
                            notification.MessageBody = $"{notification.MessageTitle}: {notification.MessageBody}";
                            resp = await (new SMSSender(notification).SendSMSAsync().ConfigureAwait(false));
                            break;
                    }

                    if (!resp) result.AddError("Error sending message to specify contact", "Error sending message to specify contact");

                    dbNotification.DeliveryStatus = resp ? DeliveryStatus.Delivered : DeliveryStatus.Failed;
                    var dbUpdate = await _repository.UpdateNotificationAsync(dbNotification).ConfigureAwait(false);

                    return result;
                }

                result.AddError("Error saving token", "Database Error occurred");
            }
            catch (Exception ex)
            {
                result.AddError($"Error sending token to specify contact : {ex.Message} ===== {ex.InnerException}", "Error sending token to specify contact");
            }

            return result;
        }

        public  async Task<ServiceResult<NotificationResponse>> SendToken(NotificationRequest notification)
        {
            var dTime = DateTime.Now;
            var result = new ServiceResult<NotificationResponse>();
            try
            {
                // Construct token implementation and pass it as parameter in the NotificationRequest
                var token = SoftUtil.GetTokenKey(6);
                var resp = false;

                notification.MessageTitle = "KMN (OTP)";

                // save token in database. if successful send it out to recipient
                var dbNotification = new Domain.Entities.Notification
                {
                    NotificationId = SoftUtil.GetGuid(),
                    MessageId = SoftUtil.GetGuid(),
                    SenderId = "",
                    RecipientId = notification.RecipientId,
                    MessageBody = token,
                    MessageTitle = notification.MessageTitle,
                    NotificationType = notification.NotificationType,
                    DeliveryStatus = DeliveryStatus.Pending,
                    Timestamp = dTime,
                    ExpirationTime = dTime,
                    CreatedBy = SoftUtil.GetGuid(),
                    LastUpdatedBy = SoftUtil.GetGuid(),
                    DateCreated = dTime,
                    LastUpdatedDate = dTime
                };

                result.SetResult(new NotificationResponse
                {
                    MessageId = dbNotification.MessageId
                });

                var dbresp = await _repository.CreateNotificationAsync(dbNotification).ConfigureAwait(false);
                if (dbresp)
                {
                    switch (notification.NotificationType)
                    {
                        case NotificationType.Email:
                            notification.MessageBody = $"<html><body>Your OTP code is <strong>{token}</strong> and you need to enter this code manually.";
                            notification.MessageBody += $"<br/>Please note that this code will expire after {dbNotification.ExpirationTime}. You can request for a new OTP anytime for device authentication. <br/>Regards,</body></html>";
                            resp = await (new EmailSender(notification).SendMailAsync().ConfigureAwait(false));
                            break;

                        case NotificationType.SMS:
                            notification.MessageBody = $"{notification.MessageTitle}: Your OTP {token} will expire in 20 minutes";
                            resp = await (new SMSSender(notification).SendSMSAsync().ConfigureAwait(false));
                            break;
                    }

                    if (!resp) result.AddError("Error sending token to specify contact", "Error sending token to specify contact");

                    dbNotification.DeliveryStatus = resp ? DeliveryStatus.Delivered : DeliveryStatus.Failed;
                    var dbUpdate = await _repository.UpdateNotificationAsync(dbNotification).ConfigureAwait(false);

                    return result;
                }

                result.AddError("Error saving token", "Database Error occurred");
            }
            catch( Exception ex)
            {
                result.AddError($"Error sending token to specify contact : {ex.Message} ===== {ex.InnerException}", "Error sending token to specify contact");
            }
          
            return result;
        }

        public async Task<ServiceResult<bool>> ValidateToken(NotificationRequest notification)
        {
            var result = new ServiceResult<bool>();
            try
            {
                var dbNotification = new Domain.Entities.Notification
                {
                    MessageId = SoftUtil.GetGuid(),
                    RecipientId = notification.RecipientId,
                    MessageBody = notification.MessageBody,
                };

                var dbresp = await _repository.ValidateTokenAsync(dbNotification).ConfigureAwait(false);
                
                if(!dbresp)
                    result.AddError("The token provided is either not exist or expired. Kindly request for new token", "The token provided is either not exist or expired");

              

                result.SetResult(dbresp);
            }
            catch (Exception ex)
            {
                result.AddError($"Error validating token to specify contact : {ex.Message} ===== {ex.InnerException}", "Error sending token to specify contact");
            }

            return result;
        }
    }
}
