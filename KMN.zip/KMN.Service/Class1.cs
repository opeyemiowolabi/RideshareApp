﻿using System;

namespace KMN.Service
{
    public class Class1
    {
    }
}
