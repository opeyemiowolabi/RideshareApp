﻿using KMN.Domain.Entities;
using KMN.Domain.Result;
using Softmark.Shared.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace KMN.Service.Contract
{
    public interface ISystemEntitiesService
    {
        Task<ServiceResult<GetCarDataInfoResult>> GetCarsById(Guid carId);
        Task<ServiceResult<GetCarDataInfoResult>> GetCarsByCarCode(string carCode);
        Task<ServiceResult<IEnumerable<GetCarDataInfoResult>>> GetCarsByGroup();
        Task<ServiceResult<IEnumerable<GetCarDataInfoResult>>> GetCarsByMake(string make);
        Task<ServiceResult<IEnumerable<GetCarDataInfoResult>>> GetCarsByMakeYear(string make, string year);
        Task<ServiceResult<IEnumerable<GetCarDataInfoResult>>> GetCarsByModelYear(string modelYear);
        Task<ServiceResult<IEnumerable<GetCarDataInfoResult>>> GetAllCars();
    }
}
