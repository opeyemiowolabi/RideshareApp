﻿using KMN.Domain.Entities;
using KMN.Domain.Result;
using Softmark.Shared.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace KMN.Service.Contract
{
    public interface IRiderService
    {
        Task<ServiceResult<AddRiderInfoResult>> AddRiderAsync(Rider rider);
        Task<ServiceResult<GetRiderInfoResult>> GetRiderByIdAsync(Guid riderId);
        Task<ServiceResult<GetRiderInfoResult>> GetRiderByEmailAsync(string email);
        Task<ServiceResult<IEnumerable<GetRiderInfoResult>>> GetAllRidersAsync(EntityStatus? status);
        Task<ServiceResult<IEnumerable<UpdateRiderContactInfoResult>>> UpdateRiderContactAsync(IEnumerable<RiderContact> contacts);
        Task<ServiceResult<IEnumerable<UpdateRiderContactInfoResult>>> AddRiderContactAsync(IEnumerable<RiderContact> contacts);
    }
}
