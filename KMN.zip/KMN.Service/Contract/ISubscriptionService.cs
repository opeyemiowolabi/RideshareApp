﻿using KMN.Domain.Entities;
using KMN.Domain.Result;
using Softmark.Shared.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Data.Entity.Spatial;
using System.Threading.Tasks;

namespace KMN.Service.Contract
{
    public interface ISubscriptionService
    {
        Task<ServiceResult<AddSubscriptionInfoResult>> AddSubscriptionAsync(Subscription  subscription);
        Task<ServiceResult<AddSubscriptionInfoResult>> AddSubscriptionAsync(PassengerRoute  subscription);
        Task<ServiceResult<IEnumerable<DriverSubscriptionInfoResult>>> GetDriverSubscriptionListAsync(DbGeography pickUpLocation, DbGeography dropOffLocation, double kilometers, EntityRequestStatus requestStatus);
        Task<ServiceResult<IEnumerable<PassengerRouteInforesult>>> GetPassengerSubscriptionListAsync(DbGeography pickUpLocation, DbGeography dropOffLocation, double kilometers, EntityRequestStatus requestStatus);
        Task<ServiceResult<DriverJoinRequestInforesult>> DriverJoinRequestAsync(Guid SubscriptionId, Guid PassengerRouteId);
    }
}
