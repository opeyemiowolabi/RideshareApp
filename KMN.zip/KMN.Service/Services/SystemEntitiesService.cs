﻿using KMN.Domain.Entities;
using KMN.Domain.Result;
using KMN.Persistence.Repositories.Contract;
using KMN.Service.Contract;
using Softmark.Shared.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using Softmark.Shared.Domain.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KMN.Service.Services
{
    public partial class SystemEntitiesService : ISystemEntitiesService
    {
        private readonly ISystemEntitiesRepository _systemRepository;

        public SystemEntitiesService(ISystemEntitiesRepository systemRepository)
        {
            _systemRepository = systemRepository;
        }

        public async Task<ServiceResult<IEnumerable<GetCarDataInfoResult>>> GetAllCars()
        {
            var cars = new List<GetCarDataInfoResult>();
            var result = new ServiceResult<IEnumerable<GetCarDataInfoResult>>();

            try
            {
                var repos = await _systemRepository.GetAllCars().ConfigureAwait(false);

                if (repos == null) return result.AddError($"No record found for the specified criteria!"
                    , $"No record found for the specified criteria!");

                foreach(var repo in repos)
                {
                    cars.Add(new GetCarDataInfoResult
                    {
                        CarDataId =  repo.CarDataId,
                        CarCode =  repo.CarCode,
                        Make =  repo.Make,
                        ModelYear =  repo.ModelYear ,
                        Year =  repo.Year 
                    });
                }

                result.SetResult(cars);
            }
            catch( Exception ex)
            {
                result.AddError("Unexpected error while executing reques", $"Unexpected error while executing request {ex.Message} {ex.StackTrace}");
            }

            return result;
        }

        public async Task<ServiceResult<GetCarDataInfoResult>> GetCarsByCarCode(string carCode)
        {
            var result = new ServiceResult<GetCarDataInfoResult>();

            try
            {
                var repo = await _systemRepository.GetCarsByCarCode(carCode).ConfigureAwait(false);

                if (repo == null) return result.AddError($"No record found for the specified criteria!"
                    , $"No record found for the specified criteria!");

                var car = (new GetCarDataInfoResult
                {
                    CarDataId = repo.CarDataId,
                    CarCode = repo.CarCode,
                    Make = repo.Make,
                    ModelYear = repo.ModelYear,
                    Year = repo.Year
                });

                result.SetResult(car);
            }
            catch (Exception ex)
            {
                result.AddError("Unexpected error while executing reques", $"Unexpected error while executing request {ex.Message} {ex.StackTrace}");
            }

            return result;
        }

        public async Task<ServiceResult<GetCarDataInfoResult>> GetCarsById(Guid carId)
        {
            var result = new ServiceResult<GetCarDataInfoResult>();

            try
            {
                var repo = await _systemRepository.GetCarsById(carId).ConfigureAwait(false);

                if (repo == null) return result.AddError($"No record found for the specified criteria!"
                    , $"No record found for the specified criteria!");
              
                    var car = (new GetCarDataInfoResult
                    {
                        CarDataId = repo.CarDataId,
                        CarCode = repo.CarCode,
                        Make = repo.Make,
                        ModelYear = repo.ModelYear,
                        Year = repo.Year
                    });

                result.SetResult(car);
            }
            catch (Exception ex)
            {
                result.AddError("Unexpected error while executing reques", $"Unexpected error while executing request {ex.Message} {ex.StackTrace}");
            }

            return result;
        }

        public async Task<ServiceResult<IEnumerable<GetCarDataInfoResult>>> GetCarsByGroup()
        {
            var cars = new List<GetCarDataInfoResult>();
            var result = new ServiceResult<IEnumerable<GetCarDataInfoResult>>();

            try
            {
                var repos = await _systemRepository.GetCarsByGroup().ConfigureAwait(false);

                if (repos == null) return result.AddError($"No record found for the specified criteria!"
                    , $"No record found for the specified criteria!");

                foreach (var repo in repos)
                {
                    cars.Add(new GetCarDataInfoResult
                    {
                        Make = repo.Make
                    });
                }

                result.SetResult(cars);
            }
            catch (Exception ex)
            {
                result.AddError("Unexpected error while executing reques", $"Unexpected error while executing request {ex.Message} {ex.StackTrace}");
            }

            return result;
        }

        public async Task<ServiceResult<IEnumerable<GetCarDataInfoResult>>> GetCarsByMake(string make)
        {
            var cars = new List<GetCarDataInfoResult>();
            var result = new ServiceResult<IEnumerable<GetCarDataInfoResult>>();

            try
            {
                var repos = await _systemRepository.GetCarsByMake(make).ConfigureAwait(false);

                if (repos == null) return result.AddError($"No record found for the specified criteria!"
                    , $"No record found for the specified criteria!");

                foreach (var repo in repos)
                {
                    cars.Add(new GetCarDataInfoResult
                    {
                        CarDataId = repo.CarDataId,
                        CarCode = repo.CarCode,
                        Make = repo.Make,
                        ModelYear = repo.ModelYear,
                        Year = repo.Year
                    });
                }

                result.SetResult(cars);
            }
            catch (Exception ex)
            {
                result.AddError("Unexpected error while executing reques", $"Unexpected error while executing request {ex.Message} {ex.StackTrace}");
            }

            return result;
        }

        public async Task<ServiceResult<IEnumerable<GetCarDataInfoResult>>> GetCarsByMakeYear(string make, string year)
        {
            var cars = new List<GetCarDataInfoResult>();
            var result = new ServiceResult<IEnumerable<GetCarDataInfoResult>>();

            try
            {
                var repos = await _systemRepository.GetCarsByMakeYear(make,year).ConfigureAwait(false);

                if (repos == null) return result.AddError($"No record found for the specified criteria!"
                    , $"No record found for the specified criteria!");

                foreach (var repo in repos)
                {
                    cars.Add(new GetCarDataInfoResult
                    {
                        CarDataId = repo.CarDataId,
                        CarCode = repo.CarCode,
                        Make = repo.Make,
                        ModelYear = repo.ModelYear,
                        Year = repo.Year
                    });
                }

                result.SetResult(cars);
            }
            catch (Exception ex)
            {
                result.AddError("Unexpected error while executing reques", $"Unexpected error while executing request {ex.Message} {ex.StackTrace}");
            }

            return result;
        }

        public async Task<ServiceResult<IEnumerable<GetCarDataInfoResult>>> GetCarsByModelYear(string modelYear)
        {
            var cars = new List<GetCarDataInfoResult>();
            var result = new ServiceResult<IEnumerable<GetCarDataInfoResult>>();

            try
            {
                var repos = await _systemRepository.GetCarsByModelYear(modelYear).ConfigureAwait(false);

                if (repos == null) return result.AddError($"No record found for the specified criteria!"
                    , $"No record found for the specified criteria!");

                foreach (var repo in repos)
                {
                    cars.Add(new GetCarDataInfoResult
                    {
                        CarDataId = repo.CarDataId,
                        CarCode = repo.CarCode,
                        Make = repo.Make,
                        ModelYear = repo.ModelYear,
                        Year = repo.Year
                    });
                }

                result.SetResult(cars);
            }
            catch (Exception ex)
            {
                result.AddError("Unexpected error while executing reques", $"Unexpected error while executing request {ex.Message} {ex.StackTrace}");
            }

            return result;
        }
    }
}
