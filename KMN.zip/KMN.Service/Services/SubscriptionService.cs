﻿using KMN.Domain.Entities;
using KMN.Domain.Result;
using KMN.Persistence.Repositories.Contract;
using KMN.Service.Contract;
using KMN.Service.Outbound.Notification;
using Softmark.Shared.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using Softmark.Shared.Domain.Utilities;
using System;
using System.Collections.Generic;
using System.Data.Entity.Spatial;
using System.Linq;
using System.Threading.Tasks;

namespace KMN.Service.Services
{
    public partial class SubscriptionService : ISubscriptionService
    {
        private readonly ISubscriberRepository _repository;  
        private readonly IRiderRepository _rider;  // 
        private readonly INotification _notification;  // 

        public SubscriptionService(ISubscriberRepository repository, IRiderRepository rider, INotification notification)
        {
            _repository = repository;
            _rider = rider;
            _notification = notification;
        }

        public static readonly Func<IEnumerable<Domain.Entities.RiderContact>, IEnumerable<RiderContactInfoResult>> _riderContactsResult = (serv) =>
        {
            var contacts = new List<RiderContactInfoResult>();

            if (serv == null) return null;

            foreach (var c in serv)
            {
                contacts.Add(
                     new RiderContactInfoResult
                     {
                         ContactId = c.ContactId,
                         RiderId = c.RiderId,
                         Address = c.Address,
                         CityOrLGA = c.CityOrLGA,
                         State = c.State,
                         PrimaryPhoneNo = c.PrimaryPhoneNo,
                         SecondaryPhoneNo = c.SecondaryPhoneNo,
                         Email = c.Email,
                         EmergencyContactName = c.EmergencyContactName,
                         EmergencyPhoneNumber = c.EmergencyPhoneNumber
                     }
                   );
            }

            return contacts;
        };

        public static readonly Func<IEnumerable<Domain.Entities.VehicleInformation>, IEnumerable<RiderVehicleInfoResult>> _riderVehiclesResult = (serv) =>
        {
            var contacts = new List<RiderVehicleInfoResult>();

            if (serv == null) return null;

            foreach (var v in serv)
            {
                contacts.Add(
                     new RiderVehicleInfoResult
                     {
                         VehicleInformationId = v.VehicleInformationId,
                         RiderId = v.RiderId,
                         CarDataId = v.CarDataId,
                         NumberOfPassenger = v.NumberOfPassenger,
                         PlateNumber = v.PlateNumber,
                         ChasisNumber = v.ChasisNumber
                     }
                   );
            }

            return contacts;
        };

        public static readonly Func<IEnumerable<Domain.Entities.Subscriber>, IEnumerable<SubscriberInforesult>> _subscribersResult = (serv) =>
        {
            var subscribers = new List<SubscriberInforesult>();

            if (serv == null) return null;

            foreach (var c in serv)
            {
                subscribers.Add(
                     new SubscriberInforesult
                     {
                         SubscriberId = c.SubscriberId,
                         SubscriptionId = c.SubscriptionId,
                         PassengerRouteId = c.PassengerRouteId,
                         AgreedFare = c.AgreedFare,
                         DriverApproval = c.DriverApproval,
                         PassengerApproval = c.PassengerApproval,
                         Notes = c.Notes
                     }
                   );
            }

            return subscribers;
        };

        public static readonly Func<IEnumerable<Domain.Entities.PassengerRoute>, IEnumerable<PassengerRouteInforesult>> _passengersResult = (serv) =>
        {
            var subscribers = new List<PassengerRouteInforesult>();

            if (serv == null || serv.Count() == 0) return null;

            foreach (var db in serv)
            {
                subscribers.Add(
                     new PassengerRouteInforesult
                     {
                          PassengerRouteId = db.PassengerRouteId
                        , RiderId = db.RiderId
                        , PassengerNames =  db.PassengerNames
                        , PassengerEmail =  db.PassengerEmail
                        , PassengerPhone =  db.PassengerPhone 
                        , PickupLocation =  db.PickupLocation
                        , DropOffLocation = db.DropOffLocation
                        , EstimatedPickupDateTime =  db.EstimatedPickupDateTime
                        , DriverApproval = db.RequestStatus 
                        , RiderType = db.RiderType 
                        , BaseFare = db.BaseFare
                        , Notes = db.Notes
                     });
            }

            return subscribers;
        };

        public async Task<ServiceResult<AddSubscriptionInfoResult>> AddSubscriptionAsync(Subscription sub)
        {
            var result = new ServiceResult<AddSubscriptionInfoResult>();
            try
              {
                // check if no date clashing 
                var subRec = await _repository.GetSubscriptionElapseAsync(sub).ConfigureAwait(false);
                if (subRec != null) return result.AddError($"Your existing subscription elapse with the specified detail: ({subRec.First().EstimatedPickupDateTime}) already exist"
                   , $"Your existing subscription elapse with the specified detail: ({subRec.First().EstimatedPickupDateTime}) already exist");

                sub.CreatedBy = SoftUtil.GetGuid();
                sub.LastUpdatedBy = SoftUtil.GetGuid();
                sub.DateCreated = DateTime.Now;
                sub.LastUpdatedDate = DateTime.Now;

                // check if rider contact detail is complete
                var rContact = await _rider.GetRiderContactByRiderIdAsync(sub.RiderId);
                if (rContact == null) return result.AddError("You need to update your contact information to complete this request"
                                                            ,"You need to update your contact information to complete this request");

                // for Driver: check if rider vehicle info is complete
                if (sub.RiderType == EntityRiderType.Driver)
                {
                    var rVehicle = await _rider.GetRiderVehicleByRiderIdAsync(sub.RiderId, sub.VehicleId);
                    if (rVehicle == null) return result.AddError("You need to update your vehicle information to complete this request"
                                                               , "You need to update your vehicle information to complete this request");

                    // check plate number, Chasis, PassengerCount, CarDataId, Status
                    if (rVehicle != null && (string.IsNullOrEmpty(rVehicle.PlateNumber) || string.IsNullOrEmpty(rVehicle.ChasisNumber) || rVehicle.NumberOfPassenger == 0))
                           return result.AddError("You need to update your vehicle information to cmplete this request"
                                                              , "You need to update your vehicle information to complete this request");
                }
               
                var repo = await _repository.CreateSubscriptionAsync(sub).ConfigureAwait(false);
                if (repo)
                {
                    var res = new AddSubscriptionInfoResult
                    {
                        TransactionId  = SoftUtil.GetGuid(),
                        SubscriptionId = sub.SubscriptionId,
                    };
                    result.SetResult(res);
                }
            }
            catch (Exception ex)
            {
                result.AddError($"Unexpected exception while creating driver subscription {ex.Message} {ex.StackTrace}", $"Unexpected exception while creating driver subscription {ex.Message} {ex.StackTrace}");
            }

            return result;
        }

        public async Task<ServiceResult<AddSubscriptionInfoResult>> AddSubscriptionAsync(PassengerRoute sub)
        {
            var result = new ServiceResult<AddSubscriptionInfoResult>();
            try
            {
                // check if no date clashing 
                var subRec = await _repository.GetSubscriptionElapseAsync(sub).ConfigureAwait(false);
                if (subRec != null) return result.AddError($"Your existing subscription elapse with the specified detail: ({subRec.First().EstimatedPickupDateTime}) already exist"
                   , $"Your existing subscription elapse with the specified detail: ({subRec.First().EstimatedPickupDateTime}) already exist");

                sub.CreatedBy = SoftUtil.GetGuid();
                sub.LastUpdatedBy = SoftUtil.GetGuid();
                sub.DateCreated = DateTime.Now;
                sub.LastUpdatedDate = DateTime.Now;

                // check if rider contact detail is complete
                var rContact = await _rider.GetRiderContactByRiderIdAsync(sub.RiderId);
                if (rContact == null) return result.AddError("You need to update your contact information to complete this request"
                                                            , "You need to update your contact information to complete this request");

                var repo = await _repository.CreateSubscriptionAsync(sub).ConfigureAwait(false);
                if (repo)
                {
                    var res = new AddSubscriptionInfoResult
                    {
                        TransactionId = SoftUtil.GetGuid(),
                        SubscriptionId = sub.PassengerRouteId,
                    };
                    result.SetResult(res);
                }
            }
            catch (Exception ex)
            {
                result.AddError($"Unexpected exception while creating passenger subscription {ex.Message} {ex.StackTrace}", $"Unexpected exception while creating passenger subscription {ex.Message} {ex.StackTrace}");
            }

            return result;
        }

        public async Task<ServiceResult<IEnumerable<DriverSubscriptionInfoResult>>> GetDriverSubscriptionListAsync(DbGeography pickUpLocation, DbGeography dropOffLocation, double kilometers, EntityRequestStatus requestStatus)
        {
            var riderSubscriptions = new List<DriverSubscriptionInfoResult>();
            var result = new ServiceResult<IEnumerable<DriverSubscriptionInfoResult>>();
            try
            {
                var subscriptions = await _repository.GetDriverSubscriptionAsync(pickUpLocation,dropOffLocation,requestStatus,kilometers).ConfigureAwait(false);
                if(subscriptions != null)
                {
                    foreach (var subscript in subscriptions)
                    {
                        var driverData = await _repository.GetDriverDataAsync(subscript.SubscriptionId).ConfigureAwait(false);

                        if(driverData != null)
                        {
                            var subscriptInfo = new DriverSubscriptionInfoResult
                            {
                                SubscriptionId = subscript.SubscriptionId,
                                RiderId = subscript.RiderId,
                                DriverNames = $"{driverData.FirstName} {driverData.LastName}",
                                DriverEmail = driverData.Email,
                                DriverPhone = driverData.PrimaryPhoneNumber,
                                VehicleId = subscript.VehicleId,
                                PickupLocation = subscript.PickupLocation,
                                DropOffLocation = subscript.DropOffLocation,
                                EstimatedPickupDateTime = subscript.EstimatedPickupDateTime,
                                EstimatedDroppOffDateTime = subscript.EstimatedDroppOffDateTime,
                                MaxPassengerAllowed = subscript.MaxPassengerAllowed,
                                BaseFare = subscript.BaseFare,
                                RequestStatus = subscript.RequestStatus,
                                Notes = subscript.Notes
                            }; 

                            var subscribers = _subscribersResult(subscript.Subscribers);
                            if (subscribers != null)
                            {
                                var subscriberInfo = new List<SubscriberInforesult>();
                                foreach (var sub in subscribers)
                                {
                                    var passengerData = await _repository.GetPassengerDataAsync(sub.PassengerRouteId).ConfigureAwait(false);
                                    if(passengerData != null)
                                    {
                                        //subscriptInfo.Subscribers
                                        subscriberInfo.Add(new SubscriberInforesult
                                        {
                                            SubscriberId = sub.SubscriberId,
                                            SubscriptionId = sub.SubscriptionId,
                                            PassengerNames = $"{passengerData.FirstName} {passengerData.LastName}",
                                            PassengerEmail = passengerData.Email,
                                            PassengerPhone = passengerData.PrimaryPhoneNumber,
                                            PassengerRouteId = sub.PassengerRouteId,
                                            AgreedFare = sub.AgreedFare,
                                            DriverApproval = sub.DriverApproval,
                                            PassengerApproval = sub.PassengerApproval,
                                            Notes = sub.Notes
                                        });
                                    }
                                }

                                subscriptInfo.Subscribers = subscriberInfo;
                            }

                            riderSubscriptions.Add(subscriptInfo);
                        }
                    }
                }

                result.SetResult(riderSubscriptions);
            }
            catch (Exception ex)
            {
                result.AddError($"Unexpected exception while executing request {ex.Message} {ex.StackTrace}", $"Unexpected exception while executing request {ex.Message} {ex.StackTrace}");
            }

            return result;
        }

        public async Task<ServiceResult<IEnumerable<PassengerRouteInforesult>>> GetPassengerSubscriptionListAsync(DbGeography pickUpLocation, DbGeography dropOffLocation, double kilometers, EntityRequestStatus requestStatus)
        {
            var result = new ServiceResult<IEnumerable<PassengerRouteInforesult>>();
            try
            {
                var passengers = await _repository.GetPassengerRouteAsync(pickUpLocation, dropOffLocation, requestStatus, kilometers).ConfigureAwait(false);
                result.SetResult(_passengersResult(passengers));
            }
            catch (Exception ex)
            {
                result.AddError($"Unexpected exception while executing request {ex.Message} {ex.StackTrace}", $"Unexpected exception while executing request {ex.Message} {ex.StackTrace}");
            }

            return result;
        }

        public async Task<ServiceResult<DriverJoinRequestInforesult>> DriverJoinRequestAsync(Guid subscriptionId, Guid passengerRouteId)
        {
            var result = new ServiceResult<DriverJoinRequestInforesult>();
           
            try
            {
                var subscription = await _repository.GetSubscriptionByIdAsync(subscriptionId).ConfigureAwait(false);
                if(subscription == null)
                    return result.AddError($"Your driver subscription does not exist" , $"Your subscription does not exist");

                var passengerRoute = await _repository.GetPassengerRouteByIdAsync(passengerRouteId).ConfigureAwait(false);
                if (passengerRoute == null)
                    return result.AddError($"Your passenger subscription does not exist" , $"Your passenger does not exist");



                var IsSubscriberExist = await _repository.GetSubscribersBySubscriptionAndPassengerIdAsync(subscriptionId, passengerRouteId).ConfigureAwait(false);
                if (IsSubscriberExist != null)
                     return result.AddError($"The specific subscription already submitted! with Driver Status : {IsSubscriberExist.DriverApproval.ToString()} and Passenger status : {IsSubscriberExist.PassengerApproval.ToString()}"
                               , $"The specific subscription already submitted! with Driver flag as {IsSubscriberExist.DriverApproval.ToString()} and Passenger flag as {IsSubscriberExist.PassengerApproval.ToString()}");

                var subscriber = new Subscriber
                {
                     SubscriberId =  SoftUtil.GetGuid()
                    ,SubscriptionId =  subscriptionId
                    ,PassengerRouteId =  passengerRouteId 
                    ,DriverApproval = EntityRequestStatus.Approved
                    ,PassengerApproval = EntityRequestStatus.AwaitingApproval 
                    ,AgreedFare =  subscription.BaseFare 
                    ,Notes =  $"Driver Note: {subscription.Notes}.  Passenger Note : {passengerRoute.Notes}"
                };
                var sub = await _repository.CreateSubscriberAsync(subscriber).ConfigureAwait(false);
                if (sub)
                {
                    var subResult = new DriverJoinRequestInforesult
                    {
                        SubscriberId = subscriber.SubscriberId,
                        PassengerRouteId = passengerRoute.PassengerRouteId,
                        SubscriptionId = subscription.SubscriptionId
                    };

                    result.SetResult(subResult);

                    // use RiderId in PassengerRoute and Subscription to get User email from Rider
                    var riderPassenger = await _rider.GetRiderById(passengerRoute.RiderId).ConfigureAwait(false);
                    if(riderPassenger != null)
                    {
                        NotificationRequest notifyPassenger = new NotificationRequest
                        {
                            RecipientId = riderPassenger.Email,
                            MessageBody = "A driver is awaiting your aproval for a trip.",
                            MessageTitle = "KMN (Subscription)"
                        };
                        _notification.SendNotification(notifyPassenger).ConfigureAwait(false);  // no need to wait
                    }

                    var riderDriver = await _rider.GetRiderById(subscription.RiderId).ConfigureAwait(false);
                    if(riderDriver != null)
                    {
                        NotificationRequest notifyDriver = new NotificationRequest
                        {
                            RecipientId = riderDriver.Email,
                            MessageBody = "A driver is awaiting your aproval for a trip.",
                            MessageTitle = "KMN (Subscription)"
                        };

                        _notification.SendNotification(notifyDriver).ConfigureAwait(false); // no need to wait
                    }
                }
            }
            catch (Exception ex)
            {
                result.AddError($"Unexpected exception while executing request {ex.Message} {ex.StackTrace}", $"Unexpected exception while executing request {ex.Message} {ex.StackTrace}");
            }

            return result;
        }
    }
}
