﻿using KMN.Domain.Entities;
using KMN.Domain.Result;
using KMN.Persistence.Repositories.Contract;
using KMN.Service.Contract;
using Softmark.Shared.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using Softmark.Shared.Domain.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KMN.Service.Services
{
    public partial class RiderService : IRiderService
    {
        private readonly IRiderRepository _repository;
        private readonly ISystemEntitiesRepository _systemRepository;

        public RiderService(IRiderRepository repository, ISystemEntitiesRepository systemRepository)
        {
            _repository = repository;
            _systemRepository = systemRepository;
        }

        public static readonly Func<IEnumerable<Domain.Entities.RiderContact>, IEnumerable<RiderContactInfoResult>> _riderContactsResult = (serv) =>
        {
            var contacts = new List<RiderContactInfoResult>();

            if (serv == null) return null;

            foreach (var c in serv)
            {
                contacts.Add(
                     new RiderContactInfoResult
                     {
                         ContactId = c.ContactId,
                         RiderId = c.RiderId,
                         Address = c.Address,
                         CityOrLGA = c.CityOrLGA,
                         State = c.State,
                         PrimaryPhoneNo = c.PrimaryPhoneNo,
                         SecondaryPhoneNo = c.SecondaryPhoneNo,
                         Email = c.Email,
                         EmergencyContactName = c.EmergencyContactName,
                         EmergencyPhoneNumber = c.EmergencyPhoneNumber
                     }
                   );
            }

            return contacts;
        };

        public static readonly Func<IEnumerable<Domain.Entities.VehicleInformation>, IEnumerable<RiderVehicleInfoResult>> _riderVehiclesResult = (serv) =>
        {
            var contacts = new List<RiderVehicleInfoResult>();

            if (serv == null) return null;

            foreach (var v in serv)
            {
                contacts.Add(
                     new RiderVehicleInfoResult
                     {
                         VehicleInformationId = v.VehicleInformationId,
                         RiderId = v.RiderId,
                         CarDataId = v.CarDataId,
                         NumberOfPassenger = v.NumberOfPassenger,
                         PlateNumber = v.PlateNumber,
                         ChasisNumber = v.ChasisNumber
                     }
                   );
            }

            return contacts;
        };

        public async Task<ServiceResult<AddRiderInfoResult>> AddRiderAsync(Rider rider)
        {
            var result = new ServiceResult<AddRiderInfoResult>();
            try
            {
                var riderRec = await _repository.GetRiderByEmail(rider.Email).ConfigureAwait(false);
                if (riderRec != null ) return result.AddError($"Rider with the specified detail: ({rider.Email}) already exist"
                    , $"Rider with the specified detail: ({rider.Email}) already exist");

                rider.CreatedBy = SoftUtil.GetGuid();
                rider.LastUpdatedBy = SoftUtil.GetGuid();
                rider.DateCreated = DateTime.Now;
                rider.LastUpdatedDate = DateTime.Now;

                // set Ids 
                foreach(var contact in rider.Contacts)
                {
                    contact.ContactId = SoftUtil.GetGuid();
                    contact.RiderId = rider.RiderId;
                }

                foreach (var vInfo in rider.VehicleInfo )
                {
                    vInfo.VehicleInformationId = SoftUtil.GetGuid();
                    vInfo.RiderId = rider.RiderId;
                }

                var repo = await _repository.CreateRiderAsync(rider).ConfigureAwait(false);
                if (repo != null)
                {
                    var res = new AddRiderInfoResult
                    {
                        TransactionId  = SoftUtil.GetGuid(),
                        RiderId = repo.RiderId,
                        RiderNumber = repo.RiderNumber ,
                        Contacts =  rider.Contacts.Select(x=> x.ContactId).ToArray(),
                        VehicleInfoIds =  rider.VehicleInfo.Select(x=>x.VehicleInformationId).ToArray()
                    };
                    result.SetResult(res);
                }
            }
            catch (Exception ex)
            {
                result.AddError($"Unexpected exception while creating rider {ex.Message} {ex.StackTrace}", $"Unexpected exception while creating rider {ex.Message} {ex.StackTrace}");
            }

            return result;
        }

        public async Task<ServiceResult<GetRiderInfoResult>> GetRiderByIdAsync(Guid riderId)
        {
            var result = new ServiceResult<GetRiderInfoResult>();
            try
            {
                var repo = await _repository.GetRiderById(riderId).ConfigureAwait(false);

                if (repo == null) return result.AddError($"Rider with the specified Id was not found!"
                    , $"Rider with the specified id: ({riderId}) does not exist exist");

                if (repo != null)
                {
                    var vresults = _riderVehiclesResult(repo.VehicleInfo);
                    foreach(var v in vresults)
                    {
                        var CarInfo = await _systemRepository.GetCarsById(v.CarDataId).ConfigureAwait(false);
                        if(CarInfo != null)
                        {
                            v.CarCode = CarInfo.CarCode;
                            v.Make = CarInfo.Make;
                            v.Year = CarInfo.Year;
                            v.ModelYear = CarInfo.ModelYear;
                        }
                    }

                    var res = new GetRiderInfoResult
                    {
                        RiderId = repo.RiderId,
                        UserName = repo.UserName,
                        RiderNumber = repo.RiderNumber,
                        FirstName = repo.FirstName,
                        MiddleName = repo.MiddleName,
                        LastName = repo.LastName,
                        Email = repo.Email, 
                        PrimaryPhoneNumber = repo.PrimaryPhoneNumber,
                        SecondaryPhoneNumber = repo.SecondaryPhoneNumber,
                        Occupation = repo.Occupation,
                        Notes = repo.Notes,
                        Contacts = _riderContactsResult(repo.Contacts),
                        Vehicles = vresults
                    };
                    result.SetResult(res);
                }
            }
            catch (Exception ex)
            {
                result.AddError("Unexpected exception while fetching rider", $"Unexpected exception while fetching rider {ex.Message} {ex.StackTrace}");
            }

            return result;
        }

        public async Task<ServiceResult<GetRiderInfoResult>> GetRiderByEmailAsync(string email)
        {
            var result = new ServiceResult<GetRiderInfoResult>();
            try
            {
                var repo = await _repository.GetRiderByEmail(email).ConfigureAwait(false);

                if (repo == null) return result.AddError($"Rider with the specified email was not found!"
                    , $"Rider with the specified email: ({email}) does not exist exist");

                if (repo != null)
                {
                    var vresults = _riderVehiclesResult(repo.VehicleInfo);
                    foreach (var v in vresults)
                    {
                        var CarInfo = await _systemRepository.GetCarsById(v.CarDataId).ConfigureAwait(false);
                        if (CarInfo != null)
                        {
                            v.CarCode = CarInfo.CarCode;
                            v.Make = CarInfo.Make;
                            v.Year = CarInfo.Year;
                            v.ModelYear = CarInfo.ModelYear;
                        }
                    }

                    var res = new GetRiderInfoResult
                    {
                        RiderId = repo.RiderId,
                        UserName = repo.UserName,
                        RiderNumber = repo.RiderNumber,
                        FirstName = repo.FirstName,
                        MiddleName = repo.MiddleName,
                        LastName = repo.LastName,
                        Email = repo.Email,
                        PrimaryPhoneNumber = repo.PrimaryPhoneNumber,
                        SecondaryPhoneNumber = repo.SecondaryPhoneNumber,
                        Occupation = repo.Occupation,
                        Notes = repo.Notes,
                        Contacts = _riderContactsResult(repo.Contacts),
                        Vehicles =  vresults 
                    };
                    result.SetResult(res);
                }
            }
            catch (Exception ex)
            {
                result.AddError($"Unexpected exception while fetching rider {ex.Message} {ex.StackTrace}", $"Unexpected exception while fetching rider {ex.Message} {ex.StackTrace}");
            }

            return result;
        }

        public async Task<ServiceResult<IEnumerable<GetRiderInfoResult>>> GetAllRidersAsync(EntityStatus? status)
        {
            var riders = new List<GetRiderInfoResult>();

            var result = new ServiceResult<IEnumerable<GetRiderInfoResult>>();
            try
            {
                var repos = await _repository.GetAllRiders (status).ConfigureAwait(false);

                if (repos != null)
                {
                    foreach (var repo in repos)
                    {
                        var vresults = _riderVehiclesResult(repo.VehicleInfo);
                        foreach (var v in vresults)
                        {
                            var CarInfo = await _systemRepository.GetCarsById(v.CarDataId).ConfigureAwait(false);
                            if (CarInfo != null)
                            {
                                v.CarCode = CarInfo.CarCode;
                                v.Make = CarInfo.Make;
                                v.Year = CarInfo.Year;
                                v.ModelYear = CarInfo.ModelYear;
                            }
                        }

                        var rider = new GetRiderInfoResult
                        {

                            RiderId = repo.RiderId,
                            RiderNumber = repo.RiderNumber,
                            UserName =  repo.UserName,
                            FirstName = repo.FirstName,
                            MiddleName = repo.MiddleName,
                            LastName = repo.LastName,
                            Email = repo.Email,
                            PrimaryPhoneNumber = repo.PrimaryPhoneNumber,
                            SecondaryPhoneNumber = repo.SecondaryPhoneNumber,
                            Occupation = repo.Occupation,
                            Notes = repo.Notes,
                            Contacts = _riderContactsResult(repo.Contacts),
                            Vehicles =  vresults 
                        };
                        riders.Add(rider);
                    }
                }

                result.SetResult(riders);
            }
            catch (Exception ex)
            {
                result.AddError("Unexpected exception while fetching rider", $"Unexpected exception while fetching rider {ex.Message} {ex.StackTrace}");
            }

            return result;
        }

        public async Task<ServiceResult<IEnumerable<UpdateRiderContactInfoResult>>> UpdateRiderContactAsync(IEnumerable<RiderContact> contacts)
        {
            var resultList = new List<UpdateRiderContactInfoResult>() ;
            var result = new ServiceResult<IEnumerable<UpdateRiderContactInfoResult>>();
            try
            {
                foreach(var contact in contacts)
                {
                    var repo = await _repository.UpdateRiderContactAsync(contact).ConfigureAwait(false);
                    resultList.Add( new UpdateRiderContactInfoResult
                    {
                        TransactionId = SoftUtil.GetGuid(),
                        RiderId = contact.RiderId,
                        ContactId  = contact.ContactId,
                        IsUpdated =  repo
                    });
                }

                result.SetResult(resultList);
            }
            catch (Exception ex)
            {
                result.AddError("Unexpected exception while updating rider contact", $"Unexpected exception while updating rider contact {ex.Message} {ex.StackTrace}");
            }

            return result;
        }

        public async Task<ServiceResult<IEnumerable<UpdateRiderContactInfoResult>>> AddRiderContactAsync(IEnumerable<RiderContact> contacts)
        {
            var resultList = new List<UpdateRiderContactInfoResult>();
            var result = new ServiceResult<IEnumerable<UpdateRiderContactInfoResult>>();
            try
            {
                foreach (var contact in contacts)
                {
                    contact.ContactId = SoftUtil.GetGuid();
                    var repo = await _repository.AddRiderContactAsync(contact).ConfigureAwait(false);
                    resultList.Add(new UpdateRiderContactInfoResult
                    {
                        TransactionId = SoftUtil.GetGuid(),
                        RiderId = contact.RiderId,
                        ContactId = contact.ContactId,
                        IsUpdated = repo
                    });
                }

                result.SetResult(resultList);
            }
            catch (Exception ex)
            {
                result.AddError("Unexpected exception while Adding rider contact", $"Unexpected exception while updating rider contact {ex.Message} {ex.StackTrace}");
            }

            return result;
        }
    }
}
