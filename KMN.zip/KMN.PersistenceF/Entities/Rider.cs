﻿using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;

namespace KMN.Persistence.Entities
{
    public class Rider : PersistenceEntity
    {
        public Guid RiderId { get; set; }
        public string RiderNumber { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public EntityGender Gender { get; set; }
        public string Email { get; set; }
        public string PrimaryPhoneNumber { get; set; }
        public string SecondaryPhoneNumber { get; set; }
        public Guid TakeOffLocationId { get; set; }
        public Guid DestinationLocationId { get; set; }
        public string Occupation { get; set; }
        public string Notes { get; set; }
        public virtual ICollection<RiderContact> Contacts { get; set; }
        public virtual ICollection<VehicleInformation> VehicleInformations { get; set; }
    }

    public class VehicleInformation : PersistenceEntity
    {
        public Guid VehicleInformationId { get; set; }
        public Guid RiderId { get; set; }
        public Guid CarDataId { get; set; }
        public int NumberOfPassenger { get; set; }
        public string PlateNumber { get; set; }
        public string ChasisNumber { get; set; }
    }

    public class RiderContact : PersistenceEntity
    {
        public Guid RiderContactId { get; set; }
        public Guid RiderId { get; set; }
        public string Address { get; set; }
        public Guid CityOrLGA { get; set; }
        public Guid State { get; set; }
        public string PrimaryPhoneNo { get; set; }
        public string SecondaryPhoneNo { get; set; }
        public string Email { get; set; }
        public string EmergencyContactName { get; set; }
        public string EmergencyPhoneNumber { get; set; }
    }
}
