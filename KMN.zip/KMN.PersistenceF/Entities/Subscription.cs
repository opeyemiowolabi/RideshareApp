﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Spatial;
using Softmark.Shared.Domain.Enum;

namespace KMN.Persistence.Entities
{
    public class Subscription : PersistenceEntity
    {
        public Guid SubscriptionId { get; set; }  
        public Guid RiderId { get; set; }  // driver UserId
        public Guid VehicleId { get; set; }
        public DbGeography PickupLocation { get; set; } // Coordinate
        public DbGeography DropOffLocation { get; set; } // Coordinate
        public DateTime?  EstimatedPickupDateTime { get; set; }
        public DateTime? EstimatedDroppOffDateTime { get; set; }
        public int MaxPassengerAllowed { get; set; } = 1;
        public EntityRiderType  RiderType { get; set; }  // (Not needed now)
        public decimal BaseFare { get; set; } = 0.00M;
        public EntityRequestStatus RequestStatus { get; set; }
        public string Notes { get; set; } // notes should be appended/concatenated 
        public virtual ICollection<Subscriber> Subscribers { get; set; } // passengers
    }

    public class Subscriber : PersistenceEntity
    {
        public Guid SubscriberId { get; set; }  
        public Guid SubscriptionId { get; set; } 
        public Guid PassengerRouteId { get; set; }
        public decimal AgreedFare { get; set; } = 0.00M;
        public EntityRequestStatus DriverApproval { get; set; } 
        public EntityRequestStatus PassengerApproval { get; set; }
        public string Notes { get; set; }  // notes should be appended/concatenated 
    }

    public class PassengerRoute : PersistenceEntity
    {
        public Guid PassengerRouteId { get; set; }
        public Guid RiderId { get; set; }  // passenger UserId
        public DbGeography PickupLocation { get; set; } // Coordinate
        public DbGeography DropOffLocation { get; set; } // Coordinate
        public DateTime? EstimatedPickupDateTime { get; set; }
        public EntityRiderType RiderType { get; set; }  // (Not needed now)
        public decimal BaseFare { get; set; } = 0.00M;
        public EntityRequestStatus RequestStatus { get; set; }
        public string Notes { get; set; } // notes should be appended/concatenated 
    }
}