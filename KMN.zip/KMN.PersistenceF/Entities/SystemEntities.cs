﻿using Softmark.Shared.Domain.Enum;
using System;
using System.ComponentModel.DataAnnotations;

namespace KMN.Persistence.Entities
{
    public class CarData : PersistenceEntity
    {
        public Guid CarDataId { get; set; }
        public string CarCode { get; set; }
        public string Make { get; set; }
        public string Year { get; set; }
        public string ModelYear { get; set; }
    }

    public class State : PersistenceEntity
    {
        public Guid CarId { get; set; }
        public Guid CarCode { get; set; }
        public string Make { get; set; }
    }

    public class LGA : PersistenceEntity
    {
        public Guid CarId { get; set; }
        public Guid CarCode { get; set; }
        public string Make { get; set; }
    }

}