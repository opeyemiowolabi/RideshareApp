﻿using System;
using System.Data.Entity;
using KMN.Persistence.Entities;
using System.Linq;
using System.Threading.Tasks;
using Softmark.Shared.Domain.Entities;
using System.Configuration;

namespace KMN.Persistence
{
    public class KMNDBContext : DbContext
    {
        static readonly string  connectionString =  ConfigurationManager.AppSettings["dbConnection"];//"Data Source=SOFTMARK;Initial Catalog=KMNdb;User ID=dev;Password=devuser";
        public KMNDBContext() : base(nameOrConnectionString: connectionString)
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<KMNDBContext, KMN.PersistenceF.Migrations.Configuration>());
        }

        public override int SaveChanges()
        {
            AttachTrackingInformation();
            return base.SaveChanges();
        }

        public override Task<int> SaveChangesAsync()
        {
            AttachTrackingInformation();
            return base.SaveChangesAsync();
        }

        private void AttachTrackingInformation()
        {
            var changedEntities = this.ChangeTracker.Entries().Where(e => e.State == EntityState.Modified);
            var newEntites = this.ChangeTracker.Entries().Where(e => e.State == EntityState.Added);

            foreach (var entry in newEntites)
            {
                if (entry?.Entity is PersistenceEntityWithoutKey)
                {
                    var persistenceEntity = entry.Entity as PersistenceEntityWithoutKey;
                    persistenceEntity.CreatedTimestamp = DateTimeOffset.Now;
                }
            }
            foreach (var entry in changedEntities)
            {
                if (entry?.Entity is PersistenceEntityWithoutKey)
                {
                    var persistenceEntity = entry.Entity as PersistenceEntityWithoutKey;
                    persistenceEntity.ModifiedTimestamp = DateTimeOffset.Now;
                }
            }
        }

        public IDbSet<Rider> Riders { get; set; }
        public IDbSet<RiderContact> RiderContacts { get; set; }
        public IDbSet<VehicleInformation> VehicleInformations { get; set; }
        public IDbSet<Notification> Notifications { get; set; }
        public IDbSet<Subscription> Subscriptions { get; set; }
        public IDbSet<Subscriber> Subscribers { get; set; }
        public IDbSet<PassengerRoute> PassengerRoutes { get; set; }

        // System tables
        public IDbSet<CarData> Cars { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}