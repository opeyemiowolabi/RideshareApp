﻿using KMN.Domain.Entities;
using KMN.Persistence.Mappers;
using KMN.Persistence.Repositories.Contract;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KMN.Persistence.Repositories
{
    public class RiderRepository : IRiderRepository
    {
        private RiderPersistentWrapper _mapper = new RiderPersistentWrapper();
        private readonly KMNDBContext _dbContext;

        private IDbSet<Entities.Rider> Riders { get; }
        private IDbSet<Entities.RiderContact> RiderContacts { get; }
        private IDbSet<Entities.VehicleInformation> VehicleInformations { get; }

        public RiderRepository(KMNDBContext dbContext)
        {
            _dbContext = dbContext;
            Riders = dbContext.Set<Entities.Rider>();
            RiderContacts = dbContext.Set<Entities.RiderContact>();
            VehicleInformations = dbContext.Set<Entities.VehicleInformation>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="rider"></param>
        /// <returns></returns>
        public async Task<Rider> CreateRiderAsync(Rider rider)
        {
            rider.Status = EntityStatus.Active;
            var entity = _mapper.Map(rider);
            Riders.Add(entity);
            int result = await _dbContext.SaveChangesAsync().ConfigureAwait(false);
            return _mapper.Map(entity);
        }

        public async Task<bool> UpdateRiderById(Rider rider)
        {
            var dbRider = await Riders.FirstOrDefaultAsync(x => x.RiderId == rider.RiderId);

            if (dbRider != null)
            {
                dbRider.FirstName = rider.FirstName;
                dbRider.LastName = rider.LastName;
                dbRider.MiddleName = rider.MiddleName;
                dbRider.PrimaryPhoneNumber = rider.PrimaryPhoneNumber;
                dbRider.LastUpdatedDate = DateTime.Now;

                var count = await _dbContext.SaveChangesAsync().ConfigureAwait(false);
                return count != 0;
            }

            return false;
        }

        public async Task<IEnumerable<Rider>> GetRiderByFirstNameorNumberorEmail(string firstName, string riderNumber, string email)
        {
            var dbRiders = await Riders.Where(x => x.FirstName == firstName || x.RiderNumber == riderNumber || x.Email == email).ToListAsync().ConfigureAwait(false);

            return dbRiders == null || dbRiders.Count == 0 ? null : _mapper.Map(dbRiders);
        }
         
        public async Task<Rider> GetRiderByEmail(string email)
        {
            var dbRider = await Riders.FirstOrDefaultAsync(x => x.Email == email).ConfigureAwait(false);
            if(dbRider != null)
            {
                var contacts = await GetRiderContactByRiderIdAsync(dbRider.RiderId).ConfigureAwait(false); ;
                dbRider.Contacts = _mapper.Map(contacts).ToList();

                var vehicles = await GetRiderVehicleByRiderIdAsync(dbRider.RiderId).ConfigureAwait(false); ;
                dbRider.VehicleInformations = _mapper.Map(vehicles).ToList();
            }
            
            return _mapper.Map(dbRider);
        }

        public async Task<Rider> GetRiderById(Guid riderId)
        {
            var dbRider = await Riders.FirstOrDefaultAsync(x => x.RiderId == riderId).ConfigureAwait(false);
            if(dbRider != null)
            {
                var contacts = await GetRiderContactByRiderIdAsync(dbRider.RiderId).ConfigureAwait(false); ;
                dbRider.Contacts = _mapper.Map(contacts).ToList();

                var vehicles = await GetRiderVehicleByRiderIdAsync(dbRider.RiderId);
                dbRider.VehicleInformations = _mapper.Map(vehicles).ToList();
            }
          
            return _mapper.Map(dbRider);
        }

        public async Task<IEnumerable<Rider>> GetAllRiders(EntityStatus? status)
        {
            IEnumerable<Entities.Rider> dbRiders = status == null ? dbRiders = await Riders.ToListAsync().ConfigureAwait(false)
                 : dbRiders = await Riders.Where(x => x.Status == status).ToListAsync().ConfigureAwait(false);

            if(dbRiders != null)
            {
                foreach (var dbRider in dbRiders)
                {
                    var contacts = await GetRiderContactByRiderIdAsync(dbRider.RiderId).ConfigureAwait(false);
                    dbRider.Contacts = _mapper.Map(contacts).ToList();

                    var vehicles = await GetRiderVehicleByRiderIdAsync(dbRider.RiderId).ConfigureAwait(false);
                    dbRider.VehicleInformations = _mapper.Map(vehicles).ToList();
                }
            }
           
            return dbRiders == null ? null : _mapper.Map(dbRiders);
        }

        public async Task<IEnumerable<RiderContact>> GetRiderContactByRiderIdAsync(Guid riderId)
        {
            var dbContacts =  await RiderContacts.Where(x => x.RiderId == riderId).ToListAsync().ConfigureAwait(false);
            return _mapper.Map(dbContacts);
        }

        public async Task<RiderContact> GetRiderContactByRiderIdAsync(Guid riderId, Guid contactId)
        {
            var dbContacts = await RiderContacts.Where(x => x.RiderId == riderId && x.RiderContactId == contactId).SingleOrDefaultAsync().ConfigureAwait(false);
            return _mapper.Map(dbContacts);
        }


        public async Task<IEnumerable<VehicleInformation >> GetRiderVehicleByRiderIdAsync(Guid riderId)
        {
            var dbVehicles = await VehicleInformations.Where(x => x.RiderId == riderId).ToListAsync().ConfigureAwait(false);
            return _mapper.Map(dbVehicles);
        }

        public async Task<VehicleInformation> GetRiderVehicleByRiderIdAsync(Guid riderId, Guid vehicleId)
        {
            var dbVehicles = await VehicleInformations.Where(x => x.RiderId == riderId && x.VehicleInformationId == vehicleId).SingleOrDefaultAsync().ConfigureAwait(false);
            return _mapper.Map(dbVehicles);
        }

        public async Task<bool> UpdateRiderContactAsync(RiderContact contact)
        {
            var riderContact = await GetRiderContactByRiderIdAsync(contact.RiderId, contact.ContactId).ConfigureAwait(false);

            if (riderContact != null)
            {
                riderContact.Address = string.IsNullOrEmpty(contact.Address) ? riderContact.Address : contact.Address;
                riderContact.PrimaryPhoneNo = string.IsNullOrEmpty(contact.PrimaryPhoneNo) ? riderContact.PrimaryPhoneNo : contact.PrimaryPhoneNo;
                riderContact.SecondaryPhoneNo = string.IsNullOrEmpty(contact.SecondaryPhoneNo) ? riderContact.SecondaryPhoneNo : contact.SecondaryPhoneNo;
                riderContact.Email = string.IsNullOrEmpty(contact.Email) ? riderContact.Email : contact.Email;
                riderContact.EmergencyContactName = string.IsNullOrEmpty(contact.EmergencyContactName) ? riderContact.EmergencyContactName : contact.EmergencyContactName;
                riderContact.EmergencyPhoneNumber = string.IsNullOrEmpty(contact.EmergencyPhoneNumber) ? riderContact.EmergencyPhoneNumber : contact.EmergencyPhoneNumber;
                riderContact.CityOrLGA = contact.CityOrLGA == null ? riderContact.CityOrLGA : contact.CityOrLGA;
                riderContact.State = contact.State == null ? riderContact.State : contact.State;
                int count = await _dbContext.SaveChangesAsync().ConfigureAwait(false);
                return count != 0;
            }

            return false;
        }

        public async Task<bool> AddRiderContactAsync(RiderContact contact)
        {
            var riderContact = await RiderContacts.FirstOrDefaultAsync(x => x.RiderId == contact.RiderId  && ( x.PrimaryPhoneNo == contact.PrimaryPhoneNo || x.Email == contact.Email) 
             && (x.Email != string.Empty )).ConfigureAwait(false);

            if (riderContact == null)
            {
                var entity = new Entities.RiderContact
                {
                    RiderId =  contact.RiderId ,
                    RiderContactId = contact.ContactId,
                    Address = contact.Address,
                    PrimaryPhoneNo = contact.PrimaryPhoneNo,
                    SecondaryPhoneNo = contact.SecondaryPhoneNo,
                    Email = contact.Email,
                    EmergencyContactName = contact.EmergencyContactName,
                    EmergencyPhoneNumber = contact.EmergencyPhoneNumber,
                    CityOrLGA = contact.CityOrLGA,
                    State = contact.State == null ? riderContact.State : contact.State
                };

                RiderContacts.Add(entity);
                int count = await _dbContext.SaveChangesAsync().ConfigureAwait(false);
                return count != 0;
            }
            return false;
        }

        public void Dispose()
        {
            _dbContext?.Dispose();
        }       
    }
}
