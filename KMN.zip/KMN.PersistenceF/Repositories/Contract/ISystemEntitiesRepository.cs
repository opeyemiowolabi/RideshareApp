﻿using KMN.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace KMN.Persistence.Repositories.Contract
{
   public interface ISystemEntitiesRepository : IDisposable
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="SystemEntitiesRepository"></param>
        /// <returns></returns>
        Task<CarData> GetCarsById(Guid carId);
        Task<CarData> GetCarsByCarCode(string carCode);
        Task<IEnumerable<CarData>> GetCarsByGroup();
        Task<IEnumerable<CarData>> GetCarsByMake(string make);
        Task<IEnumerable<CarData>> GetCarsByMakeYear(string make,string year);
        Task<IEnumerable<CarData>> GetCarsByModelYear(string modelYear);
        Task<IEnumerable<CarData>> GetAllCars();
    }
}
