﻿using KMN.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace KMN.Persistence.Repositories.Contract
{
   public interface IRiderRepository : IDisposable
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="rider"></param>
        /// <returns></returns>
        Task<Rider> CreateRiderAsync(Rider rider);
        Task<bool> UpdateRiderById(Rider rider);
        Task<IEnumerable<Rider>> GetRiderByFirstNameorNumberorEmail(string firstName, string riderNumber, string email);
        Task<Rider> GetRiderByEmail(string email);
        Task<Rider> GetRiderById(Guid riderId);
        Task<IEnumerable<Rider>> GetAllRiders(EntityStatus? status);
        Task<IEnumerable<RiderContact>> GetRiderContactByRiderIdAsync(Guid riderId);
        Task<RiderContact> GetRiderContactByRiderIdAsync(Guid riderId, Guid contactId);
        Task<bool> UpdateRiderContactAsync(RiderContact contacts);
        Task<bool> AddRiderContactAsync(RiderContact contacts);
        Task<IEnumerable<VehicleInformation>> GetRiderVehicleByRiderIdAsync(Guid riderId);
        Task<VehicleInformation> GetRiderVehicleByRiderIdAsync(Guid riderId, Guid vehicleId);

    }
}
