﻿using KMN.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Data.Entity.Spatial;
using System.Text;
using System.Threading.Tasks;

namespace KMN.Persistence.Repositories.Contract
{
   public interface ISubscriberRepository : IDisposable
    {
        Task<bool> CreateSubscriptionAsync(Subscription sub);
        Task<bool> CreateSubscriptionAsync(PassengerRoute sub);
        Task<IEnumerable<Subscription>> GetSubscriptionElapseAsync(Subscription sub);
        Task<IEnumerable<PassengerRoute>> GetSubscriptionElapseAsync(PassengerRoute sub);
        // Task<IEnumerable<PassengerRoute>> GetSubscriptionListAsync(DbGeography PickupLocation, DbGeography DropOffLocation, EntityRequestStatus RequestStatus, double? threshold);
        // Task<IEnumerable<PassengerRoute>> GetSubscriptionListAsync(DbGeography PickupLocation, EntityRequestStatus RequestStatus, double? threshold);
        // Task<IEnumerable<PassengerRoute>> GetSubscriptionListAsync(DbGeography PickupLocation, EntityRequestStatus RequestStatus);

        Task<IEnumerable<PassengerRoute>> GetPassengerRouteAsync(DbGeography PickupLocation, DbGeography DropOffLocation, EntityRequestStatus RequestStatus, double? threshold);
        Task<IEnumerable<Subscription>> GetDriverSubscriptionAsync(DbGeography PickupLocation, DbGeography DropOffLocation, EntityRequestStatus RequestStatus, double? threshold);
        Task<IEnumerable<Subscription>> GetDriverSubscriptionAsync(DbGeography PickupLocation, EntityRequestStatus RequestStatus, double? threshold);
        Task<IEnumerable<Subscription>> GetDriverSubscriptionAsync(DbGeography PickupLocation, EntityRequestStatus RequestStatus);
        Task<Rider> GetPassengerDataAsync(Guid passengerRouteId);
        Task<Rider> GetDriverDataAsync(Guid subscriptionId);
        Task<bool> CreateSubscriberAsync(Subscriber sub);

        Task<Subscription> GetSubscriptionByIdAsync(Guid subscriptionId);
        Task<PassengerRoute> GetPassengerRouteByIdAsync(Guid passengerRouteId);

        Task<Subscriber> GetSubscribersBySubscriptionAndPassengerIdAsync(Guid subscriptionId, Guid passengerRouteId);

    }
}
