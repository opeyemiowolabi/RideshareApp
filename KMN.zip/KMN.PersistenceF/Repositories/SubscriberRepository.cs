﻿using KMN.Domain.Entities;
using KMN.Persistence.Mappers;
using KMN.Persistence.Repositories.Contract;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Spatial;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KMN.Persistence.Repositories
{
   public class SubscriberRepository : ISubscriberRepository
    {
        private SubscriptionPersistentWrapper _mapper = new SubscriptionPersistentWrapper();
        private readonly KMNDBContext _dbContext;
        private IDbSet<Entities.Subscription > Subscriptions { get; }
        private IDbSet<Entities.Subscriber> Subscribers { get; }
        private IDbSet<Entities.PassengerRoute> PassengerRoutes { get; }
        public IDbSet<Entities.Rider> Riders { get; set; }
        public SubscriberRepository(KMNDBContext dbContext)
        {
            _dbContext = dbContext;
            Subscriptions = dbContext.Set<Entities.Subscription>();
            Subscribers = dbContext.Set<Entities.Subscriber>();
            PassengerRoutes = dbContext.Set<Entities.PassengerRoute>();
            Riders = dbContext.Set<Entities.Rider>();
        }

        public async Task<bool> CreateSubscriptionAsync(Subscription sub)
        {
            sub.Status = EntityStatus.Active;
            var entity = _mapper.Map(sub);
            Subscriptions.Add(entity);
            int result = await _dbContext.SaveChangesAsync().ConfigureAwait(false);
            return result == 1;
        }

        public async Task<bool> CreateSubscriptionAsync(PassengerRoute sub)
        {
            sub.Status = EntityStatus.Active;
            var entity = _mapper.Map(sub);
            PassengerRoutes.Add(entity);
            int result = await _dbContext.SaveChangesAsync().ConfigureAwait(false);
            return result == 1;
        }

        public async Task<IEnumerable<Subscription>> GetSubscriptionElapseAsync(Subscription sub)
        {
            return null;

            var dbSubs = await Subscriptions.Where(x => ( x.EstimatedPickupDateTime >= sub.EstimatedPickupDateTime && x.EstimatedPickupDateTime <= sub.EstimatedDroppOffDateTime) 
                && x.VehicleId  == sub.VehicleId && x.RiderId == sub.RiderId).ToListAsync().ConfigureAwait(false);

            return dbSubs == null || dbSubs.Count == 0 ? null : _mapper.Map(dbSubs);
        }

        public async Task<IEnumerable<PassengerRoute>> GetSubscriptionElapseAsync(PassengerRoute sub)
        {
            return null;

              var dbSubs = await PassengerRoutes.Where(x => x.EstimatedPickupDateTime >= sub.EstimatedPickupDateTime.Value.AddMinutes(20)
                & x.RiderId == sub.RiderId).ToListAsync().ConfigureAwait(false);

            return  dbSubs == null || dbSubs.Count == 0 ? null : _mapper.Map(dbSubs);
        }

        public async Task<IEnumerable<PassengerRoute>> GetSubscriptionListAsync(DbGeography PickupLocation, DbGeography DropOffLocation,EntityRequestStatus RequestStatus, double? threshold)
        {
            threshold = threshold == null ?  1 : threshold ; // pass this as parameter.. in KM
            var range = threshold * 1.609344; // to 
            var dbSubs = await PassengerRoutes.Where(x => (x.PickupLocation.Distance(PickupLocation) < range
                              && x.DropOffLocation.Distance(DropOffLocation) < range) 
                              && x.RequestStatus == RequestStatus 
                              && x.Status == EntityStatus.Active 
                              && !x.IsDeleted ).ToListAsync().ConfigureAwait(false);

            return dbSubs == null || dbSubs.Count == 0 ? null : _mapper.Map(dbSubs);
        }

        public async Task<IEnumerable<PassengerRoute>> GetSubscriptionListAsync(DbGeography PickupLocation, EntityRequestStatus RequestStatus, double? threshold)
        {
            threshold = threshold == null ? 1 : threshold; // pass this as parameter.. in KM
            var range = threshold * 1.609344; // to 
            var dbSubs = await PassengerRoutes.Where(x => (x.PickupLocation.Distance(PickupLocation) < range )
                              && x.RequestStatus == RequestStatus
                              && x.Status == EntityStatus.Active
                              && !x.IsDeleted).ToListAsync().ConfigureAwait(false);

            return dbSubs == null || dbSubs.Count == 0 ? null : _mapper.Map(dbSubs);
        }

        public async Task<IEnumerable<PassengerRoute>> GetSubscriptionListAsync(DbGeography PickupLocation, EntityRequestStatus RequestStatus)
        {
            var dbSubs = await PassengerRoutes.Where(x=>
                               x.RequestStatus == RequestStatus
                              && x.Status == EntityStatus.Active
                              && !x.IsDeleted)
                        .OrderBy(x=>x.PickupLocation.Distance(PickupLocation))
                        .ToListAsync()
                        .ConfigureAwait(false);

            return dbSubs == null || dbSubs.Count == 0 ? null : _mapper.Map(dbSubs);
        }

        public async Task<IEnumerable<Subscription>> GetDriverSubscriptionAsync(DbGeography PickupLocation, DbGeography DropOffLocation, EntityRequestStatus RequestStatus, double? threshold)
        {
            threshold = threshold == null ? 1 : threshold; // pass this as parameter.. in KM
            var range = threshold * 1.609344; // to 
            var dbSubs = await Subscriptions.Where(x => (x.PickupLocation.Distance(PickupLocation) <= range
                              && x.DropOffLocation.Distance(DropOffLocation) <= range)
                              && x.RequestStatus == RequestStatus
                              && x.Status == EntityStatus.Active
                              && !x.IsDeleted).ToListAsync().ConfigureAwait(false);

            //var xmax = dbSubs.First().PickupLocation.Distance(DropOffLocation);
            //var dbSubs = await Subscriptions.Where(x => x.RequestStatus == RequestStatus
            //                 && x.Status == EntityStatus.Active
            //                 && !x.IsDeleted).ToListAsync().ConfigureAwait(false);

            if (dbSubs != null)
            {
                foreach (var dbsub in dbSubs)
                {
                    var subcriber = await GetSubscribersBySubscriptionIdAsync(dbsub.SubscriptionId).ConfigureAwait(false);
                    dbsub.Subscribers = _mapper.Map(subcriber).ToList();
                }
            }

            return dbSubs == null || dbSubs.Count == 0 ? null : _mapper.Map(dbSubs);
        }

        public async Task<IEnumerable<Subscription>> GetDriverSubscriptionAsync(DbGeography PickupLocation, EntityRequestStatus RequestStatus, double? threshold)
        {
            threshold = threshold == null ? 1 : threshold; // pass this as parameter.. in KM
            var range = threshold * 1.609344; // to 
            var dbSubs = await Subscriptions.Where(x => (x.PickupLocation.Distance(PickupLocation) < range)
                              && x.RequestStatus == RequestStatus
                              && x.Status == EntityStatus.Active
                              && !x.IsDeleted).ToListAsync().ConfigureAwait(false);


            if (dbSubs != null)
            {
                foreach (var dbsub in dbSubs)
                {
                    var subcriber = await GetSubscribersBySubscriptionIdAsync(dbsub.SubscriptionId).ConfigureAwait(false);
                    dbsub.Subscribers = _mapper.Map(subcriber).ToList();
                }
            }

            return dbSubs == null || dbSubs.Count == 0 ? null : _mapper.Map(dbSubs);
        }

        public async Task<IEnumerable<Subscription>> GetDriverSubscriptionAsync(DbGeography PickupLocation, EntityRequestStatus RequestStatus)
        {
            var dbSubs = await Subscriptions.Where(x =>
                               x.RequestStatus == RequestStatus
                              && x.Status == EntityStatus.Active
                              && !x.IsDeleted)
                        .OrderBy(x => x.PickupLocation.Distance(PickupLocation))
                        .ToListAsync()
                        .ConfigureAwait(false);

            if(dbSubs != null)
            {
                foreach(var dbsub in dbSubs)
                {
                    var subcriber = await GetSubscribersBySubscriptionIdAsync(dbsub.SubscriptionId).ConfigureAwait(false);
                    dbsub.Subscribers = _mapper.Map(subcriber).ToList();
                }
            }
            return dbSubs == null || dbSubs.Count == 0 ? null : _mapper.Map(dbSubs);
        }
        private async Task<IEnumerable<Subscriber>> GetSubscribersBySubscriptionIdAsync(Guid subscriptionId)
        {
            var dbsubscribers = await Subscribers.Where(x => x.SubscriptionId  == subscriptionId).ToListAsync().ConfigureAwait(false);
            return _mapper.Map(dbsubscribers);
        }

        public async Task<Subscriber> GetSubscribersBySubscriptionAndPassengerIdAsync(Guid subscriptionId, Guid passengerRouteId)
        {
            var dbsubscribers = await Subscribers.FirstOrDefaultAsync (x => x.SubscriptionId == subscriptionId 
                                                        && x.PassengerRouteId == passengerRouteId 
                                                        && (x.PassengerApproval != EntityRequestStatus.Canclled && x.PassengerApproval != EntityRequestStatus.Declined )
                                                        && (x.DriverApproval != EntityRequestStatus.Canclled && x.DriverApproval != EntityRequestStatus.Declined)).ConfigureAwait(false);
            return _mapper.Map(dbsubscribers);
        }

        public async Task<Rider> GetPassengerDataAsync(Guid passengerRouteId)
        {
            var dbsubscribers = await Riders
                                            .Join(PassengerRoutes
                                            .Where(x=> x.PassengerRouteId == passengerRouteId), (r => r.RiderId), (p => p.RiderId), ((r, p) 
                                 => new {
                                            Rider = r 
                                           ,Passenger =p
                                 }))
                                            .FirstOrDefaultAsync().ConfigureAwait(false);
             
            var existingRider = Rider.CreateExisting(
                dbsubscribers.Rider.RiderId
                 , dbsubscribers.Rider.RiderNumber
                , dbsubscribers.Rider.UserName
                , dbsubscribers.Rider.Password
                , dbsubscribers.Rider.ConfirmPassword
                , dbsubscribers.Rider.FirstName
                , dbsubscribers.Rider.MiddleName
                , dbsubscribers.Rider.LastName
                , dbsubscribers.Rider.DateOfBirth
                , dbsubscribers.Rider.Gender
                , dbsubscribers.Rider.Email
                , dbsubscribers.Rider.PrimaryPhoneNumber
                , dbsubscribers.Rider.SecondaryPhoneNumber
                , Guid.NewGuid()
                , Guid.NewGuid()
                , dbsubscribers.Rider.Occupation
                , dbsubscribers.Rider.Notes
                , DateTime.Now
                , DateTime.Now
                , null
                , null
                );
            return existingRider;
        }

        public async Task<Rider> GetDriverDataAsync(Guid subscriptionId)
        {
            var dbsubscribers = await Riders
                                            .Join(Subscriptions
                                            .Where(x => x.SubscriptionId == subscriptionId), (r => r.RiderId), (p => p.RiderId), ((r, p)
                                  => new {
                                      Rider = r
                                            ,
                                      Subscription = p
                                  }))
                                            .FirstOrDefaultAsync().ConfigureAwait(false);

            var existingRider = Rider.CreateExisting(
                dbsubscribers.Rider.RiderId
                 , dbsubscribers.Rider.RiderNumber
                , dbsubscribers.Rider.UserName
                , dbsubscribers.Rider.Password
                , dbsubscribers.Rider.ConfirmPassword
                , dbsubscribers.Rider.FirstName
                , dbsubscribers.Rider.MiddleName
                , dbsubscribers.Rider.LastName
                , dbsubscribers.Rider.DateOfBirth
                , dbsubscribers.Rider.Gender
                , dbsubscribers.Rider.Email
                , dbsubscribers.Rider.PrimaryPhoneNumber
                , dbsubscribers.Rider.SecondaryPhoneNumber
                , Guid.NewGuid()
                , Guid.NewGuid()
                , dbsubscribers.Rider.Occupation
                , dbsubscribers.Rider.Notes
                , DateTime.Now
                , DateTime.Now
                , null
                , null
                );
            return existingRider;
        }

        public async Task<Rider> GetPassengerRouteAsync(Guid riderId)
        {
            var dbsubscribers = await Riders
                                            .Join(PassengerRoutes
                                            .Where(x => x.RiderId  == riderId), (r => r.RiderId), (p => p.RiderId), ((r, p)
                                  => new {
                                      Rider = r
                                            ,
                                      Passenger = p
                                  }))
                                            .FirstOrDefaultAsync().ConfigureAwait(false);

            var existingRider = Rider.CreateExisting(
                dbsubscribers.Rider.RiderId
                 , dbsubscribers.Rider.RiderNumber
                , dbsubscribers.Rider.UserName
                , dbsubscribers.Rider.Password
                , dbsubscribers.Rider.ConfirmPassword
                , dbsubscribers.Rider.FirstName
                , dbsubscribers.Rider.MiddleName
                , dbsubscribers.Rider.LastName
                , dbsubscribers.Rider.DateOfBirth
                , dbsubscribers.Rider.Gender
                , dbsubscribers.Rider.Email
                , dbsubscribers.Rider.PrimaryPhoneNumber
                , dbsubscribers.Rider.SecondaryPhoneNumber
                , Guid.NewGuid()
                , Guid.NewGuid()
                , dbsubscribers.Rider.Occupation
                , dbsubscribers.Rider.Notes
                , DateTime.Now
                , DateTime.Now
                , null
                , null
                );
            return existingRider;
        }

        public async Task<IEnumerable<PassengerRoute>> GetPassengerRouteAsync(DbGeography PickupLocation, DbGeography DropOffLocation, EntityRequestStatus RequestStatus, double? threshold)
        {
            IList<PassengerRoute> passengers = new List<PassengerRoute>();

            threshold = threshold == null ? 1 : threshold; // pass this as parameter.. in KM
            var range = threshold * 1.609344; // to 
            var dbSubs = await Subscriptions.Where(x => (x.PickupLocation.Distance(PickupLocation) <= range
                              && x.DropOffLocation.Distance(DropOffLocation) <= range)
                              && x.RequestStatus == RequestStatus
                              && x.Status == EntityStatus.Active
                              && !x.IsDeleted).ToListAsync().ConfigureAwait(false);


            var dbPass = await Riders
                                            .Join(PassengerRoutes
                                            .Where(x => (x.PickupLocation.Distance(PickupLocation) <= range
                                                     && x.DropOffLocation.Distance(DropOffLocation) <= range)
                                                     && x.RequestStatus == RequestStatus
                                                     && x.Status == EntityStatus.Active
                                                     && !x.IsDeleted)
                                            , (r => r.RiderId), (p => p.RiderId), ((r, p)
                                 => new {
                                     Rider = r
                                           ,
                                     Passenger = p
                                 }))
                                            .ToListAsync().ConfigureAwait(false);

            foreach(var db in dbPass)
            {
                passengers.Add(PassengerRoute.CreateExisting(
                  db.Passenger.PassengerRouteId
                , db.Passenger.RiderId
                , $"{db.Rider.FirstName} {db.Rider.LastName}"
                , db.Rider.Email
                , db.Rider.PrimaryPhoneNumber
                , db.Passenger.PickupLocation
                , db.Passenger.DropOffLocation
                , db.Passenger.EstimatedPickupDateTime
                , db.Passenger.RiderType
                , db.Passenger.BaseFare
                , db.Passenger.RequestStatus
                , db.Passenger.Notes 
               ));
            }
          
            return passengers;
        }

        public async Task<bool> CreateSubscriberAsync(Subscriber sub)
        {
            sub.Status = EntityStatus.Active;
            
            var entity = _mapper.Map(sub);
            Subscribers.Add(entity);
            int result = await _dbContext.SaveChangesAsync().ConfigureAwait(false);
            return result == 1;
        }

        public async Task<Subscription> GetSubscriptionByIdAsync(Guid subscriptionId)
        {
            var dbSubs = await Subscriptions.FirstOrDefaultAsync(x => x.SubscriptionId  == subscriptionId && !x.IsDeleted).ConfigureAwait(false);
           
            return  _mapper.Map(dbSubs);
        }

        public async Task<PassengerRoute> GetPassengerRouteByIdAsync(Guid passengerRouteId)
        {
            var dbSubs = await PassengerRoutes.FirstOrDefaultAsync(x => x.PassengerRouteId == passengerRouteId
                              && x.Status == EntityStatus.Active
                              && !x.IsDeleted).ConfigureAwait(false);

            return _mapper.Map(dbSubs);
        }

        public void Dispose()
        {
            _dbContext?.Dispose();
        }
    }
}