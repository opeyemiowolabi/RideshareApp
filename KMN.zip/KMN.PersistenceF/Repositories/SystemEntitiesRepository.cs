﻿using KMN.Domain.Entities;
using KMN.Persistence.Mappers;
using KMN.Persistence.Repositories.Contract;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KMN.Persistence.Repositories
{
    public class SystemEntitiesRepository : ISystemEntitiesRepository
    {
        private SystemEntitiesPersistentWrapper _systemMapper = new SystemEntitiesPersistentWrapper();
        private readonly KMNDBContext _dbContext;

        private IDbSet<Entities.CarData> Cars { get; }

        public SystemEntitiesRepository(KMNDBContext dbContext)
        {
            _dbContext = dbContext;
            Cars  = dbContext.Set<Entities.CarData>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="SystemEntities"></param>
        /// <returns></returns>

        public async Task<CarData> GetCarsById(Guid carId)
        {
            var dbCar = await Cars.FirstOrDefaultAsync(x => x.CarDataId  == carId).ConfigureAwait(false);           

            return _systemMapper.Map(dbCar);
        }

        public async Task<IEnumerable<CarData>> GetCarsByGroup()
        {
            var cars = new List<CarData>();
            var dbCars = await Cars.Where(x => x.IsDeleted == false)
                .GroupBy(g => g.Make)
                .Select(x => new
                {
                    Make = x.Key
                })
                .OrderBy(o => o.Make).ToListAsync().ConfigureAwait(false);

            foreach ( var c in dbCars)
            {
                cars.Add(new CarData
                {
                    Make = c.Make
                });
            }

            return cars;// cars.OrderBy(x=> x.Make);
        }

        public async Task<CarData> GetCarsByCarCode(string carCode)
        {
            var dbCar = await Cars.FirstOrDefaultAsync(x => x.CarCode == carCode).ConfigureAwait(false);

            return _systemMapper.Map(dbCar);
        }

        public async Task<IEnumerable<CarData>> GetCarsByMake(string make)
        {
            var dbCars = await Cars.Where(x => x.Make  == make).OrderBy(x=> x.ModelYear).ToListAsync().ConfigureAwait(false);
            return _systemMapper.Map(dbCars);
        }

        public async Task<IEnumerable<CarData>> GetCarsByMakeYear(string make, string year)
        {
            var dbCars = await Cars.Where(x => x.Make == make && x.Year == year).OrderBy(x => x.ModelYear).ToListAsync().ConfigureAwait(false);
            return _systemMapper.Map(dbCars);
        }

        public async Task<IEnumerable<CarData>> GetCarsByModelYear(string modelYear)
        {
            var dbCars = await Cars.Where(x => x.ModelYear == modelYear).OrderBy(x => x.ModelYear).ToListAsync().ConfigureAwait(false);
            return _systemMapper.Map(dbCars);
        }

        public async Task<IEnumerable<CarData>> GetAllCars()
        {
            var dbCars = await Cars.Where(x => x.Status == EntityStatus.Active).OrderBy(x => x.Make).ToListAsync().ConfigureAwait(false);
            return _systemMapper.Map(dbCars);
        }

        public void Dispose()
        {
            _dbContext?.Dispose();
        }       
    }
}
