﻿using System;
using System.Collections.Generic;
using System.Text;
using Persist = KMN.Persistence.Entities;
using KMN.Domain.Entities;
using System.Linq;

namespace KMN.Persistence.Mappers
{
    public class SubscriptionPersistentWrapper
    {
        public Persist.Subscription  Map(Subscription sub)
        {
            if (sub == null) return null;

            var subscribers = Map(sub.Subscribers);

            var entity = new Persist.Subscription 
            {
                SubscriptionId = sub.SubscriptionId,
                RiderId = sub.RiderId,
                VehicleId = sub.VehicleId,
                PickupLocation = sub.PickupLocation,
                DropOffLocation = sub.DropOffLocation,
                EstimatedPickupDateTime = sub.EstimatedPickupDateTime,
                EstimatedDroppOffDateTime = sub.EstimatedDroppOffDateTime,
                MaxPassengerAllowed = sub.MaxPassengerAllowed,
                RiderType = sub.RiderType,
                BaseFare = sub.BaseFare,
                RequestStatus = sub.RequestStatus,
                Notes = sub.Notes,
                DateCreated = sub.DateCreated,
                LastUpdatedDate = sub.LastUpdatedDate,
                CreatedBy = sub.CreatedBy,
                LastUpdatedBy = sub.LastUpdatedBy,
                Status = sub.Status,
                Subscribers = subscribers.ToList()
            };
            return entity;
        }

        public IEnumerable<Persist.Subscription> Map(IEnumerable<Subscription> subs)
        {
            IList<Persist.Subscription> entities = new List<Persist.Subscription>();
            foreach (var sub in subs)
            {
                var subscribers = Map(sub.Subscribers);
                var entity = new Persist.Subscription
                {
                    SubscriptionId = sub.SubscriptionId,
                    RiderId = sub.RiderId,
                    VehicleId = sub.VehicleId,
                    PickupLocation = sub.PickupLocation,
                    DropOffLocation = sub.DropOffLocation,
                    EstimatedPickupDateTime = sub.EstimatedPickupDateTime,
                    EstimatedDroppOffDateTime = sub.EstimatedDroppOffDateTime,
                    MaxPassengerAllowed = sub.MaxPassengerAllowed,
                    RiderType = sub.RiderType,
                    BaseFare = sub.BaseFare,
                    RequestStatus = sub.RequestStatus,
                    Notes = sub.Notes,
                    DateCreated = sub.DateCreated,
                    LastUpdatedDate = sub.LastUpdatedDate,
                    CreatedBy = sub.CreatedBy,
                    LastUpdatedBy = sub.LastUpdatedBy,
                    Status = sub.Status,
                    Subscribers = subscribers.ToList()
                };
                entities.Add(entity);
            }

            return entities;
        }

        public Subscription Map(Persist.Subscription sub)
        {
            if (sub == null) return null;

            var subscribers = Map(sub.Subscribers);
            var domain = Subscription.CreateExisting(
                    sub.SubscriptionId,
                    sub.RiderId,
                    sub.VehicleId,
                    sub.PickupLocation,
                    sub.DropOffLocation,
                    sub.EstimatedPickupDateTime,
                    sub.EstimatedDroppOffDateTime,
                    sub.MaxPassengerAllowed,
                    sub.RiderType,
                    sub.BaseFare,
                    sub.RequestStatus,
                    sub.Notes,
                    subscribers);

            return domain;
        }

        public IEnumerable<Subscription> Map(IEnumerable<Persist.Subscription> subs)
        {
            IList<Subscription> domains = new List<Subscription>();

            foreach (var sub in subs)
            {
                var subscribers = Map(sub.Subscribers);
                var domain = Subscription.CreateExisting(
                   sub.SubscriptionId,
                    sub.RiderId,
                    sub.VehicleId,
                    sub.PickupLocation,
                    sub.DropOffLocation,
                    sub.EstimatedPickupDateTime,
                    sub.EstimatedDroppOffDateTime,
                    sub.MaxPassengerAllowed,
                    sub.RiderType,
                    sub.BaseFare,
                    sub.RequestStatus,
                    sub.Notes,
                    subscribers);

                domains.Add(domain);
            }

            return domains;
        }

        public IEnumerable<Persist.Subscriber> Map(IEnumerable<Subscriber> subs)
        {
            IList<Persist.Subscriber> entities = new List<Persist.Subscriber>();
            if(subs != null)
            {
                foreach (var sub in subs)
                {
                    var entity = new Persist.Subscriber
                    {
                        SubscriberId = sub.SubscriberId,
                        SubscriptionId = sub.SubscriptionId,
                        PassengerRouteId = sub.PassengerRouteId,
                        AgreedFare = sub.AgreedFare,
                        DriverApproval = sub.DriverApproval,
                        PassengerApproval = sub.PassengerApproval,
                        Notes = sub.Notes
                    };
                    entities.Add(entity);
                }
            }
           
            return entities;
        }

        public Persist.Subscriber Map(Subscriber sub)
        {
            var entity = new Persist.Subscriber
            {
                SubscriberId = sub.SubscriberId,
                SubscriptionId = sub.SubscriptionId,
                PassengerRouteId = sub.PassengerRouteId,
                AgreedFare = sub.AgreedFare,
                DriverApproval = sub.DriverApproval,
                PassengerApproval = sub.PassengerApproval,
                Notes = sub.Notes
            };
            return entity;
        }

        public Subscriber Map(Persist.Subscriber sub)
        {
            var domain = new Subscriber()
            {
                SubscriberId = sub.SubscriberId,
                SubscriptionId = sub.SubscriptionId,
                PassengerRouteId = sub.PassengerRouteId,
                AgreedFare = sub.AgreedFare,
                DriverApproval = sub.DriverApproval,
                PassengerApproval = sub.PassengerApproval,
                Notes = sub.Notes
            };

            return domain;
        }

        public IEnumerable<Subscriber> Map(IEnumerable<Persist.Subscriber> subs)
        {
            IList<Subscriber> domains = new List<Subscriber>();

            if (subs != null)
            {
                foreach (var sub in subs)
                {
                    var domain = new Subscriber()
                    {
                        SubscriberId = sub.SubscriberId,
                        SubscriptionId = sub.SubscriptionId,
                        PassengerRouteId = sub.PassengerRouteId,
                        AgreedFare = sub.AgreedFare,
                        DriverApproval = sub.DriverApproval,
                        PassengerApproval = sub.PassengerApproval,
                        Notes = sub.Notes
                    };
                    domains.Add(domain);
                }
            }
            return domains;
        }

        public Persist.PassengerRoute Map(PassengerRoute sub)
        {
            if (sub == null) return null;

            var entity = new Persist.PassengerRoute
            {
                PassengerRouteId = sub.PassengerRouteId,
                RiderId = sub.RiderId,
                PickupLocation = sub.PickupLocation,
                DropOffLocation = sub.DropOffLocation,
                EstimatedPickupDateTime = sub.EstimatedPickupDateTime,
                RiderType = sub.RiderType,
                BaseFare = sub.BaseFare,
                RequestStatus = sub.RequestStatus,
                Notes = sub.Notes,
                DateCreated = sub.DateCreated,
                LastUpdatedDate = sub.LastUpdatedDate,
                CreatedBy = sub.CreatedBy,
                LastUpdatedBy = sub.LastUpdatedBy,
                Status = sub.Status
            };
            return entity;
        }

        public IEnumerable<Persist.PassengerRoute> Map(IEnumerable<PassengerRoute> subs)
        {
            IList<Persist.PassengerRoute> entities = new List<Persist.PassengerRoute>();
            foreach (var sub in subs)
            {
                var entity = new Persist.PassengerRoute
                {
                    PassengerRouteId = sub.PassengerRouteId,
                    RiderId = sub.RiderId,
                    PickupLocation = sub.PickupLocation,
                    DropOffLocation = sub.DropOffLocation,
                    EstimatedPickupDateTime = sub.EstimatedPickupDateTime,
                    RiderType = sub.RiderType,
                    BaseFare = sub.BaseFare,
                    RequestStatus = sub.RequestStatus,
                    Notes = sub.Notes,
                    DateCreated = sub.DateCreated,
                    LastUpdatedDate = sub.LastUpdatedDate,
                    CreatedBy = sub.CreatedBy,
                    LastUpdatedBy = sub.LastUpdatedBy,
                    Status = sub.Status
                };
                entities.Add(entity);
            }

            return entities;
        }

        public PassengerRoute Map(Persist.PassengerRoute sub)
        {
            if (sub == null) return null;

            var domain = PassengerRoute.CreateExisting(
                    sub.PassengerRouteId,
                    sub.RiderId,
                    "N/A",
                    "N/A",
                    "N/A",
                    sub.PickupLocation,
                    sub.DropOffLocation,
                    sub.EstimatedPickupDateTime,
                    sub.RiderType,
                    sub.BaseFare,
                    sub.RequestStatus,
                    sub.Notes
                    );

            return domain;
        }

        public IEnumerable<PassengerRoute> Map(IEnumerable<Persist.PassengerRoute> subs)
        {
            IList<PassengerRoute> domains = new List<PassengerRoute>();

            foreach (var sub in subs)
            {
                var domain = PassengerRoute.CreateExisting(
                   sub.PassengerRouteId,
                    sub.RiderId,
                    "N/A",
                    "N/A",
                    "N/A",
                    sub.PickupLocation,
                    sub.DropOffLocation,
                    sub.EstimatedPickupDateTime,
                    sub.RiderType,
                    sub.BaseFare,
                    sub.RequestStatus,
                    sub.Notes
                    );

                domains.Add(domain);
            }

            return domains;
        }
    }
}
