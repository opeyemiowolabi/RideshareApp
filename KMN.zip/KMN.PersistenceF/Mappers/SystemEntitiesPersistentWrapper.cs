﻿using System;
using System.Collections.Generic;
using System.Text;
using Persist = KMN.Persistence.Entities;
using KMN.Domain.Entities;

namespace KMN.Persistence.Mappers
{
    class SystemEntitiesPersistentWrapper
    {
        public IEnumerable<CarData> Map(IEnumerable<Persist.CarData> cars)
        {
            IList<CarData> domains = new List<CarData>();
            if (cars == null) return null;// domains;

            foreach (var car in cars)
            {
                // var contacts = Map(rider.Contacts);
                var domain = new CarData
                {
                    CarDataId = car.CarDataId,
                    CarCode =  car.CarCode,
                    Make = car.Make,
                    Year =  car.Year,
                    ModelYear =  car.ModelYear 
                };
                    
                domains.Add(domain);
            }

            return domains;
        }

        public IEnumerable<Persist.CarData> Map(IEnumerable<CarData> cars)
        {
            IList<Persist.CarData> entities = new List<Persist.CarData>();
            if (cars == null) return null;// entities;

            if (cars != null)
            {
                foreach (var car in cars)
                {
                    var entity = new Persist.CarData
                    {
                        CarDataId = car.CarDataId,
                        CarCode = car.CarCode,
                        Make = car.Make,
                        Year = car.Year,
                        ModelYear = car.ModelYear
                    };
                    entities.Add(entity);
                }
            }

            return entities;
        }

        public Persist.CarData Map(CarData car)
        {
            if (car == null) return null;// new Persist.CarData();

            var entity = new Persist.CarData
            {

                CarDataId = car.CarDataId,
                CarCode = car.CarCode,
                Make = car.Make,
                Year = car.Year,
                ModelYear = car.ModelYear
            };
            return entity;
        }

        public CarData Map(Persist.CarData car)
        {
            if (car == null) return null;// new CarData();

            var domain = new CarData()
            {
                CarDataId = car.CarDataId,
                CarCode = car.CarCode,
                Make = car.Make,
                Year = car.Year,
                ModelYear = car.ModelYear
            };

            return domain;
        }            
    }
}
