﻿using System;
using System.Collections.Generic;
using System.Text;
using Persist = KMN.Persistence.Entities;
using KMN.Domain.Entities;
using System.Linq;

namespace KMN.Persistence.Mappers
{
    public class RiderPersistentWrapper
    {
        public Persist.Rider Map(Rider rider)
        {
            if (rider == null) return null;

            var contacts = Map(rider.Contacts);
            var vehicles = Map(rider.VehicleInfo);

            var entity = new Persist.Rider
            {
                RiderId = rider.RiderId,
                RiderNumber = rider.RiderNumber,
                UserName = rider.UserName,
                Password = rider.Password,
                ConfirmPassword = rider.ConfirmPassword,
                FirstName = rider.FirstName,
                MiddleName = rider.MiddleName,
                LastName = rider.LastName,
                DateOfBirth = rider.DateOfBirth,
                Gender = rider.Gender,
                Email = rider.Email,
                PrimaryPhoneNumber = rider.PrimaryPhoneNumber,
                SecondaryPhoneNumber = rider.SecondaryPhoneNumber,
                TakeOffLocationId = rider.TakeOffLocationId,
                DestinationLocationId = rider.DestinationLocationId,
                Occupation = rider.Occupation,
                Notes = rider.Notes,
                DateCreated = rider.DateCreated,
                LastUpdatedDate = rider.LastUpdatedDate,
                CreatedBy =  rider.CreatedBy,
                LastUpdatedBy = rider.LastUpdatedBy,
                Status = rider.Status,
                Contacts =  contacts.ToList(),
                VehicleInformations = vehicles.ToList()
            };
            return entity;
        }

        public IEnumerable<Persist.Rider> Map(IEnumerable<Rider> riders)
        {
            IList<Persist.Rider> entities = new List<Persist.Rider>();
            foreach (var rider in riders)
            {
                var contacts = Map(rider.Contacts);
                var vehicles = Map(rider.VehicleInfo);
                var entity = new Persist.Rider
                {
                    RiderId = rider.RiderId,
                    RiderNumber = rider.RiderNumber,
                    UserName = rider.UserName,
                    Password = rider.Password,
                    ConfirmPassword = rider.ConfirmPassword,
                    FirstName = rider.FirstName,
                    MiddleName = rider.MiddleName,
                    LastName = rider.LastName,
                    DateOfBirth = rider.DateOfBirth,
                    Gender = rider.Gender,
                    Email = rider.Email,
                    PrimaryPhoneNumber = rider.PrimaryPhoneNumber,
                    SecondaryPhoneNumber = rider.SecondaryPhoneNumber,
                    TakeOffLocationId = rider.TakeOffLocationId,
                    DestinationLocationId = rider.DestinationLocationId,
                    Occupation = rider.Occupation,
                    Notes = rider.Notes,
                    DateCreated = rider.DateCreated,
                    LastUpdatedDate = rider.LastUpdatedDate,
                    CreatedBy = rider.CreatedBy,
                    LastUpdatedBy = rider.LastUpdatedBy,
                    Status = rider.Status,
                    Contacts =  contacts.ToList(),
                    VehicleInformations =  vehicles.ToList()
                };
                entities.Add(entity);
            }

            return entities;
        }

        public Rider Map(Persist.Rider rider)
        {
            if (rider == null) return null;

            var contacts = Map(rider.Contacts);
            var vehicles = Map(rider.VehicleInformations);

            var domain = Rider.CreateExisting(
                    rider.RiderId 
                  , rider.RiderNumber
                   , rider.UserName
                   , rider.Password
                   , rider.ConfirmPassword
                  , rider.FirstName
                  , rider.MiddleName
                  , rider.LastName
                  , rider.DateOfBirth
                  , rider.Gender
                  , rider.Email
                  , rider.PrimaryPhoneNumber
                  , rider.SecondaryPhoneNumber
                  , rider.TakeOffLocationId
                  , rider.DestinationLocationId
                  , rider.Occupation
                  , rider.Notes
                  , rider.DateCreated
                  , rider.LastUpdatedDate
                  , contacts
                  , vehicles );

            return domain;
        }

        public IEnumerable<Rider> Map(IEnumerable<Persist.Rider> riders)
        {
            IList<Rider> domains = new List<Rider>();

            foreach (var rider in riders)
            {
                var contacts = Map(rider.Contacts);
                var vehicles = Map(rider.VehicleInformations);
                var domain = Rider.CreateExisting(
                     rider.RiderId
                   , rider.RiderNumber
                   , rider.UserName
                   , rider.Password
                   , rider.ConfirmPassword
                   , rider.FirstName
                   , rider.MiddleName
                   , rider.LastName
                   , rider.DateOfBirth
                   , rider.Gender
                   , rider.Email
                   , rider.PrimaryPhoneNumber
                   , rider.SecondaryPhoneNumber
                   , rider.TakeOffLocationId
                   , rider.DestinationLocationId
                   , rider.Occupation
                   , rider.Notes
                   , rider.DateCreated
                   , rider.LastUpdatedDate
                   , contacts
                   , vehicles);

                domains.Add(domain);
            }

            return domains;
        }

        public IEnumerable<Persist.RiderContact> Map(IEnumerable<RiderContact> contacts)
        {
            IList<Persist.RiderContact> entities = new List<Persist.RiderContact>();
            if(contacts != null)
            {
                foreach (var contact in contacts)
                {
                    var entity = new Persist.RiderContact
                    {
                        RiderContactId = contact.ContactId,
                        RiderId = contact.RiderId,
                        Address = contact.Address,
                        CityOrLGA = contact.CityOrLGA,
                        State = contact.State,
                        PrimaryPhoneNo = contact.PrimaryPhoneNo,
                        SecondaryPhoneNo = contact.SecondaryPhoneNo,
                        Email = contact.Email,
                        EmergencyContactName = contact.EmergencyContactName,
                        EmergencyPhoneNumber = contact.EmergencyPhoneNumber
                    };
                    entities.Add(entity);
                }
            }
           
            return entities;
        }

        public Persist.RiderContact Map(RiderContact contact)
        {
            var entity = new Persist.RiderContact
            {
                RiderContactId = contact.ContactId,
                RiderId = contact.RiderId,
                Address = contact.Address,
                CityOrLGA = contact.CityOrLGA,
                State = contact.State,
                PrimaryPhoneNo = contact.PrimaryPhoneNo,
                SecondaryPhoneNo = contact.SecondaryPhoneNo,
                Email = contact.Email,
                EmergencyContactName = contact.EmergencyContactName,
                EmergencyPhoneNumber = contact.EmergencyPhoneNumber
            };
            return entity;
        }

        public RiderContact Map(Persist.RiderContact contact)
        {
            var domain = new RiderContact()
            {
                ContactId = contact.RiderContactId,
                RiderId = contact.RiderId,
                Address = contact.Address,
                CityOrLGA = contact.CityOrLGA,
                State = contact.State,
                PrimaryPhoneNo = contact.PrimaryPhoneNo,
                SecondaryPhoneNo = contact.SecondaryPhoneNo,
                Email = contact.Email,
                EmergencyContactName = contact.EmergencyContactName,
                EmergencyPhoneNumber = contact.EmergencyPhoneNumber
            };

            return domain;
        }

        public IEnumerable<RiderContact> Map(IEnumerable<Persist.RiderContact> contacts)
        {
            IList<RiderContact> domains = new List<RiderContact>();

            if (contacts != null)
            {
                foreach (var contact in contacts)
                {
                    var domain = new RiderContact()
                    {
                        ContactId = contact.RiderContactId,
                        RiderId = contact.RiderId,
                        Address = contact.Address,
                        CityOrLGA = contact.CityOrLGA,
                        State = contact.State,
                        PrimaryPhoneNo = contact.PrimaryPhoneNo,
                        SecondaryPhoneNo = contact.SecondaryPhoneNo,
                        Email = contact.Email,
                        EmergencyContactName = contact.EmergencyContactName,
                        EmergencyPhoneNumber = contact.EmergencyPhoneNumber
                    };
                    domains.Add(domain);
                }
            }
            return domains;
        }

        public IEnumerable<Persist.VehicleInformation> Map(IEnumerable<VehicleInformation> vInfos)
        {
            IList<Persist.VehicleInformation> entities = new List<Persist.VehicleInformation>();
            if (vInfos != null)
            {
                foreach (var vInfo in vInfos)
                {
                    var entity = new Persist.VehicleInformation
                    {
                        VehicleInformationId = vInfo.VehicleInformationId,
                        RiderId = vInfo.RiderId,
                        CarDataId = vInfo.CarDataId,
                        NumberOfPassenger = vInfo.NumberOfPassenger,
                        PlateNumber = vInfo.PlateNumber,
                        ChasisNumber = vInfo.ChasisNumber
                    };
                    entities.Add(entity);
                }
            }

            return entities;
        }

        public Persist.VehicleInformation Map(VehicleInformation vInfo)
        {
            var entity = new Persist.VehicleInformation
            {
                VehicleInformationId = vInfo.VehicleInformationId,
                RiderId = vInfo.RiderId,
                CarDataId = vInfo.CarDataId,
                NumberOfPassenger = vInfo.NumberOfPassenger,
                PlateNumber = vInfo.PlateNumber,
                ChasisNumber = vInfo.ChasisNumber
            };
            return entity;
        }

        public VehicleInformation Map(Persist.VehicleInformation vInfo)
        {
            var domain = new VehicleInformation()
            {
                VehicleInformationId = vInfo.VehicleInformationId,
                RiderId = vInfo.RiderId,
                CarDataId = vInfo.CarDataId,
                NumberOfPassenger = vInfo.NumberOfPassenger,
                PlateNumber = vInfo.PlateNumber,
                ChasisNumber = vInfo.ChasisNumber
            };

            return domain;
        }

        public IEnumerable<VehicleInformation> Map(IEnumerable<Persist.VehicleInformation> vInfos)
        {
            IList<VehicleInformation> domains = new List<VehicleInformation>();

            if (vInfos != null)
            {
                foreach (var vInfo in vInfos)
                {
                    var domain = new VehicleInformation()
                    {
                        VehicleInformationId = vInfo.VehicleInformationId,
                        RiderId = vInfo.RiderId,
                        CarDataId = vInfo.CarDataId,
                        NumberOfPassenger = vInfo.NumberOfPassenger,
                        PlateNumber = vInfo.PlateNumber,
                        ChasisNumber = vInfo.ChasisNumber
                    };
                    domains.Add(domain);
                }
            }
            return domains;
        }
    }
}
