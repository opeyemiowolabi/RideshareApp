﻿using System;
using Autofac;
using Microsoft.Owin.Hosting;
using System.Threading;
using KMN.Api;
using System.Net.Http;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Net;
using System.Text;
using Softmark.IoC;
using Softmark.Api;
using System.Configuration;

namespace KMN.Host
{
    class Program
    {
        static bool enableSSL = false;
        static void Main(string[] args)
        {
            string _port = ConfigurationManager.AppSettings["hostPort"];
            string _cert = ConfigurationManager.AppSettings["CertName"];

            Console.Title = "KMN - Know My Neighbor";


            SoftmarkApiConfiguration.Instance
                .UseDependencyResolver(new AutoFacIoCBuilder().BuildContainer(new Module[] { new ServiceBoostrap(), new RepositoryBoostrap() }));

            SoftmarkApiConfiguration.Instance.Configuration.EnsureInitialized();

            // to bind remotely i.e other than localhost
             var baseUrl = string.Format($"http://*:{_port}/");
            // string baseUrl = "http://localhost:9000/";
            // configure https 

            Console.WriteLine("Enable SSL (Y/N) ?");
            enableSSL = Console.ReadLine().ToUpper() == "Y"  ? true : false;

            if(enableSSL)
            {
                baseUrl = string.Format($"https://*:{_port}/");
                NetAclHelper.configNetAcl(baseUrl.Replace("*", "localhost"), _cert);
            }

            using (WebApp.Start<Startup>(url: baseUrl))
            {
                Console.WriteLine($"Service Started... {Environment.NewLine}API Listening at {baseUrl}");
                Thread.Sleep(Timeout.Infinite);
            }
        }
    }
}
