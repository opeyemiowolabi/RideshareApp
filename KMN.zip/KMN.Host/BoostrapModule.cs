﻿using Autofac;
using KMN.Persistence;
using KMN.Persistence.Repositories;
using KMN.Persistence.Repositories.Contract;
using KMN.Service;
using KMN.Service.Contract;
using KMN.Service.Outbound.Notification;
using KMN.Service.Services;
using Softmark.Shared.Domain.Utilities;

namespace KMN.Host
{
    public class RepositoryBoostrap : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.Register(ctx => new KMNDBContext());

            builder.RegisterType<RiderRepository>()
              .As<IRiderRepository>()
              .UsingConstructor(typeof(KMNDBContext));

            builder.RegisterType<NotificationRepository>()
             .As<INotificationRepository>()
             .UsingConstructor(typeof(KMNDBContext));

            builder.RegisterType<SubscriberRepository>()
             .As<ISubscriberRepository>()
             .UsingConstructor(typeof(KMNDBContext));

            builder.RegisterType<SystemEntitiesRepository>()
            .As<ISystemEntitiesRepository>()
            .UsingConstructor(typeof(KMNDBContext));
        }
    }

    public class ServiceBoostrap : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<RiderService>()
              .As<IRiderService>();

            builder.RegisterType<NotificationService>()
              .As<INotification>();

            builder.RegisterType<SystemEntitiesService>()
              .As<ISystemEntitiesService>();

            builder.RegisterType<SubscriptionService>()
              .As<ISubscriptionService>();

            builder.RegisterType<GeoHelper>()
             .As<IGeoHelper>();
        }
    }

    public class ModuleBoostrap : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // builder.RegisterType<UserAccountService>().As<IUserAccountService>();
        }
    }
}
