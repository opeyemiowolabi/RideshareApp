﻿using System;
using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;

namespace KMN.Host
{
    public class NetAclHelp { };
    public static class NetAclHelper
    {
       // private static readonly ILogger Logger = LogManager.GetLogger<NetAclHelp>();
        /*
           netsh http delete urlacl url=https://localhost:9393/
           netsh http delete sslcert ipport=0.0.0.0:40100
                    
           netsh http add urlacl url=https://localhost:9393/ user=Everyone
           netsh http add sslcert ipport=0.0.0.0:40100 certhash=fdf190b3413ceb23ed66b09a6b71b27e818ea61e appid={214124cd-d05b-4309-9af9-9caa44b2b74a}
                   
           netsh http show urlacl url=https://localhost:9393/
           netsh http show sslcert ipport=0.0.0.0:40100
         */
        public static void configNetAcl(string url, string SSLCertificateFileName)
        {
           // string SSLCertificateFileName = "KMNCert";
            try
            {
                
                Uri theUrl = new Uri(url);

                if (theUrl.Scheme == "https")
                {
                    if (string.IsNullOrEmpty(SSLCertificateFileName))
                    {
                        throw new Exception("Missing SSLCertificateThumbprint key in config file.");
                    }

                    //DisableAll(url);
                    //EnableHttps(url, theSSLCertificateThumbprint);
                    RemoveCert(url);
                    string fName = AppDomain.CurrentDomain.BaseDirectory + SSLCertificateFileName;
                    using (X509Store store = new X509Store(StoreName.My, StoreLocation.LocalMachine))
                    {
                        //Logger.Debug("Install ssl certificate " + fName + ".p12");
                        X509Certificate2 certificate = new X509Certificate2(fName + ".p12", "", X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet);
                        store.Open(OpenFlags.ReadWrite);
                        store.Add(certificate);
                        store.Close();
                       // Logger.Debug("Bind installed ssl certificate " + certificate.Thumbprint + " to " + url);
                        AddCert(url, certificate.Thumbprint);
                    }

                    System.Net.ServicePointManager.ServerCertificateValidationCallback += (se, cert, chain, sslerror) => true;
                    using (X509Store store = new X509Store(StoreName.Root, StoreLocation.LocalMachine))
                    {
                       // Logger.Debug("Install ssl certificate " + fName + ".cer");
                        X509Certificate2 certificate = new X509Certificate2(fName + ".cer");
                        store.Open(OpenFlags.ReadWrite);
                        store.Add(certificate);
                        store.Close();
                       
                    }
                }
                else if (theUrl.Scheme == "http")
                {
                    RemoveCert(url);
                }
            }
            catch (ArgumentNullException)
            {
                throw (new Exception("Missing WebAgentURL key in config file."));
            }
            catch (UriFormatException)
            {
                throw (new Exception("Invalid WebAgentURL url in config file."));
            }
        }
        private static void AddCert(string url, string certHash)
        {
            string arg1 = string.Format(@"http add sslcert ipport=0.0.0.0:{0} certhash={1} appid={2}", GetPort(url), certHash.Trim(), Guid.NewGuid().ToString("B"));
            // Logger.Debug("Add ssl certificate: " + arg1);
            var resp = RunNetsh(arg1);
           // if (RunNetsh(arg1))
           // Logger.Info("SSL setup successfully.");
           // else
           // Logger.Error("SSL setup was not successfull.");
        }
        private static void RemoveCert(string url)
        {
            var urls = ToHttpsUrl(url);
            string arg1 = string.Format(@"http delete sslcert ipport=0.0.0.0:{0}", GetPort(urls));
           // Logger.Debug("Remove ssl certificate: " + arg1);
            RunNetsh(arg1);
        }
        private static string ToHttpsUrl(string url)
        {
            UriBuilder theUrl = new UriBuilder(url);
            theUrl.Scheme = Uri.UriSchemeHttps;
            return theUrl.ToString();
        }
        //private static string ToHttpUrl(string url)
        //{
        //    UriBuilder theUrl = new UriBuilder(url);
        //    theUrl.Scheme = Uri.UriSchemeHttp;
        //    return theUrl.ToString();
        //}
        private static int GetPort(string url)
        {
            Uri theUrl = new Uri(url);
            return theUrl.Port;
        }

        //[PrincipalPermission(SecurityAction.Demand, Role = @"BUILTIN\Administrators")]
        private static bool RunNetsh(string args)
        {
            bool result = false;
            try
            {
                //System.Console.WriteLine(args);
                ProcessStartInfo psi = new ProcessStartInfo("netsh", args);

                psi.Verb = "runas";
                psi.CreateNoWindow = true;
                psi.ErrorDialog = false;
                psi.RedirectStandardError = true;
                //psi.RedirectStandardInput = true;
                psi.RedirectStandardOutput = true;
                psi.WindowStyle = ProcessWindowStyle.Hidden;
                psi.UseShellExecute = false;
                var ps = Process.Start(psi);
                string output = ps.StandardOutput.ReadToEnd();
                if (!string.IsNullOrEmpty(output))
                {
                    string msg = output.Replace("\r", " ").Replace("\n", " ");
                    if (msg.IndexOf("successfully") >= 0 || msg.IndexOf("deletion") >= 0)
                    {
                        //Logger.Debug(msg);
                        result = true;
                    }
                  //  else
                       // Logger.Error(msg);
                }
                string err = ps.StandardError.ReadToEnd();
               // if (!string.IsNullOrEmpty(err))
                    //Logger.Error(err.Replace("\r", " ").Replace("\n", " "));
                ps.WaitForExit();
            }
            catch (Exception e)
            {
                //Logger.Error("Execute Netsh command error: " + e.Message);
            }
            return result;
        }
    }
}
