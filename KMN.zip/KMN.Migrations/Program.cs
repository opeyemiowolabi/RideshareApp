﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KMN.Migrations.DataMigrations;

namespace KMN.Migrations
{
    class Program
    {
        static void Main(string[] args)
        {
            // KMNMigration.DoDbTableMigration();
            KMNDataMigrations mgr = new KMNDataMigrations();
            mgr.MigrateCars();
            Console.WriteLine("Migration completed ... press any key to exit.");
            Console.ReadKey();
        }
    }
}
