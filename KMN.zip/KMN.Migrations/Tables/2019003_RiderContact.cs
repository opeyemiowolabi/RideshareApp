﻿using FluentMigrator;
using System;

namespace KMN.Migrations.Tables
{
    [Migration(2019003)]
    public class RiderContact : Migration
    {
        public override void Up()
        {
            Create.Table("RiderContact")
                .WithColumn("RiderContactId").AsGuid().PrimaryKey()
                .WithColumn("RiderId").AsGuid().ForeignKey().NotNullable()
                .WithColumn("Address").AsString(50).Nullable()
                .WithColumn("CityOrLGA").AsGuid().ForeignKey().NotNullable().WithDefaultValue(new Guid())
                .WithColumn("State").AsGuid().ForeignKey().NotNullable().WithDefaultValue(new Guid())
                .WithColumn("PrimaryPhoneNo").AsString(50).Nullable()
                .WithColumn("SecondaryPhoneNo").AsString(50).Nullable()
                .WithColumn("Email").AsString(50).Nullable()
                .WithColumn("EmergencyContactName").AsString(50).Nullable()
                .WithColumn("EmergencyPhoneNumber").AsString(50).Nullable()
                .WithColumn("Status").AsByte().Nullable()
                .WithColumn("IsDeleted").AsBoolean().WithDefaultValue(false)
                .WithColumn("CreatedBy").AsGuid().Nullable()
                .WithColumn("LastUpdatedBy").AsGuid().Nullable()
                .WithColumn("DateCreated").AsDateTime().Nullable().WithDefaultValue(DateTime.Now)
                .WithColumn("LastUpdatedDate").AsDateTime().Nullable().WithDefaultValue(DateTime.Now);

            Create.ForeignKey("FK_RiderContact_Rider")
             .FromTable("RiderContact").ForeignColumn("RiderId")
             .ToTable("Rider").PrimaryColumn("RiderId");
        }

        public override void Down()
        {
            Delete.Table("RiderContact");
        }
    }
}
