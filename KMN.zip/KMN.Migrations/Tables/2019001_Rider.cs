﻿using FluentMigrator;
using System;

namespace KMN.Migrations.Tables
{
    [Migration(2019001)]
    public class Rider : Migration
    {
        public override void Up()
        {
            //Delete.Table("Customers");
            //IfDatabase("SalesInventoryDB").Delete.Table("Customers");
            Create.Table("Rider")
                .WithColumn("RiderId").AsGuid().PrimaryKey()
                .WithColumn("RiderNumber").AsString(50).Nullable()
                .WithColumn("FirstName").AsString(50).Nullable()
                .WithColumn("MiddleName").AsString(50).Nullable()
                .WithColumn("LastName").AsString(50).Nullable()
                .WithColumn("DateOfBirth").AsDate().Nullable()
                .WithColumn("Gender").AsByte().Nullable()
                .WithColumn("Email").AsString(50).Nullable()
                .WithColumn("PrimaryPhoneNumber").AsString(50).Nullable()
                .WithColumn("SecondaryPhoneNumber").AsString(50).Nullable()
                .WithColumn("TakeOffLocationId").AsGuid().ForeignKey().WithDefaultValue(new Guid()) // should be in Subscription
                .WithColumn("DestinationLocationId").AsGuid().ForeignKey().WithDefaultValue(new Guid()) // should be in Subscription
                .WithColumn("Occupation").AsString().Nullable()
                .WithColumn("Notes").AsString(250).Nullable()
                .WithColumn("Status").AsByte().Nullable()
                .WithColumn("IsDeleted").AsBoolean().WithDefaultValue(false)
                .WithColumn("CreatedBy").AsGuid().Nullable()
                .WithColumn("LastUpdatedBy").AsGuid().Nullable()
                .WithColumn("DateCreated").AsDateTime().Nullable().WithDefaultValue(DateTime.Now)
                .WithColumn("LastUpdatedDate").AsDateTime().Nullable().WithDefaultValue(DateTime.Now);

        }

        public override void Down()
        {
            Delete.Table("Rider");
        }
    }
}
