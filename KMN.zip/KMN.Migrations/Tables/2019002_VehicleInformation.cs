﻿using FluentMigrator;
using System;

namespace KMN.Migrations.Tables
{
    [Migration(2019002)]
    public class VehicleInformation : Migration
    {
        public override void Up()
        {
            Create.Table("VehicleInformation")
                .WithColumn("VehicleInformationId").AsGuid().PrimaryKey()
                .WithColumn("RiderId").AsGuid().ForeignKey().NotNullable().WithDefaultValue(new Guid())
                .WithColumn("VehicleType").AsGuid().ForeignKey().NotNullable().WithDefaultValue(new Guid())
                .WithColumn("VehicleMaker").AsGuid().ForeignKey().NotNullable().WithDefaultValue(new Guid())
                .WithColumn("VehicleModel").AsGuid().ForeignKey().NotNullable().WithDefaultValue(new Guid())
                .WithColumn("NumberOfPassenger").AsInt32().NotNullable().WithDefaultValue(2)
                .WithColumn("Status").AsByte().Nullable()
                .WithColumn("IsDeleted").AsBoolean().WithDefaultValue(false)
                .WithColumn("CreatedBy").AsGuid().Nullable()
                .WithColumn("LastUpdatedBy").AsGuid().Nullable()
                .WithColumn("DateCreated").AsDateTime().Nullable().WithDefaultValue(DateTime.Now)
                .WithColumn("LastUpdatedDate").AsDateTime().Nullable().WithDefaultValue(DateTime.Now);

            Create.ForeignKey("FK_VehicleInformation_Rider")
             .FromTable("VehicleInformation").ForeignColumn("RiderId")
             .ToTable("Rider").PrimaryColumn("RiderId");
        }

        public override void Down()
        {
            Delete.Table("VehicleInformation");
        }
    }
}
