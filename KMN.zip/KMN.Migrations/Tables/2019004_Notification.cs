﻿using FluentMigrator;
using System;

namespace KMN.Migrations.Tables
{
    [Migration(2019004)]
    public class Notification : Migration
    {
        public override void Up()
        {
            Create.Table("Notification")
                .WithColumn("NotificationId").AsGuid().PrimaryKey()
                .WithColumn("MessageId").AsGuid()
                .WithColumn("SenderId").AsString(250).Nullable()
                .WithColumn("RecipientId").AsString(250).Nullable()
                .WithColumn("MessageTitle").AsString(250).Nullable()
                .WithColumn("MessageBody").AsString(500).Nullable()
                .WithColumn("NotificationType").AsByte().Nullable()
                .WithColumn("DeliveryStatus").AsByte().Nullable()
                .WithColumn("IsDeleted").AsBoolean().WithDefaultValue(false)
                .WithColumn("Timestamp").AsDateTime().Nullable().WithDefaultValue(DateTime.Now)
                .WithColumn("ExpirationTime").AsDateTime().Nullable().WithDefaultValue(DateTime.Now);
        }

        public override void Down()
        {
            Delete.Table("Notification");
        }
    }
}
