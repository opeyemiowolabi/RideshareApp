﻿using System;
using FluentMigrator.Runner;
using Microsoft.Extensions.DependencyInjection;
using KMN.Migrations.Tables;
using System.Configuration;

namespace KMN.Migrations
{
   public class KMNMigration
    {
        public static bool DoDbTableMigration()
        {
            string conStr = ConfigurationManager.AppSettings["dbConnection"];
            bool isValidDbVersion = Int32.TryParse( ConfigurationManager.AppSettings["dbVersion"], out int dbSupport );
            if (!isValidDbVersion) dbSupport = 2012;

            var serviceProvider = CreateServices(conStr, dbSupport);

            // Put the database update into a scope to ensure
            // that all resources will be disposed.
            using (var scope = serviceProvider.CreateScope())
            {
                UpdateDatabase(scope.ServiceProvider);
            }

            return true;
        }

        /// <summary>
        /// Configure the dependency injection services
        /// </sumamry>
        private static IServiceProvider CreateServices(string conString, int dbSupport)
        {

            var svcCollection = new ServiceCollection();
            svcCollection.AddFluentMigratorCore();

            switch (dbSupport)
            {
                case 2008:
                    svcCollection.ConfigureRunner(x => x.AddSqlServer2008());
                    break;

                case 2012:
                    svcCollection.ConfigureRunner(x => x.AddSqlServer2012());
                    break;

                case 2014:
                    svcCollection.ConfigureRunner(x => x.AddSqlServer2016());
                    break;

                default:
                case 2016:
                    svcCollection.ConfigureRunner(x => x.AddSqlServer2012());
                    break;
            }
            svcCollection.ConfigureRunner(x => x.WithGlobalConnectionString(conString));
            svcCollection.ConfigureRunner(x => x.ScanIn(typeof(Rider).Assembly));
            svcCollection.ConfigureRunner(x => x.ScanIn(typeof(RiderContact).Assembly));
            svcCollection.ConfigureRunner(x => x.ScanIn(typeof(VehicleInformation).Assembly));
            svcCollection.ConfigureRunner(x => x.ScanIn(typeof(Notification).Assembly).For.Migrations());
            svcCollection.AddLogging(lb => lb.AddFluentMigratorConsole());

           return  svcCollection.BuildServiceProvider(false);
        }

        /// <summary>
        /// Update the database
        /// </sumamry>
        private static void UpdateDatabase(IServiceProvider serviceProvider)
        {
            // Instantiate the runner
            var runner = serviceProvider.GetRequiredService<IMigrationRunner>();

            // Execute the migrations
            runner.MigrateUp();
        }
    }
}
