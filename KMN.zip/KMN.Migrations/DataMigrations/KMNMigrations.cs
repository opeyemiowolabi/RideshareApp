﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KMN.Migrations.DataMigrations
{
    public class KMNDataMigrations
    {
        DataFactory factory;
        public KMNDataMigrations()
        {
            factory = new DataFactory();

        }

        public async Task<int> MigrateCars()
        {
            //load csv
            
            var carList = factory.ExtractCars("cars.csv", true);

            var load = await factory.LoadCars(carList);

            return 1;

        }
    }
}
