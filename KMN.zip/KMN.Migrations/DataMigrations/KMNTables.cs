﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KMN.Migrations.DataMigrations
{
   public class MigrationTemplate<TResult>
    {
        public List<TResult> Columns { get; set; }
        public string Name { get; set; }
        public string Path { get; set; }
        public string Type { get; set; }
    }
   public class Cars : AuditEntity
    {
        public Guid CarDataId { get; set; }
        public string CarCode { get; set; }
        public string Make { get; set; }
        public int Year { get; set; }
        public string ModelYear { get; set; }
    }

    public abstract class AuditEntity
    {
        public byte Status { get; set; } = 1;
        public bool IsDeleted { get; set; } = false;
        public Guid CreatedBy { get; set; }
        public Guid LastUpdatedBy { get; set; }
        public DateTime? DateCreated { get; set; } = DateTime.Now;
        public DateTime? LastUpdatedDate { get; set; } = DateTime.Now;
    }
}
