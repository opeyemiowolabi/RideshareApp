﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Microsoft.VisualBasic.FileIO;
using Dapper;
using System.Data;
using System.Configuration;

namespace KMN.Migrations.DataMigrations
{
    public class DataFactory
    {
        public static MigrationTemplate<TResult> LoadTemplate<TResult>(string xPath, TResult result)
        {
            StringBuilder sb = new StringBuilder();
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load("template.xml");
            string xpath = string.Format("/template/{0}", xPath);
            XmlNodeList nodeList = xmlDoc.DocumentElement.SelectNodes(xpath);
            foreach (XmlNode lnode in nodeList)
            {
                Type v = result.GetType();
                
                foreach (XmlNode mnode in lnode)
                {
                    XmlAttribute mnode_attr_num = mnode.Attributes["num"];
                    XmlAttribute mnode_attr_group = mnode.Attributes["group"];
                    XmlAttribute mnode_attr_desc = mnode.Attributes["desc"];
                    XmlAttribute mnode_attr_header = mnode.Attributes["headerId"];

                    //if (mnode_attr_group.InnerText == grp)
                    //{
                    //    sb.AppendLine(string.Format("{0}    {1}   {2}\n ", mnode_attr_num.InnerText, mnode_attr_desc.InnerText, mnode_attr_header.InnerText));
                    //}
                }
            }
            return null;//sb.ToString();
        }

        public IEnumerable<Cars> ExtractCars(string path, bool hasHeader = true)
        {
            var cars = new List<Cars>();
            using (TextFieldParser csvParser = new TextFieldParser(path))
            {
                csvParser.CommentTokens = new string[] { "#","//" };
                csvParser.SetDelimiters(new string[] { "," });
                csvParser.HasFieldsEnclosedInQuotes = true;

                // Skip the row with the column names
                if(hasHeader) csvParser.ReadLine();

                while (!csvParser.EndOfData)
                {
                    // Read current line fields, pointer moves to the next line.
                    string[] fields = csvParser.ReadFields();
                    cars.Add(new Cars
                    {
                        CarDataId = Guid.NewGuid(),
                        CarCode = fields[12],
                        Make = fields[11],
                        ModelYear = fields[12],
                        Year = Convert.ToInt32(fields[17])
                    });
                }

                return cars;
            }
        }

        public async Task<int> LoadCars(IEnumerable<Cars> cars)
        {
            try
            {
                using (IDbConnection db = new SqlConnection(ConfigurationManager.AppSettings["dbConnection"]))
                {
                    foreach (var car in cars)
                    {
                        var query = await db.QueryAsync<Cars>("Select * From CarDatas WHERE CarCode = @CarCode", new { car.CarCode }).ConfigureAwait(false);

                        if (!query.Any())
                        {
                            string sqlQuery = " INSERT INTO CarDatas (CarDataId,CarCode,Make,Year,ModelYear,Status,IsDeleted,CreatedBy,LastUpdatedBy,DateCreated,LastUpdatedDate)" +
                                         " VALUES (@CarDataId,@CarCode,@Make,@Year,@ModelYear,@Status,@IsDeleted,@CreatedBy,@LastUpdatedBy,@DateCreated,@LastUpdatedDate)";

                            int rowsAffected = db.Execute(sqlQuery, car);
                        }
                    }
                }
            }
            catch ( Exception ex)
            {
                Console.WriteLine(ex);
            }
           

            return 1;
        }
    }
}
