﻿using Softmark.Shared.Domain.Enum;
using Softmark.Shared.Domain.Utilities;
using System;
using System.Collections.Generic;
using System.Data.Entity.Spatial;
using System.Linq;
using System.Text;

namespace KMN.Domain.Entities
{
    public class Subscription : DomainAudit, IEquatable<Subscription>
    {
        private HashSet<Subscriber> _subscribers = new HashSet<Subscriber>();

        private Subscription(Guid id , Guid riderId, Guid vehicleId, DbGeography pickupLocation, DbGeography dropOffLocation, DateTime? estimatedPickupDateTime, DateTime? estimatedDroppOffDateTime
           ,int maxPassengerAllowed, EntityRiderType riderType, decimal baseFare, EntityRequestStatus requestStatus, string notes, IEnumerable<Subscriber> subscribers)
        {
            SubscriptionId = id;
            RiderId = riderId;
            VehicleId = vehicleId;
            PickupLocation = pickupLocation;
            DropOffLocation = dropOffLocation;
            EstimatedPickupDateTime = estimatedPickupDateTime;
            EstimatedDroppOffDateTime = estimatedDroppOffDateTime;
            MaxPassengerAllowed = maxPassengerAllowed;
            RiderType = riderType;
            BaseFare = baseFare;
            RequestStatus = requestStatus;
            Notes = notes;

            if (subscribers != null)
            foreach (var subscriber in subscribers) _subscribers.Add(subscriber);
        }


        #region public properties
        public Guid SubscriptionId { get; private set; }
        public Guid RiderId { get; private set; }
        public Guid VehicleId { get; private set; }
        public DbGeography PickupLocation { get; private set; }
        public DbGeography DropOffLocation { get; private set; }

        public DateTime? EstimatedPickupDateTime { get; set; }
        public DateTime? EstimatedDroppOffDateTime { get; set; }
        public int MaxPassengerAllowed { get; set; } = 1;
        public EntityRiderType RiderType { get; set; }  // (Not needed now)
        public decimal BaseFare { get; set; } = 0.00M;
        public EntityRequestStatus RequestStatus { get; set; }
        public string Notes { get; set; }

        public IEnumerable<Subscriber> Subscribers => _subscribers;

        #endregion


        public bool AddSubscriber(Subscriber rSubscriber)
        {
            return rSubscriber != null && _subscribers.Add(rSubscriber);
        }

        public bool AddSubscribers(IEnumerable<Subscriber> rSubscribers)
        {
            var result = true;
            foreach (var subscrib in rSubscribers)
            {
                result &= _subscribers.Add(subscrib);
            }
            return result;
        }

      
        public static Subscription CreateNew(Guid riderId, Guid vehicleId, DbGeography pickupLocation, DbGeography dropOffLocation, DateTime? estimatedPickupDateTime, DateTime? estimatedDroppOffDateTime
           , int maxPassengerAllowed, EntityRiderType riderType, decimal baseFare, EntityRequestStatus requestStatus, string notes, IEnumerable<Subscriber> subscribers)
        {
            Guid id = Guid.NewGuid();
            return new Subscription( id,riderId,vehicleId,  pickupLocation, dropOffLocation, estimatedPickupDateTime,estimatedDroppOffDateTime
           ,  maxPassengerAllowed,  riderType,  baseFare,  requestStatus,  notes, subscribers);
        }

        public static Subscription CreateExisting(Guid id, Guid riderId, Guid vehicleId, DbGeography pickupLocation, DbGeography dropOffLocation, DateTime? estimatedPickupDateTime, DateTime? estimatedDroppOffDateTime
           , int maxPassengerAllowed, EntityRiderType riderType, decimal baseFare, EntityRequestStatus requestStatus, string notes, IEnumerable<Subscriber> subscribers)
        {
            return new Subscription(id, riderId, vehicleId, pickupLocation, dropOffLocation, estimatedPickupDateTime, estimatedDroppOffDateTime
           , maxPassengerAllowed, riderType, baseFare, requestStatus, notes, subscribers);
        }

        public bool Equals(Subscription other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return _subscribers.SequenceEqual(other.Subscribers)
                    && string.Equals(SubscriptionId.ToString(), other.SubscriptionId.ToString(),
                       StringComparison.OrdinalIgnoreCase) 
                    && string.Equals(RiderId.ToString(), other.RiderId.ToString(),
                       StringComparison.OrdinalIgnoreCase); 
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((Subscription)obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                var hashCode = (_subscribers != null ? _subscribers.GetEnumerableHashCode() : 0);
                hashCode = (hashCode * 397) ^ (SubscriptionId != null ? SubscriptionId.GetHashCode() : 0);
                hashCode = (hashCode * 397) ^ (VehicleId != null ? VehicleId.GetHashCode() : 0);
                hashCode = (hashCode * 397) ^ (PickupLocation != null ? PickupLocation.GetHashCode() : 0);
                hashCode = (hashCode * 397) ^ (DropOffLocation != null ? DropOffLocation.GetHashCode() : 0);
                hashCode = (hashCode * 397) ^ (EstimatedPickupDateTime != null ? EstimatedPickupDateTime.GetHashCode() : 0);
                hashCode = (hashCode * 397) ^ (EstimatedDroppOffDateTime != null ? EstimatedDroppOffDateTime.GetHashCode() : 0);
                return hashCode;
            }
        }
    }
}
