﻿using Softmark.Shared.Domain.Enum;
using Softmark.Shared.Domain.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KMN.Domain.Entities
{
    public class Rider : DomainAudit, IEquatable<Rider>
    {
        private HashSet<RiderContact> _contacts = new HashSet<RiderContact>();
        private HashSet<VehicleInformation> _vehicleInfos = new HashSet<VehicleInformation>();

        private Rider(Guid id , string riderNumber, string userName, string password, string confirmPassword , string firstName, string middleName, string lastName, DateTime? dateOfBirth,
            EntityGender gender, string email, string primaryPhoneNumber, string secondaryPhoneNumber, Guid takeOffLocationId, Guid destinationLocationId
            , string occupation, string notes, DateTime? dateCreated, DateTime? lastUpdatedDate
            , IEnumerable<RiderContact> contacts,IEnumerable<VehicleInformation> vehicleInfos)
        {
            RiderId = id;
            RiderNumber = riderNumber;
            UserName = userName;
            Password = password;
            ConfirmPassword = confirmPassword;
            FirstName = firstName;
            MiddleName = middleName;
            LastName = lastName;
            DateOfBirth = dateOfBirth;
            Gender = gender;
            Email = email;
            PrimaryPhoneNumber = primaryPhoneNumber;
            SecondaryPhoneNumber = secondaryPhoneNumber;
            TakeOffLocationId = takeOffLocationId;
            DestinationLocationId = destinationLocationId;
            Occupation = occupation;
            Notes = notes;
            DateCreated = dateCreated;
            LastUpdatedDate = lastUpdatedDate;

            if (contacts != null)
            foreach (var contact in contacts) _contacts.Add(contact);

            if (vehicleInfos != null)
                foreach (var info in vehicleInfos) _vehicleInfos.Add(info);
        }


        #region public properties
        public Guid RiderId { get; private set; }
        public string RiderNumber { get; private set; }
        public string UserName { get; private set; }
        public string Password { get; private set; }
        public string ConfirmPassword { get; private set; }
        public string FirstName { get; private set; }
        public string MiddleName { get; private set; }
        public string LastName { get; private set; }
        public DateTime? DateOfBirth { get; private set; }
        public EntityGender Gender { get; private set; }
        public string Email { get; private set; }
        public string PrimaryPhoneNumber { get; private set; }
        public string SecondaryPhoneNumber { get; private set; }
        public Guid TakeOffLocationId { get; private set; }
        public Guid DestinationLocationId { get; private set; }
        public string Occupation { get; private set; }
        public string Notes { get; private set; }
        public IEnumerable<RiderContact> Contacts => _contacts;
        public IEnumerable<VehicleInformation> VehicleInfo => _vehicleInfos;

        #endregion


        public bool AddContact(RiderContact rContact)
        {
            return rContact != null && _contacts.Add(rContact);
        }

        public bool AddContacts(IEnumerable<RiderContact> rContacts)
        {
            var result = true;
            foreach (var contact in rContacts)
            {
                result &= _contacts.Add(contact);
            }
            return result;
        }

        public bool AddVehicleInfo(VehicleInformation vInfo)
        {
            return vInfo != null && _vehicleInfos.Add(vInfo);
        }

        public bool AddVehicleInfo(IEnumerable<VehicleInformation> vInfos)
        {
            var result = true;
            foreach (var vInfo in vInfos)
            {
                result &= _vehicleInfos.Add(vInfo);
            }
            return result;
        }

        public static Rider CreateNew(string riderNumber,string userName, string password, string confirmPassword ,string firstName, string middleName, string lastName, DateTime? dateOfBirth,
            EntityGender gender, string email, string primaryPhoneNumber,string secondaryPhoneNumber, Guid takeOffLocationId, Guid destinationLocationId
            ,string occupation, string notes, DateTime? dateCreated, DateTime? lastUpdatedDate, IEnumerable<RiderContact> contacts, IEnumerable<VehicleInformation> vehicleInfos)
        {
            Guid id = Guid.NewGuid();
            return new Rider( id,riderNumber,  userName,  password,  confirmPassword, firstName,middleName,lastName,dateOfBirth,gender,email,primaryPhoneNumber
                           ,secondaryPhoneNumber,takeOffLocationId,destinationLocationId,occupation,notes,dateCreated,lastUpdatedDate,contacts, vehicleInfos );
        }

        public static Rider CreateExisting(Guid id,string riderNumber, string userName, string password, string confirmPassword, string firstName, string middleName, string lastName, DateTime? dateOfBirth,
            EntityGender gender, string email, string primaryPhoneNumber, string secondaryPhoneNumber, Guid takeOffLocationId, Guid destinationLocationId
            , string occupation, string notes, DateTime? dateCreated, DateTime? lastUpdatedDate, IEnumerable<RiderContact> contacts, IEnumerable<VehicleInformation> vehicleInfos)
        {
            return new Rider(id, riderNumber,  userName,  password,  confirmPassword, firstName, middleName, lastName, dateOfBirth, gender, email, primaryPhoneNumber
                           , secondaryPhoneNumber, takeOffLocationId, destinationLocationId, occupation, notes, dateCreated, lastUpdatedDate, contacts, vehicleInfos);
        }

        public bool Equals(Rider other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return _contacts.SequenceEqual(other.Contacts)
                    && string.Equals(FirstName, other.FirstName,
                       StringComparison.OrdinalIgnoreCase) //  case insensitive
                    && string.Equals(LastName, other.LastName,
                       StringComparison.OrdinalIgnoreCase) //  case insensitive
                    && string.Equals(Email, other.Email,
                       StringComparison.OrdinalIgnoreCase) // case insensitive
                    && string.Equals(RiderNumber, other.RiderNumber,
                       StringComparison.OrdinalIgnoreCase); // case insensitive
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((Rider)obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                var hashCode = (_contacts != null ? _contacts.GetEnumerableHashCode() : 0);
                hashCode = (hashCode * 397) ^ (Email != null ? Email.ToLowerInvariant().GetHashCode() : 0);
                hashCode = (hashCode * 397) ^ (FirstName != null ? FirstName.GetHashCode() : 0);
                hashCode = (hashCode * 397) ^ (LastName != null ? LastName.GetHashCode() : 0);
                hashCode = (hashCode * 397) ^ (RiderNumber != null ? RiderNumber.GetHashCode() : 0);
                return hashCode;
            }
        }
    }
}
