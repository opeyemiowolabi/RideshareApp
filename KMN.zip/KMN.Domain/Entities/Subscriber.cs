﻿using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Text;

namespace KMN.Domain.Entities
{
    public class Subscriber : DomainAudit
    {
        public Guid SubscriberId { get; set; }
        public Guid SubscriptionId { get; set; }
        public Guid PassengerRouteId { get; set; }
        public decimal AgreedFare { get; set; } = 0.00M;
        public EntityRequestStatus DriverApproval { get; set; }
        public EntityRequestStatus PassengerApproval { get; set; }
        public string Notes { get; set; }  
    }
}