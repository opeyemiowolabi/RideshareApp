﻿using System;
using Softmark.Shared.Domain.Enum;
using Softmark.Shared.Domain.Utilities;
using System.Collections.Generic;
using System.Text;

namespace KMN.Domain.Entities
{
   public class RiderContact: DomainAudit
    {
        public Guid ContactId { get; set; }
        public Guid RiderId { get; set; }
        public string Address { get; set; }
        public Guid CityOrLGA { get; set; }
        public Guid State { get; set; }
        public string PrimaryPhoneNo { get; set; }
        public string SecondaryPhoneNo { get; set; }
        public string Email { get; set; }
        public string EmergencyContactName { get; set; }
        public string EmergencyPhoneNumber { get; set; }
    }
}
