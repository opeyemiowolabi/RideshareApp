﻿using System;
using Softmark.Shared.Domain.Enum;
using Softmark.Shared.Domain.Utilities;

namespace KMN.Domain.Entities
{
    public class CarData : DomainAudit
    {
        public Guid CarDataId { get; set; }
        public string CarCode { get; set; }
        public string Make { get; set; }
        public string Year { get; set; }
        public string ModelYear { get; set; }
    }

}