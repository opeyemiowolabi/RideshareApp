﻿using Softmark.Shared.Domain.Enum;
using Softmark.Shared.Domain.Utilities;
using System;
using System.Collections.Generic;
using System.Data.Entity.Spatial;
using System.Linq;
using System.Text;

namespace KMN.Domain.Entities
{
    public class PassengerRoute : DomainAudit, IEquatable<PassengerRoute>
    {
        private PassengerRoute(Guid id , Guid riderId, DbGeography pickupLocation, DbGeography dropOffLocation, DateTime? estimatedPickupDateTime
           ,EntityRiderType riderType, decimal baseFare, EntityRequestStatus requestStatus, string notes)
        {
            PassengerRouteId = id;
            RiderId = riderId;
            PickupLocation = pickupLocation;
            DropOffLocation = dropOffLocation;
            EstimatedPickupDateTime = estimatedPickupDateTime;
            RiderType = riderType;
            BaseFare = baseFare;
            RequestStatus = requestStatus;
            Notes = notes;
        }

        private PassengerRoute(Guid id, Guid riderId, string passengerNames, string passengerEmail, string passengerPhone, DbGeography pickupLocation, DbGeography dropOffLocation, DateTime? estimatedPickupDateTime
         , EntityRiderType riderType, decimal baseFare, EntityRequestStatus requestStatus, string notes)
        {
            PassengerRouteId = id;
            RiderId = riderId;
            PickupLocation = pickupLocation;
            DropOffLocation = dropOffLocation;
            EstimatedPickupDateTime = estimatedPickupDateTime;
            RiderType = riderType;
            BaseFare = baseFare;
            RequestStatus = requestStatus;
            Notes = notes;
            PassengerNames = passengerNames;
            PassengerEmail = passengerEmail;
            PassengerPhone = passengerPhone;
        }

        #region public properties
        public Guid PassengerRouteId { get; private set; }
        public Guid RiderId { get; private set; }
        public string PassengerNames { get; set; }
        public string PassengerEmail { get; set; }
        public string PassengerPhone { get; set; }
        public DbGeography PickupLocation { get; private set; }
        public DbGeography DropOffLocation { get; private set; }
        public DateTime? EstimatedPickupDateTime { get; set; }
        public EntityRiderType RiderType { get; set; }  // (Not needed now)
        public decimal BaseFare { get; set; } = 0.00M;
        public EntityRequestStatus RequestStatus { get; set; }
        public string Notes { get; set; }
        #endregion

      
        public static PassengerRoute CreateNew(Guid riderId, DbGeography pickupLocation, DbGeography dropOffLocation, DateTime? estimatedPickupDateTime,
            EntityRiderType riderType, decimal baseFare, EntityRequestStatus requestStatus, string notes)
        {
            Guid id = Guid.NewGuid();
            return new PassengerRoute( id,riderId,pickupLocation, dropOffLocation, estimatedPickupDateTime,riderType,baseFare,requestStatus,  notes);
        }

        public static PassengerRoute CreateExisting(Guid id, Guid riderId,string passengerNames, string passengerEmail, string passengerPhone, DbGeography pickupLocation, DbGeography dropOffLocation, DateTime? estimatedPickupDateTime,
          EntityRiderType riderType, decimal baseFare, EntityRequestStatus requestStatus, string notes)
        {
            return new PassengerRoute(id, riderId, passengerNames, passengerEmail, passengerPhone, pickupLocation, dropOffLocation, estimatedPickupDateTime, 
           riderType, baseFare, requestStatus, notes);
        }

        public bool Equals(PassengerRoute other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;
            return 
                     string.Equals(PassengerRouteId.ToString(), other.PassengerRouteId.ToString(),
                       StringComparison.OrdinalIgnoreCase) 
                    && string.Equals(RiderId.ToString(), other.RiderId.ToString(),
                       StringComparison.OrdinalIgnoreCase); 
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((PassengerRoute)obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                var hashCode =  (PassengerRouteId != null ? PassengerRouteId.GetHashCode() : 0);
                hashCode = (hashCode * 397) ^ (PickupLocation != null ? PickupLocation.GetHashCode() : 0);
                hashCode = (hashCode * 397) ^ (DropOffLocation != null ? DropOffLocation.GetHashCode() : 0);
                hashCode = (hashCode * 397) ^ (EstimatedPickupDateTime != null ? EstimatedPickupDateTime.GetHashCode() : 0);
                return hashCode;
            }
        }
    }
}
