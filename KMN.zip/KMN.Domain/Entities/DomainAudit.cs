﻿using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Text;

namespace KMN.Domain.Entities
{
    public class DomainAudit
    {
        public EntityStatus Status { get;  set; }
        public Guid CreatedBy { get;  set; }
        public Guid LastUpdatedBy { get;  set; }
        public DateTime? DateCreated { get;  set; }
        public DateTime? LastUpdatedDate { get;  set; }
    }
}
