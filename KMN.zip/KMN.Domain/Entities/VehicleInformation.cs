﻿using System;
using Softmark.Shared.Domain.Enum;
using Softmark.Shared.Domain.Utilities;

namespace KMN.Domain.Entities
{
   public class VehicleInformation : DomainAudit
    {
        public Guid VehicleInformationId { get; set; }
        public Guid RiderId { get; set; }
        public Guid CarDataId { get; set; }
        public int NumberOfPassenger { get; set; }
        public string PlateNumber { get; set; }
        public string ChasisNumber { get; set; }
    }
}
