﻿using Softmark.Shared.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Data.Entity.Spatial;

namespace KMN.Domain.Result
{
    public class AddSubscriptionInfoResult : DomainObject
    {
        public AddSubscriptionInfoResult()
        {

        }

        public Guid SubscriptionId { get; set; } // Agregated Entity Id
    }

    public class DriverSubscriptionInfoResult : DomainObject
    {
        public DriverSubscriptionInfoResult()
        {

        }

        public Guid SubscriptionId { get;  set; }
        public Guid RiderId { get;  set; }
        public Guid VehicleId { get;  set; }
        public string DriverNames { get; set; }
        public string DriverEmail { get; set; }
        public string DriverPhone { get; set; }
        public DbGeography PickupLocation { get;  set; }
        public DbGeography DropOffLocation { get;  set; }
        public DateTime? EstimatedPickupDateTime { get; set; }
        public DateTime? EstimatedDroppOffDateTime { get; set; }
        public int MaxPassengerAllowed { get; set; } = 1;
        public EntityRiderType RiderType { get; set; }  // (Not needed now)
        public decimal BaseFare { get; set; } = 0.00M;
        public EntityRequestStatus RequestStatus { get; set; }
        public string Notes { get; set; }
        public IEnumerable<SubscriberInforesult> Subscribers { get; set; }
    }

    public class SubscriberInforesult 
    {
        public Guid SubscriberId { get; set; }
        public Guid SubscriptionId { get; set; }
        public string PassengerNames { get; set; }
        public string PassengerEmail { get; set; }
        public string PassengerPhone { get; set; }
        public Guid PassengerRouteId { get; set; }
        public decimal AgreedFare { get; set; } = 0.00M;
        public EntityRequestStatus DriverApproval { get; set; }
        public EntityRequestStatus PassengerApproval { get; set; }
        public string Notes { get; set; }
    }

    public class PassengerRouteInforesult
    {
        public Guid PassengerRouteId { get; set; }
        public Guid RiderId { get; set; }
        public string PassengerNames { get; set; }
        public string PassengerEmail { get; set; }
        public string PassengerPhone { get; set; }
        public EntityRiderType RiderType { get; set; }  // (Not needed now)
        public DateTime? EstimatedPickupDateTime { get; set; }
        public DbGeography PickupLocation { get; set; }
        public DbGeography DropOffLocation { get; set; }
        public decimal BaseFare { get; set; } = 0.00M;
        public EntityRequestStatus DriverApproval { get; set; }
        public EntityRequestStatus PassengerApproval { get; set; }
        public string Notes { get; set; }
    }

    public class DriverJoinRequestInforesult
    {
        public Guid SubscriberId { get; set; }
        public Guid SubscriptionId { get; set; }
        public Guid PassengerRouteId { get; set; }
       
    }
}
