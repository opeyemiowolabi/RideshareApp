﻿using KMN.Domain.Entities;
using Softmark.Shared.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Text;

namespace KMN.Domain.Result
{
    public class GetCarDataInfoResult : DomainObject
    {
        public GetCarDataInfoResult()
        {

        }

        #region public properties
        public Guid CarDataId { get; set; }
        public string CarCode { get; set; }
        public string Make { get; set; }
        public string Year { get; set; }
        public string ModelYear { get; set; }
        #endregion
    }
}
