﻿using KMN.Domain.Entities;
using Softmark.Shared.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Text;

namespace KMN.Domain.Result
{
    public class AddRiderInfoResult : DomainObject
    {
        public AddRiderInfoResult()
        {

        }
      
        public Guid RiderId { get; set; } // Agregated Entity Id
        public string RiderNumber { get; set; } // Agregated Entity Id
        public Guid[] Contacts { get; set; }
        public Guid[] VehicleInfoIds { get; set; }
    }

    public class GetRiderInfoResult : DomainObject
    {
        public GetRiderInfoResult()
        {

        }
        #region public properties
        public Guid RiderId { get;  set; }
        public string UserName { get; set; }
        public string RiderNumber { get;  set; }
        public string FirstName { get;  set; }
        public string MiddleName { get;  set; }
        public string LastName { get;  set; }
        public string Email { get;  set; }
        public string PrimaryPhoneNumber { get;  set; }
        public string SecondaryPhoneNumber { get;  set; }
        public string Occupation { get;  set; }
        public string Notes { get;  set; }
        public IEnumerable<RiderContactInfoResult> Contacts { get; set; }
        public IEnumerable<RiderVehicleInfoResult> Vehicles { get; set; }
        #endregion
    }

    public class RiderContactInfoResult
    {
        public Guid ContactId { get; set; }
        public Guid RiderId { get; set; }
        public string Address { get; set; }
        public Guid CityOrLGA { get; set; }
        public Guid State { get; set; }
        public string PrimaryPhoneNo { get; set; }
        public string SecondaryPhoneNo { get; set; }
        public string Email { get; set; }
        public string EmergencyContactName { get; set; }
        public string EmergencyPhoneNumber { get; set; }
    }

    public class RiderVehicleInfoResult
    {
        public Guid VehicleInformationId { get; set; }
        public Guid RiderId { get; set; }
        public Guid CarDataId { get; set; }
        public int NumberOfPassenger { get; set; }
        public string PlateNumber { get; set; }
        public string ChasisNumber { get; set; }
        public string CarCode { get; set; }
        public string Make { get; set; }
        public string Year { get; set; }
        public string ModelYear { get; set; }
    }

    public class UpdateRiderContactInfoResult 
    {
        public UpdateRiderContactInfoResult()
        {

        }
        public Guid TransactionId { get; set; }
        public Guid RiderId { get; set; }
        public Guid ContactId { get; set; }

        public bool IsUpdated { get; set; }
    }
}
