﻿//using System;
//using System.Collections.Generic;
//using System.Text;

//namespace KMN.Persistence.Migrations
//{
//    using System;
//    using System.Data.Entity.Migrations;

//    public partial class Init : DbMigration
//    {
//        public override void Up()
//        {
//            CreateTable(
//                "dbo.Devices",
//                c => new
//                {
//                    Id = c.Int(nullable: false, identity: true),
//                    Name = c.String(),
//                    MacAddress = c.String(),
//                    DeviceType = c.Int(nullable: false),
//                    Unid = c.Int(nullable: false),
//                    Created = c.Int(nullable: false),
//                    CreateBy = c.String(),
//                    LastModified = c.Int(nullable: false),
//                    LastModifiedBy = c.String(),
//                    Version = c.Int(nullable: false),
//                    CreatedTimestamp = c.DateTimeOffset(nullable: false, precision: 7),
//                    CreatedBy = c.Int(nullable: false),
//                    ModifiedTimestamp = c.DateTimeOffset(precision: 7),
//                    ModifiedBy = c.Int(),
//                    CreatedByName = c.String(),
//                    ModifiedByName = c.String(),
//                })
//                .PrimaryKey(t => t.Id);

//            CreateTable(
//                "dbo.Holidays",
//                c => new
//                {
//                    Id = c.Int(nullable: false, identity: true),
//                    Name = c.String(),
//                    NumberOfDays = c.Int(nullable: false),
//                    Repeat = c.Boolean(nullable: false),
//                    Date = c.DateTime(nullable: false, storeType: "date"),
//                    Unid = c.Int(nullable: false),
//                    Created = c.Int(nullable: false),
//                    CreateBy = c.String(),
//                    LastModified = c.Int(nullable: false),
//                    LastModifiedBy = c.String(),
//                    Version = c.Int(nullable: false),
//                    CreatedTimestamp = c.DateTimeOffset(nullable: false, precision: 7),
//                    CreatedBy = c.Int(nullable: false),
//                    ModifiedTimestamp = c.DateTimeOffset(precision: 7),
//                    ModifiedBy = c.Int(),
//                    CreatedByName = c.String(),
//                    ModifiedByName = c.String(),
//                    Calendar_Id = c.Int(),
//                    HolidayType_Id = c.Int(),
//                })
//                .PrimaryKey(t => t.Id)
//                .ForeignKey("dbo.HolidayCalendars", t => t.Calendar_Id)
//                .ForeignKey("dbo.HolidayTypes", t => t.HolidayType_Id)
//                .Index(t => t.Calendar_Id)
//                .Index(t => t.HolidayType_Id);

//            CreateTable(
//                "dbo.HolidayCalendars",
//                c => new
//                {
//                    Id = c.Int(nullable: false, identity: true),
//                    Unid = c.Int(nullable: false),
//                    Created = c.Int(nullable: false),
//                    CreateBy = c.String(),
//                    LastModified = c.Int(nullable: false),
//                    LastModifiedBy = c.String(),
//                    Version = c.Int(nullable: false),
//                    CreatedTimestamp = c.DateTimeOffset(nullable: false, precision: 7),
//                    CreatedBy = c.Int(nullable: false),
//                    ModifiedTimestamp = c.DateTimeOffset(precision: 7),
//                    ModifiedBy = c.Int(),
//                    CreatedByName = c.String(),
//                    ModifiedByName = c.String(),
//                })
//                .PrimaryKey(t => t.Id);

//            CreateTable(
//                "dbo.HolidayTypes",
//                c => new
//                {
//                    Id = c.Int(nullable: false, identity: true),
//                    Unid = c.Int(nullable: false),
//                    Created = c.Int(nullable: false),
//                    CreateBy = c.String(),
//                    LastModified = c.Int(nullable: false),
//                    LastModifiedBy = c.String(),
//                    Version = c.Int(nullable: false),
//                    CreatedTimestamp = c.DateTimeOffset(nullable: false, precision: 7),
//                    CreatedBy = c.Int(nullable: false),
//                    ModifiedTimestamp = c.DateTimeOffset(precision: 7),
//                    ModifiedBy = c.Int(),
//                    CreatedByName = c.String(),
//                    ModifiedByName = c.String(),
//                })
//                .PrimaryKey(t => t.Id);

//            CreateTable(
//                "dbo.PrivilegeBindings",
//                c => new
//                {
//                    Id = c.Int(nullable: false, identity: true),
//                    PrivilegeType = c.Int(nullable: false),
//                    Enabled = c.Boolean(nullable: false),
//                    Name = c.String(),
//                    Unid = c.Int(nullable: false),
//                    Created = c.Int(nullable: false),
//                    CreateBy = c.String(),
//                    LastModified = c.Int(nullable: false),
//                    LastModifiedBy = c.String(),
//                    Version = c.Int(nullable: false),
//                    CreatedTimestamp = c.DateTimeOffset(nullable: false, precision: 7),
//                    CreatedBy = c.Int(nullable: false),
//                    ModifiedTimestamp = c.DateTimeOffset(precision: 7),
//                    ModifiedBy = c.Int(),
//                    CreatedByName = c.String(),
//                    ModifiedByName = c.String(),
//                })
//                .PrimaryKey(t => t.Id);

//            CreateTable(
//                "dbo.ScheduleElements",
//                c => new
//                {
//                    Id = c.Int(nullable: false, identity: true),
//                    Holidays = c.Boolean(nullable: false),
//                    Level = c.Int(nullable: false),
//                    PlusDays = c.Int(nullable: false),
//                    Start = c.Time(nullable: false, precision: 7),
//                    Stop = c.Time(nullable: false, precision: 7),
//                    Unid = c.Int(nullable: false),
//                    Created = c.Int(nullable: false),
//                    CreateBy = c.String(),
//                    LastModified = c.Int(nullable: false),
//                    LastModifiedBy = c.String(),
//                    Version = c.Int(nullable: false),
//                    CreatedTimestamp = c.DateTimeOffset(nullable: false, precision: 7),
//                    CreatedBy = c.Int(nullable: false),
//                    ModifiedTimestamp = c.DateTimeOffset(precision: 7),
//                    ModifiedBy = c.Int(),
//                    CreatedByName = c.String(),
//                    ModifiedByName = c.String(),
//                    Schedule_Id = c.Int(),
//                })
//                .PrimaryKey(t => t.Id)
//                .ForeignKey("dbo.Schedules", t => t.Schedule_Id)
//                .Index(t => t.Schedule_Id);

//            CreateTable(
//                "dbo.Schedules",
//                c => new
//                {
//                    Id = c.Int(nullable: false, identity: true),
//                    Unid = c.Int(nullable: false),
//                    Created = c.Int(nullable: false),
//                    CreateBy = c.String(),
//                    LastModified = c.Int(nullable: false),
//                    LastModifiedBy = c.String(),
//                    Version = c.Int(nullable: false),
//                    CreatedTimestamp = c.DateTimeOffset(nullable: false, precision: 7),
//                    CreatedBy = c.Int(nullable: false),
//                    ModifiedTimestamp = c.DateTimeOffset(precision: 7),
//                    ModifiedBy = c.Int(),
//                    CreatedByName = c.String(),
//                    ModifiedByName = c.String(),
//                })
//                .PrimaryKey(t => t.Id);

//        }

//        public override void Down()
//        {
//            DropForeignKey("dbo.ScheduleElements", "Schedule_Id", "dbo.Schedules");
//            DropForeignKey("dbo.Holidays", "HolidayType_Id", "dbo.HolidayTypes");
//            DropForeignKey("dbo.Holidays", "Calendar_Id", "dbo.HolidayCalendars");
//            DropIndex("dbo.ScheduleElements", new[] { "Schedule_Id" });
//            DropIndex("dbo.Holidays", new[] { "HolidayType_Id" });
//            DropIndex("dbo.Holidays", new[] { "Calendar_Id" });
//            DropTable("dbo.Schedules");
//            DropTable("dbo.ScheduleElements");
//            DropTable("dbo.PrivilegeBindings");
//            DropTable("dbo.HolidayTypes");
//            DropTable("dbo.HolidayCalendars");
//            DropTable("dbo.Holidays");
//            DropTable("dbo.Devices");
//        }
//    }
//}