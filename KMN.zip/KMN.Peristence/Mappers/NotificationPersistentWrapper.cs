﻿using System;
using System.Collections.Generic;
using System.Text;
using Persist = KMN.Persistence.Entities;
using KMN.Domain.Entities;

namespace KMN.Persistence.Mappers
{
    class NotificationPersistentWrapper
    {
        public Persist.Notification  Map(Notification  notification)
        {
            var entity = new Persist.Notification
            {
                NotificationId = notification.NotificationId,
                MessageId = notification.MessageId,
                SenderId = notification.SenderId,
                RecipientId = notification.RecipientId,
                MessageTitle = notification.MessageTitle,
                MessageBody = notification.MessageBody,
                NotificationType = notification.NotificationType,
                DeliveryStatus = notification.DeliveryStatus,
                IsDeleted = notification.IsDeleted,
                Timestamp = notification.Timestamp,
                ExpirationTime = notification.ExpirationTime,
                DateCreated = notification.DateCreated,
                LastUpdatedDate = notification.LastUpdatedDate,
                LastUpdatedBy = notification.LastUpdatedBy,
                CreatedBy =  notification.CreatedBy,
                Status = notification.Status
            };
            return entity;
        }

        public Notification Map(Persist.Notification notification)
        {
            var domain = new Notification
            {
                MessageId = notification.MessageId,
                SenderId = notification.SenderId,
                RecipientId = notification.RecipientId,
                MessageTitle = notification.MessageTitle,
                MessageBody = notification.MessageBody,
               // NotificationType = notification.NotificationType,
              //  DeliveryStatus = notification.DeliveryStatus,
                IsDeleted = notification.IsDeleted,
                Timestamp = notification.Timestamp,
                ExpirationTime = notification.ExpirationTime
            };

            return domain;
        }


    }
}
