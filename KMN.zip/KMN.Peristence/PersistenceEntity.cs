﻿using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Text;

namespace KMN.Persistence
{
   public class PersistenceEntity 
    {
        public EntityStatus Status { get; set; } = EntityStatus.Active;
        public bool IsDeleted { get; set; } = false;
        public Guid CreatedBy { get;  set; }
        public Guid LastUpdatedBy { get;  set; }
        public DateTime? DateCreated { get; set; } = DateTime.Now;
        public DateTime? LastUpdatedDate { get;  set; } = DateTime.Now;
    }
}
