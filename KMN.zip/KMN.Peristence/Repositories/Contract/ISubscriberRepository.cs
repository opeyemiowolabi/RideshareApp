﻿using KMN.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace KMN.Persistence.Repositories.Contract
{
   public interface ISubscriberRepository : IDisposable
    {
    }
}
