﻿using KMN.Domain.Entities;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace KMN.Persistence.Repositories.Contract
{
   public interface INotificationRepository : IDisposable
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Notification"></param>
        /// <returns></returns>
        Task<bool> CreateNotificationAsync(Notification notification);
        Task<bool> UpdateNotificationAsync(Notification notification);
        Task<bool> ValidateTokenAsync(Notification notification);
    }
}
