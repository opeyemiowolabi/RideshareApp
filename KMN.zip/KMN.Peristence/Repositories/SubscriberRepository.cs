﻿using KMN.Domain.Entities;
using KMN.Persistence.Mappers;
using KMN.Persistence.Repositories.Contract;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KMN.Persistence.Repositories
{
   public class SubscriberRepository : ISubscriberRepository
    {
        private readonly KMNDBContext _dbContext;
        public SubscriberRepository(KMNDBContext dbContext)
        {
            _dbContext = dbContext;
          
        }



        public void Dispose()
        {
            _dbContext?.Dispose();
        }
    }
}
