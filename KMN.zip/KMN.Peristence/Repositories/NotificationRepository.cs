﻿using KMN.Domain.Entities;
using KMN.Persistence.Mappers;
using KMN.Persistence.Repositories.Contract;
using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KMN.Persistence.Repositories
{
    public class NotificationRepository : INotificationRepository
    {
        private NotificationPersistentWrapper _notificationMapper = new NotificationPersistentWrapper();
        private readonly KMNDBContext _dbContext;

        private IDbSet<Entities.Notification> Notifications { get; }

        public NotificationRepository(KMNDBContext dbContext)
        {
            _dbContext = dbContext;
            Notifications = dbContext.Set<Entities.Notification>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="notification"></param>
        /// <returns></returns>
        public async Task<bool> CreateNotificationAsync(Notification notification)
        {
            try
            {
                var entity = _notificationMapper.Map(notification);
                Notifications.Add(entity);
                var count = await _dbContext.SaveChangesAsync().ConfigureAwait(false);
                return count != 0;
            }
            catch(Exception ex)
            {
                return false;
            }
        }

        public async Task<bool> UpdateNotificationAsync(Notification notification)
        {
            try
            {
                var entity = await Notifications.FirstOrDefaultAsync(x => x.MessageId  == notification.MessageId).ConfigureAwait(false);

                if(entity != null)
                {
                    entity.DeliveryStatus = notification.DeliveryStatus;
                    entity.LastUpdatedDate = notification.LastUpdatedDate;
                }

                var count = await _dbContext.SaveChangesAsync().ConfigureAwait(false);
                return count != 0;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public async Task<bool> ValidateTokenAsync(Notification notification)
        {
            var dbNotification = await Notifications.FirstOrDefaultAsync(x => x.MessageBody  == notification.MessageBody && x.RecipientId == notification.RecipientId).ConfigureAwait(false);

            if (dbNotification != null)
            {
               if (dbNotification.ExpirationTime >= DateTime.Now)
                    return false;

               return true;
            }

            return false;
        }

        public void Dispose()
        {
            _dbContext?.Dispose();
        }       
    }
}
