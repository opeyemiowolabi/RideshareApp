﻿using Softmark.Shared.Domain.Enum;
using System;
using System.ComponentModel.DataAnnotations;

namespace KMN.Persistence.Entities
{
    public class Notification : PersistenceEntity
    {
        public Guid NotificationId { get; set; }
        public Guid MessageId { get; set; }
        public string SenderId { get; set; }
        public string RecipientId { get; set; }
        public string MessageTitle { get; set; }
        public string MessageBody { get; set; }
        public NotificationType NotificationType { get; set; }
        public DeliveryStatus DeliveryStatus { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime?  Timestamp { get; set; }
        public DateTime?  ExpirationTime { get; set; }
    }
}