﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace KMN.Persistence.Entities
{
   public class RiderContact : PersistenceEntity
    {
        public Guid RiderContactId { get; set; }
        public Guid RiderId { get; set; }
        public string Address { get; set; }
        public Guid CityOrLGA { get; set; }
        public Guid State { get; set; }
        public string PrimaryPhoneNo { get; set; }
        public string SecondaryPhoneNo { get; set; }
        public string Email { get; set; }
        public string EmergencyContactName { get; set; }
        public string EmergencyPhoneNumber { get; set; }
    }
}
