﻿using Softmark.Shared.Domain.Enum;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace KMN.Persistence.Entities
{
   public class Rider : PersistenceEntity
    {
        public Guid RiderId { get; set; }
        public string RiderNumber { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public EntityGender Gender { get; set; }
        public string Email { get; set; }
        public string PrimaryPhoneNumber { get; set; }
        public string SecondaryPhoneNumber { get; set; }
        public Guid TakeOffLocationId { get; set; }
        public Guid DestinationLocationId { get; set; }
        public string Occupation { get; set; }
        public string Notes { get; set; }
        public virtual ICollection<RiderContact> Contacts { get; set; }
        public virtual ICollection<VehicleInformation> VehicleInformations { get; set; }
    }
}
