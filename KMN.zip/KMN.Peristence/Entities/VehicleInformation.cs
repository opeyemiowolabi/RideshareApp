﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace KMN.Persistence.Entities
{
   public class VehicleInformation : PersistenceEntity
    {
        public Guid VehicleInformationId { get;  set; }
        public Guid RiderId { get;  set; }
        public Guid VehicleType { get; set; }
        public Guid VehicleMaker { get; set; }
        public Guid VehicleModel { get; set; }
        public int NumberOfPassenger { get; set; }
    }
}
